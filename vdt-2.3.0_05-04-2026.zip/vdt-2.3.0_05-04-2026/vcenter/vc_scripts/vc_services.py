#!/usr/bin/env python
__title__ = "VC SERVICES CHECK"

from vcenter.vc_cfg.current_defaults import service_status, version
from configparser import ConfigParser
import logging
import os
import sys
if os.getenv('VMWARE_PYTHON_PATH') not in sys.path:
    sys.path.append(os.getenv('VMWARE_PYTHON_PATH'))


logger = logging.getLogger(__name__)

def check_vmon_start_priority():
    """
    Check start order for vmon service as outlined in KB 318741

    Returns:
        dict: A dictionary containing the following keys:
            - 'title' (str): The title of the services check.
            - 'result' (str): The result of the services check. It can be 'PASS' or 'FAIL'.
            - 'details' (str): Additional details about the services check, if any.
    """
    title = "VMON Start Priority"
    result = 'PASS'
    details = ''
    documentation = ''
    parsed_config = ConfigParser()
    parsed_config.read("/etc/systemd/system/multi-user.target.wants/vmware-vmon.service")
    start_priority = parsed_config.get('Unit', 'After')
    
    if version.startswith('8.0.1') or version.startswith('8.0.0'):
        if 'vmdird.service' not in start_priority:
            result = 'WARN'
            details = f"Start priority is incorrect: {start_priority.replace(' ', ', ')}"
            documentation = "https://knowledge.broadcom.com/external/article/318741"
    
    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

def check_trustmanagement_start_priority():
    """
    Check svcaccount prestart variable to check for issue outlined in KB 413870

    Returns:
        dict: A dictionary containing the following keys:
            - 'title' (str): The title of the services check.
            - 'result' (str): The result of the services check. It can be 'PASS' or 'FAIL'.
            - 'details' (str): Additional details about the services check, if any.
    """
    title = "Trustmanagement Start Priority"
    result = 'PASS'
    details = ''
    documentation = ''
    try:
        
        from cis.svcaccount_prestart_util import AUTHZ_OPERATIONS_NOT_SUPPORTED_SVCACCOUNTS
        
        if not all(x in AUTHZ_OPERATIONS_NOT_SUPPORTED_SVCACCOUNTS for x in ['lookupsvc', 'trustmanagement']):
            result = 'FAIL'
            details = "Potential service start race condition!"
            documentation = "https://knowledge.broadcom.com/external/article?articleNumber=413870"
        
        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}
    
    except:
        return None  

def check_start_priority():
    '''
    Builds the start priority check for multiple services.

    Returns:
        dict: A dictionary containing the following keys:
            - 'subheading' (str): The title of the services check.
            - 'checks' (list): List of dictionaries containing the results from the service start priority checks.

    '''
    subheading = 'Service Start Priority'
    checks = []

    vmon_check = check_vmon_start_priority()
    checks.append(vmon_check)

    trustmanagement_check = check_trustmanagement_start_priority()
    
    #only add the trustmanagement check if it returns check data
    if trustmanagement_check:
        checks.append(trustmanagement_check)
    
    return {'subheading': subheading, 'checks': checks}

def run_services_check():
    """
    Perform a services check and return a dictionary with the result.

    Returns:
        dict: A dictionary containing the following keys:
            - 'title' (str): The title of the services check.
            - 'result' (str): The result of the services check. It can be 'PASS' or 'FAIL'.
            - 'details' (str): Additional details about the services check, if any.
    """    
    title = "Services Check"
    details = ""
    if len(service_status['STOPPED']) > 0 and len(service_status['RUNNING']) > 0:
        result = 'FAIL'
        stopped_services = '\n  '.join(service_status['STOPPED'])
        details = f"The following services are stopped:\n  {stopped_services}"

    elif len(service_status['RUNNING']) < 1:
        result = 'FAIL'
        details = "All services are stopped."

    elif len(service_status['STOPPED']) < 1:
        result = "PASS"

    return {'title': title, 'result': result, 'details': details}
