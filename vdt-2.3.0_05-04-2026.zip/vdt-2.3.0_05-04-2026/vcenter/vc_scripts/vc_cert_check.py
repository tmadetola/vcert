#!/usr/bin/env python
__title__ = "VC CERTIFICATE CHECK"

import socket
import os
import sys
import json
import traceback
import re
from collections import OrderedDict
from datetime import datetime, timedelta
import ssl
if os.getenv('VMWARE_PYTHON_PATH') not in sys.path:
    sys.path.append(os.getenv('VMWARE_PYTHON_PATH'))
import vmafd

try:
    # Python 3 hack.
    import urllib.request as urllib2
    import urllib.parse as urlparse
except ImportError:
    import urllib2
    import urlparse

sys.path.append(os.environ['VMWARE_PYTHON_PATH'])

parentdir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
libdir = os.path.join(parentdir, 'lib')
sys.path.append(os.path.abspath(libdir))


sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from lib.vdt_formatter import ColorWrap
from vcenter.vc_lib.cert_utils import exManager, validate_chain, split_pem
from vcenter.vc_cfg.current_defaults import sso_domain, hostname, pnid, machine_id, service_status, ca_list, root_map
from vcenter.vc_lib.common import LDAPOps, psqlQuery, Cert, run_command, ChainValidationException, get_all_identity_sources, VecsDB
import logging


logger = logging.getLogger(__name__)

raw_trusted_roots = ca_list
trusted_list = None

vcsa_kblink = "https://knowledge.broadcom.com/external/article?legacyId=76719"
win_kblink = "https://knowledge.broadcom.com/external/article?legacyId=79263"

today = datetime.now()
today = today.strftime("%d-%m-%Y")
delay = 1
timeout = 2

########### CONFIGURABLE PARAMETERS ###########
NUM_DAYS_CRITICAL = 30
NUM_DAYS_WARNING = 60
NUM_DAYS_INFO = 90
CHECKS = {"CRITICAL": NUM_DAYS_CRITICAL,
          "WARNING": NUM_DAYS_WARNING,
          "INFO": NUM_DAYS_INFO}

##### END IMPORTS #####

_DefaultCommmandEncoding = sys.getfilesystemencoding()

### utilitiy functions ###
def getAddr():
    """
    Retrieve IP address and hostname.

    Returns:
        (str, str): A tuple containing the IP address and hostname.

    Raises:
        None.

    Logs:
        Debug log messages indicating the process of retrieving and resolving the IP address and hostname.
    """    
    logger.debug("getting IP and resolving to hostname")
    ip = ""
    ifconfig = run_command(["ifconfig", "eth0"])
    ifconfig = ifconfig.decode()
    for line in ifconfig.split('\n'):
        mylist = list(line.split())
        for param in mylist:
            if "addr:" in param:
                ip = param.split(':')[1]
    hostname = socket.gethostname()
    logger.debug("IP: %s, Hostname: %s" % (ip, hostname))
    return ip, hostname

def autodeploy_serviceaccount_exists(username, password):
    """
    If the autodeploy service account exists, then the rbd extension doesn't.
    Queries vmdir for the service account using LDAP.

    Args:
        username (str): The username to authenticate with.
        password (str): The password to authenticate with.

    Returns:
        bool: True if the autodeploy service account exists.

    Raises:
        None
    """     
    ldapquery = LDAPOps(username, password)
    rbd_user = f"autodeploy-{machine_id}"
    ldapfilter = f"(&(objectclass=vmwServiceAccount)(sAMAccountName={rbd_user}))"
    result = ldapquery.search(None, ldapfilter)
    
    if ldapquery.search(None, ldapfilter):
         logger.debug(f"Autodeploy service account {rbd_user} exists")
         return True
    else:
        logger.debug(f"Autodeploy service account {rbd_user} does not exist")
        return False

class checkCert(object):

    """
    A class for checking certificates.

    Attributes:
        certdata (str): The certificate data.
        hostname (str): The hostname associated with the certificate.
        ip (str): The IP address associated with the certificate.
        alias (str): An alias for the certificate.
        note (str): Additional notes for the certificate.
    """    
    def __init__(self, certdata, hostname="", ip="", alias="", note=""):
        """
        Initialize a Cert object with the given certificate data.

        Args:
            certdata (str): The certificate data.
            hostname (str): The hostname associated with the certificate. Default is an empty string.
            ip (str): The IP address associated with the certificate. Default is an empty string.
            alias (str): An alias for the certificate. Default is an empty string.
            note (str): Additional notes for the certificate. Default is an empty string.

        Returns:
            None

        Raises:
            None
        """        
        self.load_cert = Cert(certdata)
        self.raw_cert = certdata
        logger.debug(self.load_cert.__dict__)
        self.sigalg = self.load_cert.sigalg
        self.alias = alias
        self.note = note
        self.subject = self.load_cert.subject
        logger.debug("Checking certificate: %s for problems" % self.subject)
        if self.load_cert.authkey:
            if self.load_cert.authkey != "FAILED_TO_DECODE":
                self.authkey = self.load_cert.authkey.replace('keyid:', '')
                self.authkey = self.authkey.strip()
            else:
                self.authkey = "ERROR!"
        else:
            self.authkey = None
        if self.load_cert.subjectkey:
            if self.load_cert.subjectkey != "FAILED_TO_DECODE":
                self.subjectkey = self.load_cert.subjectkey.replace('keyid:', '')
                self.subjectkey = self.subjectkey.strip()
            else:
                self.subjectkey = "ERROR!"
        else:
            self.subjectkey = None
        self.san = self.load_cert.subjectAltName
        self.exp = self.load_cert.validuntil.split()[0]
        self.cert_name = self.load_cert.thumbprint
        self.subjectkey = self.load_cert.subjectkey
        self.exp_certs = {}
        self.hostname = hostname
        self.ip = ip
        self.certlist = trusted_list
        self.trustchain = {}
        sol_users = ['vpxd-extension', 'vpxd', 'machine', 'wcp', 'vsphere-webclient', 'hvc']

    def expCheck(self):
        """
        Check the expiration status of a certificate.

        Returns a dictionary containing information about the expiration status of the certificate.

        Returns:
            dict: A dictionary containing the following keys:
                - 'title' (str): The title of the certificate expiration check.
                - 'result' (str): The result of the expiration check ('FAIL', 'WARNING', or 'PASS').
                - 'details' (str): Additional details about the expiration status.
                - 'documentation' (str): Link to additional documentation.

        Raises:
            None

        Note:
            - The expiration check uses predefined thresholds for critical and warning levels.
            - The expiration date of the certificate is compared to the current date and time.
        """ 
        logger.debug("checking expiration")       
        title = "Certificate Expiration Check"
        result = ""
        details = ""
        documentation = ""

        CHECKS = {"CRITICAL": 30,
                  "WARNING": 60}

        today = datetime.now().strftime("%d-%m-%Y")
        conv_exp = datetime.strptime(self.exp, '%Y-%m-%d')
        exp = datetime.strftime(conv_exp, '%d-%m-%Y')
        exp_date = datetime.strptime(exp, '%d-%m-%Y')
        now = datetime.strptime(today, '%d-%m-%Y')

        if exp_date <= now + timedelta(days=CHECKS.get("CRITICAL")):
            result = "FAIL"
            diff = exp_date - now
            exp_in_days = diff.days
            if exp_in_days < 0:
                negative_days = str(exp_in_days).replace('-', '')
                details = f"{self.cert_name}: expired {negative_days} days ago!"
            else:
                details = f"{self.cert_name}: expires in {exp_in_days} days."
            documentation = "https://knowledge.broadcom.com/external/article?legacyId=68171 and https://knowledge.broadcom.com/external/article/385107"

        elif exp_date <= now + timedelta(days=CHECKS.get("WARNING")):
            diff = exp_date - now
            exp_in_days = diff.days

            result = "WARNING"
            details = f"{self.cert_name}: expires in {exp_in_days} days!"
            documentation = "https://knowledge.broadcom.com/external/article?legacyId=68171 and https://knowledge.broadcom.com/external/article/385107"

        else:
            result = "PASS"

        if self.alias == 'data-encipherment':
            if result != "PASS":
                documentation = "https://knowledge.broadcom.com/external/article/312152"

        title = f"{title} - (Expires {str(datetime.strftime(exp_date, '%m-%d-%Y'))})"

        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    def sanCheck(self):
        """
        Check the Subject Alternative Names (SAN) of a certificate.

        Returns a dictionary with the following keys:
            - "title" (str): The title of the check.
            - "result" (str): The result of the check.
            - "details" (str): Additional details about the check.
            - "documentation" (str): Documentation related to the check.

        Raises:
            None

        Returns:
            dict: A dictionary with the check results.
        """
        logger.debug("checking SAN")        
        title = "Certificate SAN Check"
        result = ""
        details = ""
        documentation = ""

        hostflag = True
        ipflag = True

        if self.san:
            if self.hostname.lower() not in self.san.lower():
                hostflag = False
                result = "FAIL"
                details = "Hostname is not in the SAN!"
                if self.ip not in self.san:
                    ipflag = False
                    details = "Neither hostname nor IP in the SAN!"
            if self.ip != "":
                if self.ip not in self.san:
                    ipflag = False
                    result = "PASS"

            if hostflag == True and ipflag == True:
                result = result = "PASS"
            
            if hostflag == True and ipflag == False:
                result = "INFO"
                details = "SAN contains hostname but not IP."
            
            if hostflag == False and ipflag == True:
                result = "WARNING"
                details = "SAN contains IP but not hostname.  This configuration is not recommended."

            if not hostflag and not ipflag:
                result = "FAIL"
                details = "SAN contains neither hostname nor IP!"
        else:
            result = "WARNING"
            details = "No SAN detected"

        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    def algCheck(self):
        """
        Check the certificate Subject Alternative Name (SAN) for compliance.

        Returns a dictionary with the following keys:

        - title (str): The title of the check.
        - result (str): The result of the check, either "PASS" or "FAIL".
        - details (str): Additional details about the check result.
        - documentation (str): Reference to the documentation for further information.

        Returns:
            dict: A dictionary containing the check results.
        """        
        logger.debug("checking algorithm")
        title = "Certificate Algorithm Check"
        result = "PASS"
        details = ""
        documentation = ""

        if "sha1" in self.sigalg:
            result = "FAIL"
            details = f"{self.sigalg} is not a supported algorithm."
            documentation = "Please see the document 'Certificate Requirements for Different Solution Paths' on https://docs.vmware.com corresponding to your version."
        
        elif "ecdsa" in self.sigalg:
            result = "WARNING"
            details = f"{self.sigalg} is not a supported algorithm as part of the MACHINE_SSL_CERT chain of trust. "
            documentation = "https://knowledge.broadcom.com/external/article/369797"

        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}


    def getTrustChain(self, authkey, canum=0):
        """
        Get the trust chain for a given authentication key.

        Args:
            authkey (str): The authentication key.
            canum (int, optional): The index number of the certificate authority. Defaults to 0.

        Returns:
            None

        Raises:
            None
        """        
        rc = 1
        cacount = 'ca' + str(canum)
        if authkey != None:
            for cert in self.certlist:
                if authkey == self.certlist[cert]['subjectkey']:
                    canum += 1
                    rc = 0
                    self.trustchain[cacount] = cert
                    if not 'children' in trusted_list[cert].keys():
                        trusted_list[cert]['children'] = []

                    if self.alias == "":
                        self.alias = self.cert_name

                    if self.note != "":
                        self.alias = self.alias + " (" + self.note + ")"

                    trusted_list[cert]['children'].append(self.alias)
                    if self.certlist[cert]['authkey'] != self.certlist[cert]['subjectkey']:
                        self.getTrustChain(self.certlist[cert]['authkey'], canum)
                else:
                    continue
        else:
            rc = 0

        if rc == 1:
            self.trustchain[authkey] = "Signing authority does not exist in TRUSTED_ROOTS!"

    def printChain(self):
        """
        Prints the trustchain in a formatted manner.

        Args:
            self (object): The instance of the class.

        Returns:
            None
        """        
        trustchain = OrderedDict(sorted(self.trustchain.items()))
        for ca, alias in trustchain.items():
            print("\t  See TRUSTED_ROOTS alias: %s" % alias)

    def trustCheck(self, ignore_chain=False):
        """
        Perform a certificate trust check.

        Returns a dictionary containing the result of the trust check.

        Returns:
            dict: A dictionary with the following keys:
                - 'title': (str) The title of the trust check.
                - 'result': (str) The result of the trust check.
                - 'details': (str) Additional details about the trust check.
                - 'documentation': (str) Documentation related to the trust check.

        Raises:
            None
        """        
        logger.debug("Checking chain of trust")
        title = "Certificate Trust Check"
        result = "PASS"
        details = ""
        documentation = ""
        if not self.subjectkey:
            result = "FAIL"
            details = "This certificate does not have a subject key identifier (not compliant with RFC 5280)!"
            documentation = "See https://knowledge.broadcom.com/external/article?articleNumber=383813"
            return {'title': title, 'result': result, 'details': details, 'documentation': documentation}
            
        msg, status = validate_chain(self.raw_cert, ignore_chain=ignore_chain)
        title += f" ({status})"
        details = f"{msg}"
        if "TRUSTED" not in status or "UNKNOWN" in status:
            if "TRUSTED" not in status:
                result = "FAIL"
                documentation = f"Manually validate the certificate chain: \n\thttps://knowledge.broadcom.com/external/article/369297\n\nReplace the certificate again, but with the complete chain."  
            else:
                result = "WARN"
                documentation = f"\n\tThis signer isn't the current VMCA.\n\tIf this is a custom cert, then it is missing the full chain in the VECS entry.\n\tManually validate the certificate chain: \n\thttps://knowledge.broadcom.com/external/article/369297\n\n\tReplace the certificate again, but with the complete chain."
            
        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    def caCheck(self):
        """
        Check if a certificate is a Certificate Authority (CA).

        Returns a dictionary with the following keys:
        - 'title': A string describing the check being performed.
        - 'result': A string indicating if the check passed or failed.
        - 'details': Additional details about the check result.
        - 'documentation': A URL providing documentation related to the check.

        Raises:
            None
        """ 
        logger.debug("Checking if cert is a certificate authority")       
        title = "Certificate Authority Parameter Check"
        result = ""
        details = ""
        documentation = ""
        logger.info("Checking if certificate is a CA")
        keyusage = self.load_cert.keyusage
        if keyusage and 'Certificate Sign' in keyusage:
            logger.debug("found certificate sign")
            if not self.authkey or self.subjectkey == self.authkey:
                logger.debug(f'authkey: {self.authkey}, skid: {self.subjectkey}')
                title += " (ROOT)"
            else:
                title += " (INTERMEDIATE)"
            result = "PASS"
        else:
            logger.debug("did not find certificate sign")
            title += " (LEAF!)"
            result = "FAIL"
            details = "Certificate is NOT a certificate authority!  It must be removed."
            documentation = "https://knowledge.broadcom.com/external/article?legacyId=2146011"

        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    def reportDn(self):
        """
        Report on the subject DN.

        Returns a dictionary with the following keys:
        - 'title': A string describing the check being performed.
        - 'result': A string indicating if the check passed or failed.
        - 'details': Additional details about the check result.
        - 'documentation': A URL providing documentation related to the check.

        Raises:
            None
        """  
        logger.debug("reporting subject DN")      
        title = "Certificate DN"
        result = "INFO"
        details = f"{self.subject}"
        documentation = ""
        
        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    def extKeyUsageCheck(self):
        """
        Check the extended key usage of a certificate.

        Returns:
            dict: A dictionary containing the following keys:
                - title (str): The title of the check.
                - result (str): The result of the check ('PASS' or 'FAIL').
                - details (str): Additional details about the check, if applicable.
                - documentation (str): Documentation related to the check.
        """
        logger.debug("checking extended key usage")        
        title = "Certificate Key Usage Check"
        result = "PASS"
        details = ""
        documentation = ""

        if self.load_cert.extkeyusage:
            if 'TLS Web Client Authentication' not in self.load_cert.extkeyusage:
                result = "FAIL"
                details = "\tvpxd-extension solution user must have 'TLS Web Client Authentication'!"
        return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    def execute(self, alg=True, exp=True, san=True, ca=False, trust=True, extusage=False, ignore_chain=False):
        """
        Execute various checks and return the results.

        Args:
            alg (bool): If True, perform algorithm check. Default is True.
            exp (bool): If True, perform expiration check. Default is True.
            san (bool): If True, perform subject alternative name check. Default is True.
            ca (bool): If True, perform certificate authority check. Default is False.
            trust (bool): If True, perform trust check. Default is True.
            extusage (bool): If True, perform extended key usage check. Default is False.

        Returns:
            list: A list of check results.
        """        
        output = []

        if alg:
            output.append(self.algCheck())
        if trust:
            output.append(self.trustCheck(ignore_chain))
        if exp:
            output.append(self.expCheck())
        if extusage:
            output.append(self.extKeyUsageCheck())
        if san:
            output.append(self.sanCheck())
        if ca:
            output.append(self.caCheck())
            output.append(self.reportDn())
        return output

def loadMachineCredentials():
    """
        Retrieve machine account and machine account password from vmafd.

        Returns:
            tuple: A tuple containing the machine account and machine account password from vmafd.

            The tuple has the format (username, password).

            If VMAFD is not running, it returns (None, None).

        Raises:
            None.
    """

    if 'vmafdd service required!' in sso_domain:
        return None, None

    vmafdclient = vmafd.client('localhost')
    name = vmafdclient.GetMachineName()
    domain = vmafdclient.GetDomainName()
    username = '{}@{}'.format(name, domain)
    password = vmafdclient.GetMachinePassword()
    return username, password

class parseSts(object):

    """
    A class for parsing STS certificates.

    Attributes:
        processed (list): A list of certificate thumbprints that have been processed.
        results (dict): A dictionary containing the results of the certificate parsing.
            'expired' (dict): A sub-dictionary containing expired certificate information.
                'root' (list): A list of expired root certificates.
                'leaf' (list): A list of expired leaf certificates.
            'valid' (dict): A sub-dictionary containing valid certificate information.
                'root' (list): A list of valid root certificates.
                'leaf' (list): A list of valid leaf certificates.
    """    
    def __init__(self):
        """
        Initialize an instance of the class.

        Stores empty lists and dictionaries within the instance to be used for storing processed and resulting data. 

        Attributes:
            processed (list): An empty list to store processed data.
            results (dict): A dictionary to store resulting data.
                expired (dict): A nested dictionary to store expired data.
                    root (list): An empty list to store expired root data.
                    leaf (list): An empty list to store expired leaf data.
                valid (dict): A nested dictionary to store valid data.
                    root (list): An empty list to store valid root data.
                    leaf (list): An empty list to store valid leaf data.
        """        
        self.processed = []
        self.results = {}
        self.results['expired'] = {}
        self.results['expired']['root'] = []
        self.results['expired']['leaf'] = []
        self.results['valid'] = {}
        self.results['valid']['root'] = []
        self.results['valid']['leaf'] = []

    def get_ldap_certs(self):
        certs = []
        username, password = loadMachineCredentials()
        ldapquery = LDAPOps(username, password)
        base_dn = f"cn={sso_domain},cn=Tenants,cn=IdentityManager,cn=Services,{ldapquery.base_dn}"
        ldap_filter = '(objectclass=vmwSTSTenantCredential)'
        ldap_attribute = 'userCertificate'

        result = ldapquery.search(base_dn, ldap_filter, ldap_attribute, "LEVEL")
        
        for entry in result:
            
            for cert in entry.userCertificate:
                certs.append(ssl.DER_cert_to_PEM_cert(cert))

        return certs
        # print(result)

    def get_certs(self, force_refresh):
        """
        Get the certificates from the STS.

        Args:
            force_refresh (bool): A flag indicating whether to force a refresh of the certificates.

        Returns:
            dict: A dictionary containing the certificates.

        Raises:
            Exception: If there is an error while retrieving the certificates.
        """        
        logger.info("getting STS certs")
        urllib2.getproxies = lambda: {}
        domain_name = sso_domain
        dc_name = hostname
        vmafd_pnid = pnid

        if vmafd_pnid.lower() == dc_name.lower():
            url = (
                    'http://localhost:7080/idm/tenant/%s/certificates?scope=TENANT'
                    % domain_name)
        else:
            url = (
                    'https://%s/idm/tenant/%s/certificates?scope=TENANT'
                    % (dc_name, domain_name))
        try:
            result = json.loads(urllib2.urlopen(url).read().decode('utf-8'))
        except Exception as e:
            e = str(e.reason).split(']')[1]
            logger.error(e)
            raise Exception(e)
        return result

    def check_cert(self, certificate):
        """
        Check the validity of a certificate and update the results.

        Args:
            self: The reference to the current object.
            certificate (str): The certificate to check.

        Returns:
            None

        Raises:
            None
        """        
        # logger.info("Checking certificate: %s" % certificate)
        cert = Cert(certificate)
        certdetail = cert.__dict__

        #  Attempt to identify what type of certificate it is
        if cert.authkey:
            cert_type = "leaf"
        else:
            cert_type = "root"

        #  Try to only process a cert once
        if cert.thumbprint not in self.processed:
            # Date conversion
            self.processed.append(cert.thumbprint)
            exp = cert.validuntil.split()[0]
            conv_exp = datetime.strptime(exp, '%Y-%m-%d')
            exp = datetime.strftime(conv_exp, '%d-%m-%Y')
            now = datetime.strptime(today, '%d-%m-%Y')
            exp_date = datetime.strptime(exp, '%d-%m-%Y')

            # Get number of days until it expires
            diff = exp_date - now
            certdetail['daysUntil'] = diff.days

            # Sort expired certs into leafs and roots, put the rest in goodcerts.
            if exp_date <= now:
                self.results['expired'][cert_type].append(certdetail)
            else:
                self.results['valid'][cert_type].append(certdetail)

    def execute(self):

        """
        Execute the necessary operations on certificates.

        This function retrieves certificates in JSON format and iterates through each item in the JSON. For each item, it further iterates through each certificate and performs a check on the encoded value. The results of the checks are stored and returned.

        Returns:
            list: The results of the certificate checks.

        Raises:
            None
        """
        
        certs =  self.get_ldap_certs()
        
        for item in certs:
            self.check_cert(item)       
        
        return self.results

def checkExtCerts(username, password):
    """
    Check if the vCenter Server Extension Certificates have the correct thumbprint.

    Args:
        username (str): The username to authenticate with.
        password (str): The password to authenticate with.

    Returns:
        dict: A dictionary containing the results of the extension certificate check.
            - title (str): The title of the check.
            - result (str): The overall result of the check ('PASS' or 'FAIL').
            - details (str): Additional details about the check.
            - documentation (str): A link to relevant documentation.

    Raises:
        None
    """    
    title = "VPXD Extension Thumbprint Check"
    result = "PASS"
    details = ""
    documentation = ""

    extensions = ['com.vmware.vim.eam']

    if not autodeploy_serviceaccount_exists(username,password):
        if 'vmware-rbd-watchdog' not in service_status['DISABLED']:
            extensions.append('com.vmware.rbd')
    if 'vmware-imagebuilder' not in service_status['DISABLED']:
        extensions.append('com.vmware.imagebuilder')
    
    cert_client = VecsDB()
    cert = Cert(cert_client.get_cert_from_store('vpxd-extension', 'vpxd-extension'))
    vpxd_ext_thumb = cert.thumbprint

    for extension in extensions:
        ext_thumb = psqlQuery(f'select thumbprint from vpx_ext where ext_id = \'{extension}\';')
        if ext_thumb == vpxd_ext_thumb:
            details += f"\n{ColorWrap.ok('[PASS]')}\t{extension}: thumbprint match"
        else:
            result = "FAIL"
            details += f"\n{ColorWrap.fail('[FAIL]')}\t{extension}: Thumbprint mismatch detected!"
            documentation = "https://knowledge.broadcom.com/external/article?legacyId=57379 | https://knowledge.broadcom.com/external/article?legacyId=2112577 | https://knowledge.broadcom.com/external/article?legacyId=80588"

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}
 

def checkCerts():
    """
    Check certificates in various stores.

    This function retrieves certificates from different stores and performs various checks on each certificate.

    Returns:
        generator: A generator that yields a dictionary containing the results of the certificate checks.

    Yields:
        dict: A dictionary containing information about each store and the certificate checks performed.

    Raises:
        Exception: If an error occurs while checking a certificate.
    """    
    output = []
    myip, myhostname = getAddr()

    storeignore = ['TRUSTED_ROOTS', 'TRUSTED_ROOT_CRLS', 'APPLMGMT_PASSWORD', 'KMS_ENCRYPTION']
    cert_client = VecsDB()
    certs = cert_client.get_all_certs(ignore_list=storeignore)

    for store in certs:
        if store not in storeignore:
            store_check = {'subheading': store.upper(), "checks": []}
            logger.info("Checking certs in store: %s" % store)
            if len(certs[store].keys()) > 0:
                if 'BACKUP_STORE' in store:
                    continue
                for alias in certs[store]:
                    aliases = {}

                    logger.info("Checking cert alias %s in store %s" % (alias, store))
                    try:
                        cert = certs[store].get(alias)
                        if 'wcp' in store or 'wcp' in alias:
                            store_check['checks'].append({'subheading': f"{alias}",
                                            'checks': checkCert(cert, myhostname, myip, alias=alias).execute(
                                                san=False, ignore_chain=True)})
                        

                        elif 'KMS_ENCRYPTION' in store and 'password' not in alias:
                            try:
                                store_check['checks'].append({'subheading': f"{alias}",
                                                'checks': checkCert(cert, myhostname, myip, alias=alias).execute(
                                                    alg=True, exp=True, san=False,
                                                    ca=False, trust=False,
                                                    extusage=False)})
                            except:
                                logger.error("There was a problem checking KMS certs.  Skipping...")
                                pass
                        else:
                            if 'SMS' in store:
                                store_check['checks'].append({'subheading': f"{alias}",
                                                'checks': checkCert(cert, myhostname, myip, alias=alias).execute(
                                                    trust=False, san=False)})


                            else:
                                if 'STS_INTERNAL_SSL_CERT' in store:
                                    title = "Legacy Certificate Found"
                                    result = "WARN"
                                    details = "This store exists in VCSA's that were previously Windows vCenter Servers and then converted to VCSA.\nIt should be removed."
                                    documentation = "https://knowledge.broadcom.com/external/article/316625"
                                    store_check['checks'].append({'title': title, 'result': result, 'details': details, 'documentation': documentation})
                                
                                store_check['checks'].append({'subheading': f"{alias}",
                                           'checks': checkCert(cert, myhostname, myip, alias=alias).execute()})
                                

                    except Exception as e:
                        logger.error("skipping %s, error was: %s" % (alias, e))
                        logger.error(traceback.format_exc())
                        continue
                # newcheck['checks'] = aliases
                yield store_check

def checkRoots():

    """
    Check the roots in the trusted roots store.

    Yields a dictionary for each root certificate in the store, containing subheading and checks information.

    Yields:
        dict: Dictionary containing subheading and checks information for each root certificate.

    Raises:
        None
    """
    cert_client = VecsDB()
    certlist = cert_client.list_certs_in_store("TRUSTED_ROOTS")
    
    for alias, cert in certlist['TRUSTED_ROOTS'].items():  
        yield {'subheading': f"{alias}",'checks': checkCert(cert, alias=alias).execute(
                               san=False, ca=True)}


### entry functions ###

def root_check():
    """
    Check for root certificates on the system.

    Returns:
        list: A list of results from checking for root certificates.
    """    
    results = []
    for x in checkRoots():
        results.append(x)
    return results

def vecs_check():
    """
    Check the certificates and return the results.

    This function calls the `getCaTrustList` function to retrieve a list of certificates and then checks each certificate using the `checkCerts` function. The results of the checks are collected in a list and returned.

    Returns:
        list: A list of the results of the certificate checks.
    """    
    results = []
    for x in checkCerts():
        results.append(x)
    return results

def crls_check():
    """
    Check the number of CRLs in the TRUSTED_ROOT_CRLS store.

    Returns a dictionary with the following keys:
        - 'title': A string representing the title of the check.
        - 'result': A string representing the result of the check ('PASS' or 'FAIL').
        - 'details': A string providing additional details on the check.
        - 'documentation': A string with the link to the related documentation.

    Raises:
        None.
    """    
    title = "TRUSTED_ROOT_CRLS Check"
    documentation = ""
    logger.info("Checking CRLs...")

    details = ""
    kbarticle = "https://knowledge.broadcom.com/external/article?legacyId=80020"
    
    cert_client = VecsDB()
    crlcount = cert_client.get_cert_count_from_store("TRUSTED_ROOT_CRLS")

    if int(crlcount) >= 500:
        result = "FAIL"
        details = f"Large number of CRLs found!  [Count: {crlcount}]"
        documentation = kbarticle
    else:
        result = "PASS"
        title = title + f" [Count: {crlcount}]"

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}


def esxi_cert_mode_check():
    """
    Check the ESXi Certificate Mode.

    Args:
        username (str): The username for accessing the ESXi server.
        password (str): The password for accessing the ESXi server.

    Returns:
        dict: A dictionary containing the title, result, and details of the certificate mode check.
            - title (str): The title of the certificate mode check, with the current certificate mode appended.
            - result (str): The result of the certificate mode check, either 'PASS' or 'FAIL'.
            - details (str): Additional details about the certificate mode check, including recommendations and instructions.

    Notes:
        - If the certificate mode is 'thumbprint', the function sets the result to 'FAIL' and provides recommendations for changing the mode.
    """    
    title = "ESXi Certificate Mode Check"
    details = ""
    result = "PASS"
    documentation = ""
    certmode = psqlQuery("select value from vpx_parameter where name = \'vpxd.certmgmt.mode\';")
    title = title + f" [{certmode}]"
    if certmode == "thumbprint":
        result = "FAIL"
        details = """\tVMware does not recommend using the value of 'thumbprint' for 
the vpxd.certmgmt.mode advanced Setting for extended periods.  
It is recommended to change the value to the default 'vmca', 
or 'custom',depending on your security requirements.  
Changing to one of these values will require that certificates 
be re-issued to the hosts.  See 'Renew or Refresh ESXi Certificates' 
section of the vSphere Security documentation.
        """
        documentation = "https://knowledge.broadcom.com/external/article/372329"

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

def extension_check(username, password):
    """
    Check if a user's credentials have valid extensions.

    Args:
        username (str): The username of the user.
        password (str): The password of the user.

    Returns:
        bool: True if the user's credentials have valid extensions, False otherwise.
    """    
    return checkExtCerts(username, password)

def sts_check():
    """
    Check the status of STS certificates and return the result.

    Returns:
        dict: A dictionary containing the following keys:
            - title (str): The title of the check.
            - result (str): The result of the check, either "PASS" or "FAIL".
            - details (str): Additional details about the check result.
            - documentation (str): Documentation URL for further information.

    Raises:
        Exception: If there is an error contacting the STS service.
    """
    title = "STS Certificate Check"
    result = "PASS"
    details = ""
    documentation = ""
    try:
        parse_sts = parseSts()
        results = parse_sts.execute()
        expired_count = len(results['expired']['leaf']) + len(results['expired']['root'])

        if expired_count > 0:
            result = "FAIL"
            details = f"{expired_count}x expired STS certificates."
            documentation = "https://knowledge.broadcom.com/external/article?legacyId=76719"
    except Exception as e:
        result = "FAIL"
        details = f"Failed to contacting STS service.  Are the STS services running?  Error: {e}", 'fail'

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

def verify_id_source_cert(certs):
    checks = []
    for cert in certs:
        p_cert = Cert(cert)
        checks.append({'subheading': p_cert.subject, 'checks': checkCert(cert).execute(alg=True, exp=True, san=False,
                                        ca=False, trust=False,
                                        extusage=False)})
    return checks

def check_identity_source_certs(username, password):
    title = "Identity Source Certificate Check"
    checks = []
    id_sources = get_all_identity_sources(username,password)
    no_cert_return = {'title': "No certificates", 'result': "INFO"}
    if len(id_sources) > 0:
        for ids in id_sources:
            id_name = f"{ids.get('domain_name')} ({ids.get('type')})"
            if len(ids.get('certificates', [])) > 0:

                checks.append({'subheading': id_name, 'checks': verify_id_source_cert(ids.get('certificates'))})
            else:
                checks.append({'subheading': id_name, 'checks': [no_cert_return]})

        return checks
    else:
        return {'title': "No identity sources found.", 'result': "INFO"}

def check_rui_match():
    """
    Check the status of vpxd rui.crt.

    Returns:
        dict: A dictionary containing the following keys:
            - title (str): The title of the check.
            - result (str): The result of the check, either "PASS" or "FAIL".
            - details (str): Additional details about the check result.
            - documentation (str): Documentation URL for further information.

    Raises:
        Exception: File is unreadable or does not exist.
    """
    filename = "/etc/vmware-vpx/ssl/rui.crt"
    title = "Cert File rui.crt Matches MACHINE_SSL_CERT"
    result = "PASS"
    details = ""
    documentation = ""

    cert_client = VecsDB()
    with open(filename) as f:
            rui_data = f.read()
    rui_data = rui_data.strip()
    MACHINE_CERT = cert_client.get_cert_from_store("MACHINE_SSL_CERT", "__MACHINE_CERT").strip()

    if rui_data != MACHINE_CERT:
        result = "FAIL"
        title = "Cert File rui.crt Does NOT Match MACHINE_SSL_CERT"
        details = f"Replace rui.crt contents with the current contents of MACHINE_SSL_CERT.  See relevant KB."
        documentation = "https://knowledge.broadcom.com/external/article/391725"

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

def check_rui_chain():
    
    """
    validates the chain of the rui.crt.

    Returns:
        dict: A dictionary containing the following keys:
            - title (str): The title of the check.
            - result (str): The result of the check, either "PASS" or "FAIL".
            - details (str): Additional details about the check result.
            - documentation (str): Documentation URL for further information.

    Raises:
        Exception: File is unreadable or does not exist.
    """
    filename = "/etc/vmware-vpx/ssl/rui.crt"
    title = "Validate VPXD rui.crt Certificate Chain"
    result = "PASS"
    details = ""
    documentation = ""

    if os.path.exists(filename):
        with open(filename, 'rb') as f:
            rui_cert = f.read()
    try:
        validate_chain(rui_cert.decode('utf-8'))
    except ChainValidationException as e:
        result = "FAIL"
        details = e.errors

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}