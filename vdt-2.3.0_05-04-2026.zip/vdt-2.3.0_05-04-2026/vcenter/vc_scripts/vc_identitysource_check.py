#!/usr/bin/env python3
import sys
import ssl
import logging
import traceback
from vcenter.vc_lib.common import LDAPOps, get_all_identity_sources, AfdDB
from vcenter.vc_cfg.current_defaults import sso_domain, hostname, pnid, identity_sources

logger = logging.getLogger(__name__)

class RemoveLegacySysDomain(LDAPOps):
    """
    Handles the removal of specific system domain attributes from LDAP identity providers.

    This class provides methods to locate identity provider DNs within an SSO domain
    and clean up problematic attributes like UPN suffixes and aliases.
    """

    def __init__(self, username, password):
        """
        Initialize an LDAP connection object with the purpose of removing SYSTEM-DOMAIN.

        Args:
            username (str): The username for the LDAP connection.
            password (str): The password for the LDAP connection.
            sso_domain (str, optional): SSO domain name (e.g., 'vsphere.local').
        """
        super().__init__(username, password)
        self.lwreg = AfdDB()
        

    def get_id_dn(self) -> str:
        """
        Constructs the Distinguished Name (DN) for the identity provider source.

        Returns:
            str: The full LDAP DN for the identity provider.
        """
        id_source_dn = f"cn={self.sso_domain},cn=IdentityProviders,cn={self.sso_domain},cn=Tenants,cn=IdentityManager,cn=Services,{self.base_dn}"
        return id_source_dn

    def get_id_provider(self) -> any:
        """
        Searches LDAP for the identity provider object using the STS identity store class.

        Returns:
            object: The first LDAP entry result if found, otherwise None.
        """
        object_dn = self.get_id_dn()
        filter = "(objectClass=vmwSTSIdentityStore)"
        attributes = ['*']
        results = self.reuse_search(base_dn=object_dn, ldap_attributes=attributes, ldap_filter=filter)

        if results:
            return results[0]
        else:
            logger.debug(f"No URL endpoint found for {object_dn}!")
            return None

    def get_id_provider_attrs(self) -> dict:
        """
        Retrieves the attributes of the identity provider as a dictionary.

        Returns:
            dict: A dictionary of entry attributes, or an empty dict if not found.
        """
        id_provider = self.get_id_provider()

        if id_provider:
            return id_provider.entry_attributes_as_dict
        else:
            logger.debug(f"No attributes found for the ID provider!")
            return {}

    def find_bad_attrs(self) -> list:
        """
        Identifies problematic domain attributes currently present in the identity provider.

        Returns:
            list: A list of attribute names found that match the 'bad' criteria 
                  (vmwSTSUpnSuffixes, vmwSTSAlias).
        """
        id_attrs = self.get_id_provider_attrs()
        badentries = ['vmwSTSUpnSuffixes', 'vmwSTSAlias']
        results = [x for x in id_attrs if x in badentries]
        if 'vmwSTSUpnSuffixes' in id_attrs:
            if "SYSTEM-DOMAIN" not in id_attrs.get('vmwSTSUpnSuffixes')[0]:
                results.remove('vmwSTSUpnSuffixes')
        if len(results) > 0:
            logger.debug(f"Found bad identity provider attributes: {results}")
        else:
            logger.debug("No bad identity provider attributes found.")
        return results

    def find_bad_dn(self) -> bool:       
        """
        Searches LDAP for the identity provider object using the STS identity store alias class.

        Returns:
            object: The first LDAP entry result if found, otherwise None.
        """
        
        object_dn = f"cn=SYSTEM-DOMAIN,cn=IdentityProviders,cn={self.sso_domain},cn=Tenants,cn=IdentityManager,cn=Services,{self.base_dn}"
        filter = "(objectClass=vmwSTSIdentityStoreAlias)"
        attributes = ['*']
        results = self.reuse_search(base_dn=object_dn, ldap_attributes=attributes, ldap_filter=filter)
        logger.debug(results)

        if results:
            logger.debug("Found SYSTEM-DOMAIN DN!")
            return True
        else:
            logger.debug("No SYSTEM-DOMAIN DN found.")
            return False

    def find_bad_reg_keys(self) -> list:
        """
        Identifies problematic registry keys currently present in the likewise registry.

        Returns:
            list: A list of registry key names found that match the 'SPSystemDomain*' 
                  (SPSystemDomainAlias, SPSystemDomainBackCompat, SPSystemDomainUserAliases).
        """
        results = []
        regkey = "SPSystemDomain%"
        reg_keys = self.lwreg.get_reg_value_search(regkey)
        for reg_key in reg_keys:
            results.extend([x for x,y in reg_key.items()])
        # results = [i for i,j in x.items() for x in reg_keys if reg_keys]
        
        if len(results) > 0:
            logger.debug(f"Found the following bad registry keys: {results}")
        
        else:
            logger.debug("No bad registry keys found.")
        
        return results

    def find_legacy_system_domain(self):
        """
        Only calls the functions to find problem attributes or registry keys.
        
        this is the dry-run function.
        """
        logger.info("Checking for legacy identity provider references.")
        bad_attrs = self.find_bad_attrs()
        bad_dn = self.find_bad_dn()
        bad_regkeys = self.find_bad_reg_keys()
        if any([bad_attrs, bad_dn, bad_regkeys]):
            logger.warning("Problems found!  Please run this tool without the dry-run option to fix them.")
        else:
            logger.info("No offending entries found.")

def legacy_system_domain_check(username, password):
    title = "Legacy SYSTEM-DOMAIN Check"
    details = ""
    documentation = ""
    result = "PASS"

    rlsd = RemoveLegacySysDomain(username, password)
    
    try:
        bad_attrs = rlsd.find_bad_attrs()
        bad_dn = rlsd.find_bad_dn()
        bad_regkeys = rlsd.find_bad_reg_keys()   
    
    except Exception as e:
        print(traceback.format_exc())
    
    finally:
        rlsd.close()

    if any([bad_attrs, bad_dn, bad_regkeys]):
        result = "FAIL"
        details = "Legacy SYSTEM-DOMAIN found!  This can cause significant authentication problems!"
        if bad_attrs:
            details += f"\n\u2022\tBad identity provider attribute(s) found!"
        if bad_dn:
            details += f"\n\u2022\tSYSTEM-DOMAIN identity source found"
        if bad_regkeys:
            details += f"\n\u2022\tBad LW registry key(s) found!"
        
        details += "\nPlease run the script attached to the referenced KB article."
        documentation = "https://knowledge.broadcom.com/external/article/408176"
    
    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

def identity_source_types(username,password):
    """
    lists types of identity sources configured

    Returns:
        dict: A dictionary containing the following fields:
            - title (str): The title of the result indicating if the local OS identity source exists or not.
            - result (str): The result of the check, either 'PASS' or 'WARN'.
            - Note (str): Additional details about the check if the local OS identity source does not exist.
            - documentation (str): A link to the documentation for more information.

    Raises:
        None.
    """
    
    title = "Identity sources configured:"
    documentation = ""
    details = ""

    all_identity_sources = get_all_identity_sources(username, password)

    if identity_sources:
        all_identity_sources.append(identity_sources)

    if len(all_identity_sources) > 0:
        for x in all_identity_sources:
            ids_string = f"{x.get('domain_name')} ({x.get('type')})"
            if 'connection_string' in x.keys():
                conn_str = x.get('connection_string')
                ids_string += f": {conn_str}"
        details += ids_string + "\n"
    else:
        title = "No identity source configured"


    return {'title': title, 'result': 'INFO', 'details': details, 'documentation': documentation}

def connection_string_check(username, password):
    """
    Checks if the VMDIR STS connection string points to a bad provider.

    Args:
        username (str): The username to connect to the LDAP server.
        password (str): The password to authenticate with the LDAP server.

    Returns:
        dict: A dictionary containing the following fields:
            - title (str): The title of the result indicating if the local OS identity source exists or not.
            - result (str): The result of the check, either 'PASS' or 'WARN'.
            - Note (str): Additional details about the check if the local OS identity source does not exist.
            - documentation (str): A link to the documentation for more information.

    Raises:
        None.
    """
    
    title = "STS connection string okay"
    details = ""
    documentation = ""
    ldap_query = LDAPOps(username, password)
    connection_string = ""
    filter = f"(&(objectclass=vmwSTSIdentityStore)(vmwSTSProviderType=IDENTITY_STORE_TYPE_VMWARE_DIRECTORY))"
    connection_string = str(ldap_query.search(None, filter, ldap_attributes=['vmwSTSConnectionStrings'])[0].vmwSTSConnectionStrings)

    if any(x in connection_string.lower() for x in [hostname.lower(), pnid.lower(), 'localhost']):
        result = "PASS"
    else:
        result = "FAIL"
        title = f"STS connection string is incorrect ({connection_string})"
        details = "This could prevent services from starting after a recent decommission of another vCenter"
        documentation = "https://knowledge.broadcom.com/external/article?legacyId=91965"

    return {'title': title, 'result': result, 'Note': details, 'documentation': documentation}





def main(username, password):
    """
    Checks if a local OS identity source exists and returns the result.

    Args:
        username (str): The username to connect to the LDAP server.
        password (str): The password to authenticate with the LDAP server.

    Returns:
        dict: A dictionary containing the following fields:
            - title (str): The title of the result indicating if the local OS identity source exists or not.
            - result (str): The result of the check, either 'PASS' or 'WARN'.
            - Note (str): Additional details about the check if the local OS identity source does not exist.
            - documentation (str): A link to the documentation for more information.

    Raises:
        None.
    """    
    title = "Local OS identity source exists"
    details = ""
    documentation = ""
    ldap_query = LDAPOps(username, password)

    filter = f"(&(objectclass=vmwSTSIdentityStore)(vmwSTSProviderType=IDENTITY_STORE_TYPE_LOCAL_OS))"

    if ldap_query.search(None, filter):
        result = "PASS"
    else:
        result = "WARN"
        title = "Local OS identity source does NOT exist"
        details = "This can cause an issue in vCenter 8.0U2 and U2a with Storage Profiles."
        documentation = "https://knowledge.broadcom.com/external/article?legacyId=94870"

    return {'title': title, 'result': result, 'Note': details, 'documentation': documentation}