import sys, os
from vcenter.vc_lib.common import psqlQueryAsUser, Cert, CheckConnect, psqlPythonQueryWithPassword
from vcenter.vc_cfg.current_defaults import version, ca_list, ca_pem_file
sys.path.append(os.environ['VMWARE_PYTHON_PATH'])
import certifi
from OpenSSL import SSL
from OpenSSL.crypto import dump_certificate, FILETYPE_PEM
import urllib.parse as urlparse
from urllib3 import disable_warnings
import requests
import logging
import json
import ssl
from ssl import SSLError
import socket

disable_warnings()

BC_DL_URL = "dl.broadcom.com"
BC_DL_TSGUIDE = "https://knowledge.broadcom.com/external/article/395322"
KB_CONFIG_INSTRUCTIONS = "https://knowledge.broadcom.com/external/article/390098"
timeout = 2

logging.getLogger('urllib3').setLevel(logging.WARNING)
logger = logging.getLogger(__name__)

def verify_cb(conn, cert, errun, depth, ok):
        return True

def transparent_proxy_cert_verify():
    hostname = urlparse.urlparse(BC_DL_URL).hostname
    
    conn = ssl.create_connection((hostname, 443))
    context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    sock = context.wrap_socket(conn, server_hostname=hostname)
    
    certificate = ssl.DER_cert_to_PEM_cert(sock.getpeercert(True))
    
    return certificate


def proxy_test_cert_verify(proxies):
    https_proxy = urlparse.urlparse(proxies.get('https'))
    proxy_host = https_proxy.hostname
    proxy_port = https_proxy.port
    PROXY_ADDR = (f"{proxy_host}", proxy_port)
    CONNECT = f"CONNECT {BC_DL_URL}:{443} HTTP/1.0\r\nConnection: close\r\n\r\n"
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    s.setblocking(1)
    s.connect(PROXY_ADDR)
    s.send(str.encode(CONNECT))
    s.recv(4096)

    ctx = SSL.Context(SSL.SSLv23_METHOD)
    ctx.set_verify(SSL.VERIFY_NONE, verify_cb)

    ss = SSL.Connection(ctx, s)
    ss.set_connect_state()
    ss.do_handshake()
    cert = ss.get_peer_certificate()
    ss.shutdown()
    ss.close()
    return dump_certificate(cert=cert, type=FILETYPE_PEM).decode('utf-8')


def get_server_cert(hostname, port=443):
    """
    Gets SSL cert from host on port specified. Converts to
    string compatible with LS specs.

    Args:
        hostname (str): The hostname.
        port (int): The port.

    Returns:
        cert: The certificate string formatted for lookup service endpoints.
    """
    #  returns the cert trust value formatted for lstool
    logger.debug("Getting SSL certificate on %s:%s" % (hostname, port))
    ssl.create_default_context()
    socket.setdefaulttimeout(5)

    return ssl.get_server_certificate((hostname, port), ssl_version=ssl.PROTOCOL_TLS)

def get_proxies():
    proxy_file = "/etc/sysconfig/proxy"
    params = {}
    with open(proxy_file) as f:
        for line in f.readlines():
            if not line.startswith('#'):
                if "=" in line:
                    name, value = line.split('=')
                    params[name] = value.rstrip().replace('"', '')
    proxies = {
        "http": params.get('HTTP_PROXY'),
        "https": params.get('HTTPS_PROXY')
    }
    return proxies

def proxy_configured(proxies):
    for x,y in proxies.items():
        if y:
            return True
        
    return False

def test_url(title, url, fail_doc, token="",proxies={},verify=True):

    hostname = urlparse.urlparse(url).hostname
    result = "PASS"
    documentation = ""
    details = ""

    context = ssl.create_default_context()
    if not verify:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

    try:
        r = requests.get(url, stream=True, timeout=timeout, proxies=proxies, verify=verify)
        if r.status_code >= 200 and r.status_code < 400:
            title = f"{title} - OK"
            content = next(r.iter_content(10))
        else:
            result = "FAIL"
            title = f"{title} - ({r.status_code}:{r.reason})"
            documentation = fail_doc
            details = f""        
    
    except requests.exceptions.SSLError:
        
        if verify != ca_pem_file and verify == True:
            return test_url(title, url, fail_doc, token, proxies=proxies, verify=ca_pem_file)
        
        else:

            title = f"{title} - UNTRUSTED"
            
            try:
                if proxy_configured(proxies):
                    raw_cert = proxy_test_cert_verify(proxies)
                else:
                    raw_cert = transparent_proxy_cert_verify()
                cert = Cert(raw_cert)
                detected_issuer = cert.issuer
                logger.debug(f"got cert: {str(cert)}")

                details_msg = f"""
    The connection to {BC_DL_URL} is being intercepted by a security device in your network.  
    Ensure file downloads from {BC_DL_URL} are not being blocked by this device.
    Additional Info: The SSL cert issuer for {hostname} is not trusted!
    Detected issuer: {detected_issuer}
    You will likely have to manually trust the device's certificate.  see KB 326301

    """
                docu_msg = "https://knowledge.broadcom.com/external/article/326301"
                
                result = test_url(title, url, fail_doc, token, proxies=proxies, verify=False)
                result['result'] = "FAIL"
                result['details'] = result['details'] + details_msg
                result['documentation'] = result['documentation'] + f"\n{docu_msg}"
                return result

            except Exception as e:
                result = "FAIL"
                details = f"Unable to parse the certificate!  Error was: {e}"
    
    except requests.exceptions.ConnectTimeout as e:
        e = str(e).replace(url, hostname)
        result = "FAIL"
        details = f"Failed to connect to {hostname} due to timeout.  Please check network connectivity."

    except requests.exceptions.ConnectionError as e:
        result = "FAIL"
        e = str(e).replace(url, hostname)
        
        if "Name or service not known" in str(e):
            details = f"Connection error.  Failed to resolve {hostname} in DNS!"
        
        elif "Connection refused" in str(e):
            details = f"Connection error.  Connection to {hostname} was refused!"

        elif "Network is unreachable" in str(e):
            details = f"Connection error.  Connection to {hostname}:  Network is unreachable!"
        
        else:
            details = f"Connection error.  Error was: {e}"
   
    except Exception as e:
        e = str(e).replace(url, hostname)
        result = "FAIL"
        details = f"ERROR connecting to {hostname}!\n Error was: {e}"

    return {'title': title, 'result': result, 'details': details.replace(token, '<download token>'), 'documentation': documentation}

def test_host_update(token):
    proxies = get_proxies()
    output = []
    HOST_UPDATE_7 = f"https://{BC_DL_URL}/{token}/PROD/COMP/ESX_HOST/main/esx/vmw/vib20/bmcal/VMware_bootbank_bmcal_7.0.3-0.135.24585291.vib"
    HOST_UPDATE_8 = f"https://{BC_DL_URL}/{token}/PROD/COMP/ESX_HOST/main/esx/vmw/vib20/bcm-mpi3/VMW_bootbank_bcm-mpi3_8.8.1.0.0.0-1vmw.803.0.0.24022510.vib"
    output.append(test_url("7.x URL Test", HOST_UPDATE_7, BC_DL_TSGUIDE, token=token, proxies=proxies))
    output.append(test_url("8.x URL Test", HOST_UPDATE_8, BC_DL_TSGUIDE, token=token, proxies=proxies))
    return {'subheading': 'Download Test', 'checks': output}

def test_vc_update(token):
    proxies = get_proxies()
    output = []
    VC_UPDATE_7 = f"https://{BC_DL_URL}/{token}/PROD/COMP/VCENTER/vmw/8d167796-34d5-4899-be0a-6daade4005a3/7.0.3.02300/package-pool/vmware-vsm-7.0.3.02300-15160956.x86_64.rpm"
    VC_UPDATE_8 = f"https://{BC_DL_URL}/{token}/PROD/COMP/VCENTER/vmw/8d167796-34d5-4899-be0a-6daade4005a3/8.0.3.00500/package-pool/155c73ec8a8de71373b88686fddbe039e9a93649d8d1de5abe8257cc91f61d56.blob"
    output.append(test_url("7.x URL Test", VC_UPDATE_7, BC_DL_TSGUIDE, token=token, proxies=proxies))
    output.append(test_url("8.x URL Test", VC_UPDATE_8, BC_DL_TSGUIDE, token=token, proxies=proxies))
    return {'subheading': 'Download Test', 'checks': output}

def get_vumuser_password():
    
    filename = "/usr/lib/vmware-updatemgr/bin/configvalues.txt"
    password = ""
    with open(filename) as f:
        data = f.readlines()
    for line in data:
        if 'db_password' in line:
            password = line.split('=', 1)[1].rstrip()
    return password

def get_vum_url_config():
        
    details = ""
    documentation = ""
    title = "URL Config"
    result = "PASS"
    
    token = ""
    url_endpoints = []
    expected_urls = ['PROD/COMP/ESX_HOST/main/vmw-depot-index.xml', 'PROD/COMP/ESX_HOST/addon-main/vmw-depot-index.xml', 'PROD/COMP/ESX_HOST/iovp-main/vmw-depot-index.xml', 'PROD/COMP/ESX_HOST/vmtools-main/vmw-depot-index.xml']
    logger.debug(f"expected URLs: {expected_urls}")
    
    try:
        vum_pass = get_vumuser_password()
        query = 'select url from pm_online_and_umds_depots;'
        urls = [x[0] for x in psqlPythonQueryWithPassword(query=query, password=vum_pass, sqluser='vumuser')]
    except:
        query = 'select url from pm_online_and_umds_depots'
        urls = psqlQueryAsUser(osuser="updatemgr", query=query, sqluser='vumuser', return_all=True).splitlines()
    
        del urls[:2]
    
    for x in urls:
        parsed_url = urlparse.urlparse(x)
        logger.debug(f"Found update URL with hostname: {parsed_url.netloc}")
        if parsed_url.netloc == BC_DL_URL:
            url_path_list = parsed_url.path.split('/')
            token = url_path_list[1]
            url_path = '/'.join(url_path_list[2:])
            url_endpoints.append(url_path)
    
    logger.debug(f"URLs found: {url_endpoints}")
    
    if len(url_endpoints) < 1:
        result = "WARN"
        details = "\n Changes are required for Broadcom ESXi patch downloads!"
        documentation = KB_CONFIG_INSTRUCTIONS
    else:

        if not all(x in expected_urls for x in url_endpoints):
            missing_endpoints = [ep for ep in expected_urls if ep not in url_endpoints]
            
            output_missing = '\n\t'.join([f'https://{BC_DL_URL}/<downloadtoken>/{missing}' for missing in missing_endpoints])
            result = "WARN"
            details = f" Further changes are required for online patching!  You are missing the following endpoint(s):\n\n\t{output_missing}\n\n"
            documentation = KB_CONFIG_INSTRUCTIONS
    
    output = {'title': title, 'result': result, 'details': details, 'documentation': documentation}

    return output, token

def vlcm_vum_checks():

    title = "VLCM/VUM Configuration"
    if version.startswith('9'):
        return {'subheading': title, 'checks': [{'title': 'Skipped as not necessary in 9+.', 'result': 'PASS'}]}
    checks = []
    url_check, token = get_vum_url_config()
    checks.append(url_check)
    if token != "":
        checks.append(test_host_update(token))

    return {'subheading': title, 'checks': checks}

def get_vami_url_config():

    title = "URL Config"
    result = "WARN"
    details = "\nChanges are required for Broadcom vCenter patch downloads!"
    documentation = KB_CONFIG_INSTRUCTIONS

    policy_conf = "/etc/applmgmt/appliance/software_update_policy.conf"
    
    token = ""
    output = {'title': title,'result': result, 'details': details, 'documentation': documentation}
    if os.path.exists(policy_conf):
        with open(policy_conf) as file:
            data = json.load(file)
        if 'custom_url' in data.keys():
            current_url = urlparse.urlparse(data.get('custom_url'))
            if current_url.netloc == BC_DL_URL:
                url_path_list = current_url.path.split('/')
                token = url_path_list[1]
                result = "PASS"
                output = {'title': title,'result': result}
            
    return output, token

def vami_update_checks():

    title = "VAMI Configuration"
    if version.startswith('9'):
        return {'subheading': title, 'checks': [{'title': 'Skipped as not necessary in 9+.', 'result': 'PASS'}]}
    checks = []
    url_check, token = get_vami_url_config()
    checks.append(url_check)
    if token != "":
        checks.append(test_vc_update(token))

    return {'subheading': title, 'checks': checks}

def verify_ssl_certificate(hostname):
    context = ssl.create_default_context()
 
    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            ssock.do_handshake()
            cert = ssock.getpeercert()
            print("Certificate is valid.")

def broadcom_connectivity_check():
    title = "dl.broadcom.com"
    result = "PASS"
    details = ""
    documentation = ""
    port = 443
    try:
        socket.gethostbyname(BC_DL_URL)
        rc, connection_result = CheckConnect(BC_DL_URL,port).check()
        if not rc:
            result = "FAIL"
            details = f"Cannot contact port 443 on {BC_DL_URL}!"
    except SSLError as e:
        result = "FAIL"
        details = f"Error was: {e.reason}"
    except socket.gaierror as e:
        result = "FAIL"
        details = f"Could not resolve {BC_DL_URL} in DNS!"
    except socket.timeout as e:
        result = "FAIL"
        details = f"Timed out trying to contact {BC_DL_URL}!"
    except Exception as e:
        result = "FAIL"
        details = f"ERROR connecting to {BC_DL_URL}!\n Error was: {e}"
    
    return {'subheading': "Network Connectivity",'checks': [{'title': title, 'result': result, 'details': details, 'documentation': documentation}]}

