#!/usr/bin/env python
__title__ = "Lookup Service Check"
from vcenter.vc_lib.lstool_scan import *
from vcenter.vc_lib.lstool_parse import *
from vcenter.vc_lib.common import AfdDB, RegValueNotFound
from lib.vdt_formatter import ColorWrap
from vcenter.vc_cfg.current_defaults import machine_id, version, sso_domain
import json
import xml.etree.ElementTree as xml
sys.path.append(os.environ['VMWARE_PYTHON_PATH'])
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import vmafd
import logging
logger = logging.getLogger(__name__)

#REQUIRED SERVICES ARE VMAFD, VMDIR

class lsReport(object):

    """
    Runs lstool_parse and lstool_scan to identify problems in the SSO domain.

    Attributes:
        report (json): this is the output of lstool_scan.py
        report_file (str): path to destination scan results file.
    """

    def __init__(self):
        """
     Args:
         params (dict): Dictionary of local node parameters returned from utils.get_params().
         report_file (str): Path to destination scan results file.
     """

        parser = LSTool_Parse()
        lsJsonData = parser.parseData()
        scanner = LSTool_Scan(lsJsonData)
        self.report = scanner.execute(live=True)

    def generateReport(self):
        """
     This function outputs the problems found (if any) and dumps the report to self.report_file.
     """
        title = "Lookupservice Check"
        result = ""
        results = []

        for site in self.report:
            site_problems = []

            for node in self.report[site]:

                nodename = node
                output = self.report[site][node]['Problems Detected']
                checks = []
                if output != "No problems found.":
                    result = 'FAIL'
                    nodename = f"{ColorWrap.fail('[FAIL]')}    {node}"
                    for problem in self.report[site][node]['Problems Detected']:
                        if problem:
                            title = problem
                            details = ""

                            if 'UNKNOWN' in node or 'NO_HOSTNAME' in node:
                                if not 'Node In Multiple Sites' in self.report[site][node]['Problems Detected']:
                                    title = "3rd party/Orphaned service registrations.  Additional investigation needed:"

                                    for service in self.report[site][node]['Services']:
                                        for x in self.report[site][node]['Services'][service]:
                                            if 'Service ID' in x.keys():
                                                serviceid = x['Service ID']
                                                details += f"Type: {service}, ID: {serviceid}"
                                else:
                                    details = self.report[site][node]['Problems Detected'][problem].get('Recommended Action')


                            else:
                                details = self.report[site][node]['Problems Detected'][problem].get('Recommended Action')

                            checks.append({'title': title, 'details': details, 'result': result})
                    site_problems.append({'subheading': nodename, 'checks': checks})

                else:

                    if 'UNKNOWN' in node or 'NO_HOSTNAME' in node:

                        result = 'WARNING'
                        title = "3rd party/Orphaned service registrations.  Could not identify association by hostID, nodeID or serviceID."
                        details = ""
                        for service in self.report[site][node]['Services']:
                            for x in self.report[site][node]['Services'][service]:
                                if 'Service ID' in x.keys():
                                    serviceid = x['Service ID']
                                    details += f"Type: {service}, ID: {serviceid}"
                        checks.append({'title': title, 'details': details, 'result': result})
                        site_problems.append({'subheading': nodename, 'checks': checks})

                    else:
                        site_problems.append({'subheading': f'{ColorWrap.ok("[PASS]")}    {nodename}', 'checks': []})
                        # site_problems.append({'title': nodename, 'result': 'PASS'})

            results.append({'subheading': f'SSO Site: {site}', 'checks': site_problems})
        return results

def compare_mid_reg_vmafd():
    """
    Compare the machine ID reported by the vmafd service with the machine ID in the likewise registry.
    Also checks for the MachineGuid registry key missing.

    Returns a dictionary with the following keys:
        - title (str): The title of the machine ID check.
        - details (str): Additional details about the check.
        - result (str): The result of the machine ID check ('PASS' or 'FAIL').
        - documentation (str): A URL to additional documentation.

    Raises:
        None.

    Requires:
        - vmafd service needs to be running.

    Returns:
        dict: A dictionary containing the result of the machine ID check.
    """    
    title = "Compare Machine ID (VMAFD vs. registry)"
    result = "PASS"
    details = ""
    documentation = ""
    
    lwreg = AfdDB()
    try:
        reg_mid = lwreg.machine_id()
    except RegValueNotFound:
        reg_mid = None

    vmafdclient = vmafd.client('localhost')
    vmafd_mid = vmafdclient.GetMachineID()


    if not reg_mid:
        result = "FAIL"
        details = "MachineGuid registry key missing!  Follow the KB to correct."
        documentation = "https://knowledge.broadcom.com/external/article/312479"
    
    elif reg_mid != vmafd_mid:
        result = "FAIL"
        details = "Machine ID doesn't match between the VMAFD service and the likewise registry!  Follow the KB to correct."
        documentation = "https://knowledge.broadcom.com/external/article/312479"

    else:
        logger.debug("Machine ID matches between VMAFD and likewise registry")

    return {'title': title, 'details': details, 'result': result, 'documentation': documentation}

def compare_mid_reg_vpxd():
    """
    Compare the machine ID in the vpxd.cfg file with the machine ID in the likewise registry.
    Also checks for the MachineGuid registry key missing.

    Returns a dictionary with the following keys:
        - title (str): The title of the machine ID check.
        - details (str): Additional details about the check.
        - result (str): The result of the machine ID check ('PASS' or 'FAIL').
        - documentation (str): A URL to additional documentation.

    Raises:
        None.

    Requires:
        - The function getMachineIdFromVpxdCfg() which retrieves the machine ID from the vpxd.cfg file.

    Returns:
        dict: A dictionary containing the result of the machine ID check.
    """    
    title = "Compare Machine ID (vpxd.cfg vs. registry)"
    result = "PASS"
    details = ""
    documentation = ""
    vpxd_mid = getMachineIdFromVpxdCfg()
    
    lwreg = AfdDB()
    try:
        reg_mid = lwreg.machine_id()
    except RegValueNotFound:
        reg_mid = None

    if not reg_mid:
        result = "FAIL"
        details = "MachineGuid registry key missing!  Follow the KB to correct."
        documentation = "https://knowledge.broadcom.com/external/article/312479"
    
    elif reg_mid != vpxd_mid:
        result = "FAIL"
        details = "Machine ID doesn't match between vpxd.cfg and the likewise registry!  Follow the KB to correct."
        documentation = "https://knowledge.broadcom.com/external/article/312479"

    else:
        logger.debug("Machine ID matches between vpxd.cfg and likewise registry")

    return {'title': title, 'details': details, 'result': result, 'documentation': documentation}

def getMachineIdFromVpxdCfg():
    """
    Returns the machine ID extracted from the vpxd.cfg file.

    Returns:
        str: The machine ID extracted from the vpxd.cfg file. If an error occurs during parsing, it returns 'FAILED TO PARSE VPXD.CFG'.
    """

    try:
        vpxd = xml.parse("/etc/vmware-vpx/vpxd.cfg")
        sol_entry = vpxd.findall('.//name')
        vcsol = sol_entry[0].text
        vcsol = vcsol.replace("vpxd-svc-acct-",'').replace("vpxd-",'').split('@')[0]
    except:
        vcsol = "FAILED TO PARSE VPXD.CFG"
    return vcsol

def getSsoDomainFromVpxdCfg():
    
    """
    Returns the sso domain extracted from the vpxd.cfg file.

    Returns:
        str: The SSO domain extracted from the vpxd.cfg file. If an error occurs during parsing, it returns 'FAILED TO PARSE VPXD.CFG'.
    """    
    try:
        if version.startswith('9'):
            user_marker = 'vpxd-svc-acct-'
        else:
            user_marker = 'vpxd-'
        vpxd = xml.parse("/etc/vmware-vpx/vpxd.cfg")
        sol_entry = vpxd.findall('.//name')
        vcsol = sol_entry[0].text
        cfg_sso_domain = vcsol.split('@')[1]
        logger.debug(f"SSO domain in vpxd.cfg is: {cfg_sso_domain}")
    except:
        cfg_sso_domain = "FAILED TO PARSE VPXD.CFG"
    return cfg_sso_domain

def compareMachineID():
    """
    Compare the machine ID with the machine ID in the vpxd.cfg file.

    Returns a dictionary with the following keys:
        - title (str): The title of the machine ID check.
        - details (str): Additional details about the check.
        - result (str): The result of the machine ID check ('PASS' or 'FAIL').
        - documentation (str): A URL to additional documentation.

    Raises:
        None.

    Requires:
        - The function getMachineIdFromVpxdCfg() which retrieves the machine ID from the vpxd.cfg file.

    Returns:
        dict: A dictionary containing the result of the machine ID check.
    """    
    title = "Machine ID Check"
    vpxd_mid = getMachineIdFromVpxdCfg()
    result = "PASS"
    details = ""
    documentation = ""

    if "FAILED" in vpxd_mid:
        result = 'FAIL'
        details = "Failed to process the vpxd.cfg file!  Investigate the invalid XML"
        documentation = "https://knowledge.broadcom.com/external/article/345089"
    
    elif machine_id != vpxd_mid:
        result = "FAIL"
        rec_cmd = "/usr/lib/vmware-vmafd/bin/vmafd-cli set-machine-id --server-name localhost --id %s" % vpxd_mid
        details = "Machine ID doesn't match vpxd.cfg\n  Current MID: %s\n  Correct MID: %s\n  Recommended command (service restart required): \n\t%s" % (
        machine_id, vpxd_mid, rec_cmd)
        documentation = "https://knowledge.broadcom.com/external/article/322198"

    else:
        logger.debug("Machine ID matches vpxd solution user in vpxd.cfg")

    return {'title': title, 'details': details, 'result': result, 'documentation': documentation}

def compareSsoDomain():
    """
    Compare the machine ID with the machine ID in the vpxd.cfg file.

    Returns a dictionary with the following keys:
        - title (str): The title of the machine ID check.
        - details (str): Additional details about the check.
        - result (str): The result of the machine ID check ('PASS' or 'FAIL').
        - documentation (str): A URL to additional documentation.

    Raises:
        None.

    Requires:
        - The function getMachineIdFromVpxdCfg() which retrieves the machine ID from the vpxd.cfg file.

    Returns:
        dict: A dictionary containing the result of the machine ID check.
    """    
    title = "vpxd.cfg SSO Domain Check"
    vpxd_domain = getSsoDomainFromVpxdCfg().lower()
    result = "PASS"
    details = ""
    documentation = ""

    if "FAILED" in vpxd_domain:
        result = 'FAIL'
        details = "Failed to process the vpxd.cfg file!  Investigate the invalid XML"
        documentation = "https://knowledge.broadcom.com/external/article/345089"
    
    elif vpxd_domain.lower() != sso_domain.lower():
        result = "FAIL"
        details = f"""Expected: {sso_domain}, Actual: {vpxd_domain}

There is a mismatch in the SSO domain configured for the vpxd solution user in the vpxd.cfg file.
This could be due to a recent domain repoint, or a manual typo in the file.  
Follow the steps in the KB to correct the entry in vpxd.cfg."""
        documentation = "https://knowledge.broadcom.com/external/article/344940"

    else:
        logger.debug("SSO domain for vpxd solution user in vpxd.cfg matches current SSO domain name.")

    return {'title': title, 'details': details, 'result': result, 'documentation': documentation}

def run_lscheck():
    """
    Run the lscheck command and generate a report.

    Returns:
        str: The generated report.

    Raises:
        None.
    """    
    ls_report = lsReport()
    return ls_report.generateReport()

def run_machine_id_check():
    """
    Run machine ID check and return the result.

    Returns:
        bool: Result of the machine ID check.
    """    
    return compareMachineID()

def run_sso_domain_check():
    """
    Run vpxd.cfg SSO domain check and return the result.

    Returns:
        bool: Result of the sso domain check.
    """ 
    return compareSsoDomain()
