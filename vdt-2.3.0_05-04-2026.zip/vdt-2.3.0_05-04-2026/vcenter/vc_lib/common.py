import sys
import os
import threading
import shlex
import re
import json
import subprocess as subproc
import logging
import ssl
import socket
import time
import ldap3 as ldap
import psycopg2
import sqlite3
import atexit
from ldap3 import LEVEL, BASE, SUBTREE
from datetime import datetime
sys.path.append(os.environ['VMWARE_PYTHON_PATH'])
from OpenSSL.crypto import (load_certificate)
from OpenSSL.crypto import (TYPE_DSA, TYPE_RSA, FILETYPE_PEM)
from cis.vecs import *
try:
    # Python 3 hack.
    import urllib.request as urllib2
    import urllib.parse as urlparse
except ImportError:
    import urllib2
    import urlparse

_DefaultCommmandEncoding = sys.getfilesystemencoding()

logger = logging.getLogger(__name__)


def run_command(cmd, stdin=None, encoding=_DefaultCommmandEncoding):
    """
    Run a command in a subprocess and return the output.

    Args:
        cmd (list): A list of command and arguments to run.
        stdin (str, optional): Standard input for the command. Defaults to None.
        encoding (str, optional): The encoding to use for the input. Defaults to the default command encoding.

    Returns:
        bytes: The output of the command as bytes.

    Raises:
        subprocess.CalledProcessError: If the command returns a non-zero exit status.
        subprocess.TimeoutExpired: If the command times out.
    """    
    process = subproc.Popen(cmd, stdout=subproc.PIPE,
                               stderr=subproc.PIPE, stdin=subproc.PIPE)
    if sys.version_info[0] >= 3 and isinstance(stdin, str):
        stdin = stdin.encode(encoding)
    stdout, stderr = process.communicate(stdin)
    if not stdout:
        logger.error(stderr.decode())
        sys.exit(1)
    return stdout


def get_oauth_identity_sources(ldap_connection):
    
    identity_sources_list = []
    domain_dn = ldap_connection.base_dn
    ldap_attributes = ['vmwSTSTrustedDomain', 'vmwSTSName', 'vmwSTSConnectionStrings']

    base_dn = f"cn=VCIdentityProviders,cn={ldap_connection.sso_domain},cn=Tenants,cn=IdentityManager,cn=Services,{domain_dn}"
    ldap_filter = f"(objectclass=vmwSTSExternalIdp)"
    result = ldap_connection.reuse_search(base_dn, ldap_filter, ldap_attributes, "SUBTREE")
    if result:
        for entry in result:
            result = dict()
            result['type'] = entry.vmwSTSName
            result['domain_name'] = entry.vmwSTSTrustedDomain
            identity_sources_list.append(result)
            # print(f"Identity source: type={entry.vmwSTSName}, domain={entry.vmwSTSTrustedDomain}")

    return identity_sources_list


def get_all_identity_sources(username,password):
    """
    Get the identity sources settings

    return: list of configured identity source represented in the following dict object:
    {
        "type": one of ('AD over LDAP', 'ADFS', 'OpenLDAP')
        "domain_name": domain name
        "certificates": CA certificate for this identity source
    }
    """
    search_list = [
        ('AD over LDAP', 'IdentityProviders', 'IDENTITY_STORE_TYPE_LDAP_WITH_AD_MAPPING'),
        ('ADFS', 'VCIdentityProviders', 'IDENTITY_STORE_TYPE_LDAP_WITH_AD_MAPPING'),
        ('OpenLDAP', 'IdentityProviders', 'IDENTITY_STORE_TYPE_LDAP')
    ]

    identity_sources_list = []


    ldap_connection = LDAPOps(username,password)
    domain_dn = ldap_connection.base_dn
    ldap_attributes = ['vmwSTSDomainName', 'userCertificate', 'vmwSTSConnectionStrings']
    for type_name, provider_cn, provider_type in search_list:

        base_dn = f"cn={provider_cn},cn={ldap_connection.sso_domain},cn=Tenants,cn=IdentityManager,cn=Services,{domain_dn}"
        ldap_filter = f"(&(objectclass=vmwSTSIdentityStore)(vmwSTSProviderType={provider_type}))"
        # ldap_filter = f"(vmwSTSProviderType={provider_type})"
        result = ldap_connection.reuse_search(base_dn, ldap_filter, ldap_attributes, "SUBTREE")
        if not result:
            # print(f"Didn't find {base_dn}")
            continue
        else:
            # print(f"Found DN: {base_dn}")
            for entry in result:
                result = dict()
                result['type'] = type_name
                result['domain_name'] = entry.vmwSTSDomainName
                result['connection_string'] = entry.vmwSTSConnectionStrings
                certs = []
                for cert in entry.userCertificate:
                    # only expect single certificate
                    certs.append(ssl.DER_cert_to_PEM_cert(cert))
                
                if len(certs) > 0 and type_name == 'AD over LDAP':
                    result['type'] = 'AD over LDAPS'
                
                result['certificates'] = certs
                identity_sources_list.append(result)
                # print("Identity source: type={}, domain={}".format(type_name, result['domain_name']))
    
    oauth_sources = get_oauth_identity_sources(ldap_connection)
    # print("Got oauth sources.")
    if oauth_sources:
        identity_sources_list.extend(oauth_sources)
        # print("extended id source list result")
    ldap_connection.close()

    return [x for x in identity_sources_list if x]


def get_iwa_sources():
    providers = []
    cmd = ['/opt/vmware/bin/sso-config.sh', 'get_identity_sources']
    output, errors, timeout = Command(cmd).run()


    id_sources = re.split('^.*IDENTITY SOURCE INFORMATION.*$', output,0, re.MULTILINE)
    for x in id_sources:
        if 'providerType' in x:
            for line in x.splitlines():
                if 'IdentitySourceName' in line:
                    source_name = line.split(':')[1].strip()
                if 'providerType' in line:
                    source_type = line.split(':')[1].strip()
            if 'KERBEROS' in source_type:
                source_type = 'IWA (Kerberos)'
                return {'domain_name': source_name, 'type': source_type}
            # providers.append(f"- Name: {source_name}, Type: {source_type}")

    return None


class RunCommand(object):
    # Based on jcollado's solution:
    # http://stackoverflow.com/questions/1191374/subprocess-with-timeout/4825933#4825933
    """
    A class representing a command to be executed.

    Attributes:
        cmd (str or list): The command to be executed. If a string, it will be split into a list of arguments.
        stdin (str): The input to be passed to the command's standard input.
        quiet (bool): If True, suppresses the output of the command.
        close_fds (bool): If True, closes all file descriptors before executing the command.
        encoding (str): The encoding to be used for the input and output of the command.
        shell (bool): If True, runs the command through the shell.
        response (str): The response to be passed to the command's standard input.
        command_timeout (int): The maximum time in seconds to wait for the command to complete.
    """
    def __init__(self, cmd, stdin=None, quiet=False, close_fds=False, encoding=_DefaultCommmandEncoding, shell=False,
                 response=None):
        """
        Initialize a Command object.

        Args:
            cmd (str or list): The command to execute. If it is a string, it will be split into a list of arguments.
            stdin (str or None): Input to be passed to the subprocess.
            quiet (bool): Flag indicating whether to suppress output from the subprocess.
            close_fds (bool): Flag indicating whether to close all file descriptors except stdin, stdout, and stderr.
            encoding (str): The character encoding to be used for the subprocess.
            shell (bool): Flag indicating whether the command should be executed through the shell.
            response (str or None): Output of the subprocess command.
            command_timeout (int): Timeout value in seconds for the command execution.

        Raises:
            None

        Returns:
            None
        """
        self.shell = shell
        self.stdin = stdin
        self.encoding = encoding
        try:
            if isinstance(cmd, basestring):
                cmd = shlex.split(cmd)
        except:
            if isinstance(cmd, str):
                cmd = shlex.split(cmd)
        self.cmd = cmd
        self.process = None
        self.error = None
        self.response = response

    def run(self):
        """
        Executes a command with optional input and captures the output and error streams.

        Raises an error if the Python version is less than 3 or the input stream is not a string.

        Returns:
            Tuple[str, str, bool]: A tuple containing the command output as a string, the error message as a string.

        Raises:
            TypeError: If the Python version is less than 3 or the input stream is not a string.
        """
        if sys.version_info[0] >= 3 and isinstance(self.stdin, str):
            self.stdin = self.stdin.encode(self.encoding)
        if self.response:
            self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=subproc.PIPE,
                                         shell=self.shell)
            self.process.stdin.write(self.response.encode(self.encoding))
        else:
            self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=self.stdin,
                                         shell=self.shell)
        self.output, self.error = self.process.communicate(self.stdin)

        return self.output.decode('utf-8'), self.error.decode('utf-8')


class FailedCommand(Exception):
    """
    Helps when handling command failures.
    """

    def __init__(self, cmd, error, msg="Command failed!"):
        """
        Initialize a CommandError instance.

        Args:
            cmd (str): The command that failed.
            error (str): The specific error message related to the failure.
            msg (str, optional): The custom error message to display. Defaults to 'Command failed!'.

        Raises:
            None.

        Returns:
            None.
        """        
        self.cmd = cmd
        self.error = error
        self.msg = msg
        super().__init__(self.msg)


class Command(object):
    # Based on jcollado's solution:
    # http://stackoverflow.com/questions/1191374/subprocess-with-timeout/4825933#4825933
    """
    A class representing a command to be executed.

    Attributes:
        cmd (str or list): The command to be executed. If a string, it will be split into a list of arguments.
        stdin (str): The input to be passed to the command's standard input.
        quiet (bool): If True, suppresses the output of the command.
        close_fds (bool): If True, closes all file descriptors before executing the command.
        encoding (str): The encoding to be used for the input and output of the command.
        shell (bool): If True, runs the command through the shell.
        response (str): The response to be passed to the command's standard input.
        command_timeout (int): The maximum time in seconds to wait for the command to complete.
    """    
    def __init__(self, cmd, stdin=None, quiet=False, close_fds=False, encoding=_DefaultCommmandEncoding, shell=False,
                 response=None, command_timeout=30):
        """
        Initialize a Command object.

        Args:
            cmd (str or list): The command to execute. If it is a string, it will be split into a list of arguments.
            stdin (str or None): Input to be passed to the subprocess.
            quiet (bool): Flag indicating whether to suppress output from the subprocess.
            close_fds (bool): Flag indicating whether to close all file descriptors except stdin, stdout, and stderr.
            encoding (str): The character encoding to be used for the subprocess.
            shell (bool): Flag indicating whether the command should be executed through the shell.
            response (str or None): Output of the subprocess command.
            command_timeout (int): Timeout value in seconds for the command execution.

        Raises:
            None

        Returns:
            None
        """        
        self.shell = shell
        self.stdin = stdin
        self.encoding = encoding
        try:
            if isinstance(cmd, basestring):
                cmd = shlex.split(cmd)
        except:
            if isinstance(cmd, str):
                cmd = shlex.split(cmd)
        self.cmd = cmd
        self.process = None
        self.error = None
        self.response = response
        self.command_timeout = command_timeout

    def run(self):
        """
        Run a command and return the output, error, and timeout status.

        Returns:
            Tuple[str, str, bool]: A tuple containing the command output as a string, the error message as a string, and a boolean indicating if the command timed out.

        Raises:
            None.
        """        
        timedout = False

        def target():
            """
            Executes a command with optional input and captures the output and error streams.

            Raises an error if the Python version is less than 3 or the input stream is not a string.

            Args:
                None

            Returns:
                None

            Raises:
                TypeError: If the Python version is less than 3 or the input stream is not a string.
            """            
            if sys.version_info[0] >= 3 and isinstance(self.stdin, str):
                self.stdin = self.stdin.encode(self.encoding)
            if self.response:
                self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=subproc.PIPE,
                                             shell=self.shell)
                self.process.stdin.write(self.response.encode(self.encoding))
            else:
                self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=self.stdin,
                                             shell=self.shell)
            self.output, self.error = self.process.communicate(self.stdin)

        thread = threading.Thread(target=target)
        thread.start()
        thread.join(self.command_timeout)
        if thread.is_alive():
            self.process.terminate()
            thread.join()
        if self.process.returncode != 0:
            if len(self.error.decode()) <= 0:
                timedout = True

        return self.output.decode('utf-8'), self.error.decode('utf-8'), timedout


class RegValueNotFound(Exception):
    """Exception raised when a requested registry value is not found in the database."""
    pass


class CertNotFound(Exception):
    """Exception raised when a specific certificate alias cannot be found in a store."""
    pass


class StoreNotFound(Exception):
    """Exception raised when a requested VECS store does not exist."""
    pass


class AfdDB(object):
    """
    Interface for interacting with the Likewise registry database.

    Attributes:
        con (sqlite3.Connection): The connection object to the registry database.
        cur (sqlite3.Cursor): The cursor object for executing SQL commands.
    """
    def __init__(self):
        """Initializes the connection to the Likewise registry database and registers a cleanup handler."""
        logger.debug("Accessing LW database (/var/lib/likewise/db/registry.db)")
        self.con = sqlite3.connect('/var/lib/likewise/db/registry.db')
        self.cur = self.con.cursor()
        atexit.register(self.close_conn, self.con, self.cur)
    
    def get_reg_value_search(self, valuename) -> list:
        """
        Retrieves and decodes multiple registry values.

        Args:
            valuename (str): The name of the registry value to look up.
                Allows fuzzy search.

        Returns:
            list: list of dictionaries containing values {str: (int or str)}: 
                The decoded value. Returns an integer if the type is 4 (DWORD), 
                otherwise returns a UTF-16 decoded string.

        """
        results = []
        query = f"SELECT ValueName, Type, Value FROM regvalues1 WHERE ValueName LIKE '{valuename}';"
        allresults = self.cur.execute(query).fetchall()
        for result in allresults:
            if result:
                val_name, val_type, output = result
                if val_type == 4:
                    value = int.from_bytes(output, byteorder='little')
                else:
                    value = output.decode('utf-16').replace('\x00', '')
                results.append({val_name: value})
            else:
                continue
        return results
    
    def get_reg_value(self, valuename):
        """
        Retrieves and decodes a registry value by its name.

        Args:
            valuename (str): The name of the registry value to look up.

        Returns:
            int or str: The decoded value. Returns an integer if the type is 4 (DWORD), 
                otherwise returns a UTF-16 decoded string.

        Raises:
            RegValueNotFound: If the valuename does not exist in the database.
        """
        logger.debug(f"Getting registry value: {valuename}")
        query = f"SELECT Type, Value FROM regvalues1 WHERE ValueName LIKE '{valuename}';"
        result = self.cur.execute(query).fetchone()
        if result:
            val_type, output = result
            if val_type == 4:
                return int.from_bytes(output, byteorder='little')
            else:
                return output.decode('utf-16').replace('\x00','')
        else:
            raise RegValueNotFound(f"Could not find registry value '{valuename}'!")
           
    def rhttpproxy_port(self):
        """Retrieves the RHTTPProxyPort value."""
        return self.get_reg_value('RHTTPProxyPort')

    def ls_location(self):
        """
        Constructs the Lookup Service (LS) SDK URL.

        Returns:
            str: The full LS SDK URL (https://<DC>:<Port>/lookupservice/sdk).
        """
        dc_name = self.get_reg_value('AffinitizedDC')
        return f"https://{dc_name}:{self.rhttpproxy_port()}/lookupservice/sdk"
    
    def sso_domain(self):
        """Retrieves the SSO Domain Name."""
        return self.get_reg_value('DomainName')
    
    def pnid(self):
        """Retrieves the Primary Network ID (PNID)."""
        return self.get_reg_value('PNID')
    
    def sso_site(self):
        """Retrieves the SSO Site Name."""
        return self.get_reg_value('SiteName')
    
    def machine_id(self):
        """Retrieves the Machine GUID."""
        return self.get_reg_value('MachineGuid')
    
    def node_id(self):
        """Retrieves the LDU (Node) GUID."""
        return self.get_reg_value('LduGuid')

    @staticmethod
    def close_conn(con, cur):
        """
        Closes the database cursor and connection. Called automatically at exit.

        Args:
            con (sqlite3.Connection): The connection to close.
            cur (sqlite3.Cursor): The cursor to close.
        """
        cur.close()
        con.close()


class VecsDB(object):
    """
    Interface for interacting with the vSphere Endpoint Certificate Store (VECS).

    Attributes:
        con (sqlite3.Connection): The connection object to the afd database.
        cur (sqlite3.Cursor): The cursor object for executing SQL commands.
    """

    def __init__(self):
        """Initializes the connection to the VMAFD database and registers a cleanup handler."""
        self.con = sqlite3.connect('/storage/db/vmware-vmafd/afd.db')
        self.cur = self.con.cursor()
        atexit.register(self.close_conn, self.con, self.cur)

    def get_store_id(self, storename):
        """
        Retrieves the internal StoreID for a given store name.

        Args:
            storename (str): The name of the certificate store.

        Returns:
            int: The unique StoreID.

        Raises:
            StoreNotFound: If the store name is not found in StoreTable.
        """
        query = f"SELECT StoreID FROM StoreTable WHERE StoreName LIKE '{storename}';"
        result = self.cur.execute(query).fetchone()
        if result:
            return result[0]
        else:
            raise StoreNotFound(f"No store with store name '{storename}' found!")
    
    def list_vecs_stores(self):
        """
        Lists all available VECS stores.

        Returns:
            list[str]: A list of all StoreNames in the database.
        """
        results = []
        query = f"SELECT StoreName FROM StoreTable;"
        for item in self.cur.execute(query).fetchall():
            results.append(item[0])
        return results
    
    def get_cert_from_store(self, storename, alias):
        """
        Retrieves a specific certificate from a store by its alias.

        Args:
            storename (str): The name of the store.
            alias (str): The alias of the certificate.

        Returns:
            str: The pem certificate decoded from UTF-16 with null terminators removed.

        Raises:
            CertNotFound: If the alias does not exist in the specified store.
        """
        storeid = self.get_store_id(storename)
        query = f"SELECT CertBlob FROM CertTable WHERE StoreID = '{storeid}' AND Alias = '{alias}';"
        result = self.cur.execute(query).fetchone()
        if result:
            return result[0].decode('utf-16').replace("\x00","")
        else:
            raise CertNotFound(f"Cert alias '{alias}' not found in store '{storename}'!")

    def get_cert_count_from_store(self, storename):
        """
        Counts the number of certificates in a specific store.

        Args:
            storename (str): The name of the store.

        Returns:
            int: The number of certificates in that store.
        """
        storeid = self.get_store_id(storename)
        query = f"SELECT * FROM CertTable WHERE StoreID = {storeid};"
        return len([x for x in self.cur.execute(query).fetchall()])
    
    def list_certs_in_store(self, storename):
        """
        Returns a mapping of all certificate aliases and their certs for a given store.

        Args:
            storename (str): The name of the store to query.

        Returns:
            dict: A nested dictionary in the format {storename: {alias: cert}}.
        """
        storeid = self.get_store_id(storename)
        storemap = {storename: {}}
        query = f"SELECT * FROM CertTable WHERE StoreID = {storeid};"
        for cert in self.cur.execute(query).fetchall():
            cert_data = {}
            for i in range(len(cert)):
                cert_data[self.cur.description[i][0]] = cert[i]
            storemap[storename][cert_data['Alias']] = cert_data['CertBlob'].decode('utf-16').replace("\x00","")
        return storemap
        
    def list_aliases_in_store(self, storename):
        """
        Lists all certificate aliases within a specific store.

        Args:
            storename (str): The name of the store.

        Returns:
            list[str]: A list of certificate aliases.
        """
        return [x.get('alias') for x in self.list_certs_in_store(storename)]
    
    def get_all_certs(self, ignore_list=None):
        """
        Retrieves every certificate from every store in the database.

        Returns:
            dict: A mapping of all stores and their associated certificates.
        """
        results = {}
        for store in self.list_vecs_stores():
            if store in ignore_list:
                continue
            results.update(self.list_certs_in_store(store))
        return results

    @staticmethod
    def close_conn(con, cur):
        """
        Closes the database cursor and connection. Called automatically at exit.

        Args:
            con (sqlite3.Connection): The connection to close.
            cur (sqlite3.Cursor): The cursor to close.
        """
        cur.close()
        con.close()


def psqlPythonQueryWithPassword(query, password, sqluser='postgres'):
    """
    Executes a SQL query on a local PostgreSQL database and returns all results.

    Connects to the 'VCDB' database on localhost using the provided credentials,
    executes the specified query, and fetches all resulting rows. Ensures that 
    the cursor and connection are closed regardless of success or failure.

    Args:
        query (str): The SQL query string to be executed.
        password (str): The password for the PostgreSQL user.
        sqluser (str, optional): The PostgreSQL username. Defaults to 'postgres'.

    Returns:
        list of tuples: A list containing all rows fetched from the query result.

    Raises:
        Exception: If a connection error occurs or the SQL execution fails.
    """
    
    try:
        # Connect to an existing database
        connection = psycopg2.connect(user=sqluser,
                                    password=password,
                                    host="127.0.0.1",
                                    port="5432",
                                    database="VCDB")

        # Create a cursor to perform database operations
        cursor = connection.cursor()
        cursor.execute(query)
        
        # Fetch result
        record = cursor.fetchall()

        return record

    except Exception as error:
        raise Exception(f"\tError while connecting to PostgreSQL!\n{error}")
    finally:
        if (connection):
            cursor.close()
            connection.close()


def psqlQuery(query, return_all=False):
    """
    Run a PostgreSQL query and return the output.

    Args:
        query (str): The SQL query to be executed.
        return_all (bool, optional): If True, return all output. If False, return only the third line of the output. 
                                     Defaults to False.

    Returns:
        str: The output of the query.

    Raises:
        Exception: If there is an error executing the query or if the vPostgres service is not available.
    """    
    logger.debug("running SQL query: %s" % query)
    psqlpath = "/opt/vmware/vpostgres/current/bin/psql"
    cmd = [psqlpath, '-d', 'VCDB', 'postgres', '-c', query]
    try:
        output, errors, timeout = Command(cmd).run()
        if return_all:
            return output
        else:
            output = output.split('\n')[2]
            return output.strip()
    except:
        msg = "Requires vPostgres service!"
        return msg
    

def psqlQueryAsUser(osuser, query, sqluser='postgres',return_all=False):
    """
    Run a PostgreSQL query and return the output.

    Args:
        query (str): The SQL query to be executed.
        return_all (bool, optional): If True, return all output. If False, return only the third line of the output. 
                                     Defaults to False.

    Returns:
        str: The output of the query.

    Raises:
        Exception: If there is an error executing the query or if the vPostgres service is not available.
    """    
    logger.debug("running SQL query: %s" % query)
    psqlpath = "/opt/vmware/vpostgres/current/bin/psql"
    cmd = ['sudo','-u',osuser, psqlpath, '-d', 'VCDB', '-U', sqluser, '-c', query]
    try:
        output, errors, timeout = Command(cmd).run()
        
    except:
        msg = "Requires vPostgres service!"
        return msg
    
    if 'FATAL' in errors:
        raise Exception(f"Failed to run PSQL command.  Error was: {errors}")
    
    if return_all:
        return output
    
    else:
        output = output.split('\n')[2]
        return output.strip()


def psqlQueryWithPassword(query, password, sqluser='postgres', return_all=False):
    """
    Run a PostgreSQL query and return the output.

    Args:
        query (str): The SQL query to be executed.
        return_all (bool, optional): If True, return all output. If False, return only the third line of the output. 
                                     Defaults to False.

    Returns:
        str: The output of the query.

    Raises:
        Exception: If there is an error executing the query or if the vPostgres service is not available.
    """    
    logger.debug("running SQL query: %s" % query)
    psqlpath = "/opt/vmware/vpostgres/current/bin/psql"
    cmd = [psqlpath, '-d', 'VCDB', '-U', sqluser, '-c', query]
    cmd_concat = " ".join(cmd)
    try:
        output, errors, timeout = Command(cmd, response=password).run()

    except:
        msg = "Requires vPostgres service!"
        return msg
    
    if 'FATAL' in errors:
        raise Exception(f"Failed to run PSQL command.  Error was: {errors}")
    
    if return_all:
        return output
        
    else:
        output = output.split('\n')[2]
        return output.strip()
    

def getStartup(service):
    """
    Get the startup type of a service.

    Args:
        service (str): The name of the service.

    Returns:
        str: The startup type of the service.

    Raises:
        Exception: If an error occurs while retrieving the startup type.
    """    
    result = ""
    logger.debug("Getting startup type of service %s" % service)
    if 'vmware-' in service and 'postgres' not in service and 'sts' not in service:
        service = service.replace('vmware-', '')
        if 'watchdog' in service:
            service = service.replace('-watchdog', '')
    try:
        result = str(getSrvStartType(service, quiet=True))
    except:
        result = "Automatic"
    if not result:
        result = "Automatic"
    logger.debug(result)
    return result


def getMultiServiceStatus(svcs=None):
    """
    Get the status of multiple services.

    Args:
        svcs (list, optional): A list of service names. Defaults to None.

    Returns:
        dict: A dictionary containing the status of each service.

    Raises:
        None.
    """    
    svcslist = ' '.join(svcs)
    logger.debug("Getting startup type of service %s" % svcslist)
    result = get_services_status(svcs)
    logger.debug(result)
    return result


def getSingleServiceStatus(service):
    """
    Get the status of a single service.

    Args:
        service (str): The name of the service.

    Returns:
        bool: True if the service is running, False otherwise.
    """    
    logger.debug("Getting status of service %s" % service)
    for x, y in get_services_status([service]).items():
        if len(y) == 2:
            status = y[0]
        else:
            status = y
    logger.debug(status)
    if status == 'RUNNING':
        return True
    else:
        return False


class CheckConnect(object):

    """
    A class for checking connectivity to a host on specific ports.

    Attributes:
        retry (int): The number of times to retry the connection check.
        delay (int): The number of seconds to wait between connection attempts.
        timeout (int): The timeout value in seconds for the connection attempt.
        ip (str): The IP address of the host to check.
        ports (list or int): The list of ports to check or a single port number.
        ptype (str): The type of protocol to use for the connection check.
        init_msg (str): The initial message for the connection check.

    Methods:
        TCP(port): Checks the TCP connectivity to the specified port.
        check(): Performs the connection check for all the specified ports.
    """    
    def __init__(self, ip, ports):
        #  Spec will be yaml parameters specific to the product
        """
        Initialize a PortChecker object.

        Args:
            ip (str): The IP address of the host to perform port checks on.
            ports (int or list): The port or list of ports to check on the host.

        Attributes:
            retry (int): The number of times to retry a failed port check.
            delay (int): The delay in seconds between retries.
            timeout (int): The timeout in seconds for each port check.
            ip (str): The IP address of the host to perform port checks on.
            ports (list): A list of ports to check on the host.
            ptype (str): The type of port check to perform.
            init_msg (str): The initialization message for the PortChecker object.
        """        
        self.retry = 1
        self.delay = 1
        self.timeout = 2
        self.ip = ip
        if isinstance(ports, int):
            self.ports = [ports]
        if isinstance(ports, list):
            self.ports = ports
        self.ptype = "TCP"

        self.init_msg = "Port check for host %s" % self.ip

    def TCP(self, port):
        """
        Test TCP connection on a specified port.

        Args:
            port (int): The port number to test the TCP connection.

        Returns:
            tuple: A tuple containing the return code (0 if successful, 1 if failed) and a message describing the test result.
        """        
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(self.timeout)
        rc = 1
        try:
            response = s.connect((self.ip, int(port)))
            s.shutdown(socket.SHUT_RDWR)
            s.close()
            result = "tcp port test returned %s" % response
            logger.debug(result)
            rc = 0
        except Exception as e:
            result = "tcp port test failed. error was: %s" % e
            logger.debug(result)
        return rc, result

    def check(self):
        """
        Performs a TCP check on a list of ports.

        Returns a tuple of a success flag and a dictionary containing the result of each port check.

        Args:
            self: An instance of the class that this method is a part of.

        Returns:
            tuple: A tuple containing a boolean indicating whether all the checks were successful, and a dictionary that maps each checked port to its result ('success' or 'failed').
        """        
        output = {}
        success = True
        for port in self.ports:
            listening = False
            for attempt in range(self.retry):
                rc, result = self.TCP(port)
                if rc == 0:
                    listening = True
                    break
                else:
                    time.sleep(self.delay)
            if listening:
                output[str(port)] = "success"
            else:
                output[str(port)] = "failed"
                success = False
        return success, output


def sanitize_data(item, **kwargs):
    """
    Remove problematic characters from data
    :param item: data to process
    :type item: string or bytes object, list or dict
    :return: data suitable for printing as 'utf-8'
    :rtype: string
    All ANSI escapes, does not work on non-ansii escapes (use strict)
      re.compile(r'(\x9b|\x1b\[)[0-?]*[ -\/]*[@-~]')  # Includes colours
    Colors only
        re.compile(r'\x1b\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K]') # Colours only
    Colours ok, all other escapes removed (above combined)
      re.compile(r'(?!\x1b\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K])((\x9b|\x1b\[)[0-?]*[ -\/]*[@-~])')
    Strict, only [a-zA-Z0-9] and common punctuation
        re.compile(r'[^\x20-\x7e]+')
    """
    if kwargs.get('strict', False):
        # Strict, only [a-zA-Z0-9] and common punctuation
        re_applied = re.compile(r'[^\x20-\x7e]+')
    elif kwargs.get('wizard', False):
        # Return only alphanumeric and '_'
        re_applied = re.compile(r'[^0-9a-zA-Z_]+')
        return re_applied.sub('', item)
    else:
        # Colours ok, all other escapes removed
        re_applied = re.compile(r'(?!\x1b\[([0-9]{1,2}(;[0-9]{1,2})?)?[m|K])((\x9b|\x1b\[)[0-?]*[ -/]*[@-~])')

    if isinstance(item, dict) or isinstance(item, list):
        return item
    if isinstance(item, bytes):
        item = item.decode('utf-8', 'ignore').strip()
    if isinstance(item, str):
        item = re_applied.sub('.', item)
        superfluous_newlines = re.compile(r'\n\s*\n')
        item = superfluous_newlines.sub('\n', item)
        return item
    else:
        return None


def getSslCert(hostname, port=443):
    """
    Gets SSL cert from host on port specified. Converts to
    string compatible with LS specs.

    Args:
        hostname (str): The hostname.
        port (int): The port.

    Returns:
        cert: The certificate string formatted for lookup service endpoints.
    """
    #  returns the cert trust value formatted for lstool
    logger.debug("Getting SSL certificate on %s:%s" % (hostname, port))
    socket.setdefaulttimeout(5)
    try:
        try:
            cert = ssl.get_server_certificate((hostname, port), ssl_version=ssl.PROTOCOL_TLS)

        except AttributeError:
            cert = ssl.get_server_certificate((hostname, port), ssl_version=ssl.PROTOCOL_SSLv23)

        except socket.timeout as e:
            raise Exception("Timed out getting certificate")

        except ConnectionRefusedError:
            # print("Connection refused while getting cert for host %s on port %s!" % (hostname, port))
            raise

        values = ['-----BEGIN CERTIFICATE-----', '-----END CERTIFICATE-----', '\n']

        for i in values:
            cert = cert.replace(i, '')
        logger.debug("Got certificate.")
        return cert

    except Exception as e:
        msg = ("[%s:%s]:%s"
               % (hostname, port, str(e)))
        raise Exception(msg)


class LDAPOps(object):

    """
    A class representing LDAP operations.

    Attributes:
        ldap_server_url (str): The URL of the LDAP server.
        server (ldap.Server): The LDAP server object.
        base_dn (str): The base DN (Distinguished Name) for the LDAP server.
        user (str): The LDAP user.
        password (str): The password for the LDAP user.
        connection (ldap.Connection): The connection to the LDAP server.
    """    
    def __init__(self, username, password):
        """
        Initialize an LDAP connection object.

        Args:
            username (str): The username for the LDAP connection.
            password (str): The password for the LDAP connection.

        Raises:
            Exception: If the LDAP connection fails.

        Attributes:
            ldap_server_url (str): The URL of the LDAP server.
            server (ldap.Server): The LDAP server object.
            base_dn (str): The base distinguished name for the LDAP search.
            user (str): The user distinguished name for the LDAP connection.
            password (str): The password for the LDAP connection.
            connection (ldap.Connection): The LDAP connection object.
        """        
        from vcenter.vc_cfg.current_defaults import sso_domain
        self.ldap_server_url = 'ldap://localhost:389'
        self.server = ldap.Server(self.ldap_server_url, get_info=ldap.ALL)
        self.sso_domain = sso_domain
        base_dn_convert = sso_domain.split('.')
        self.base_dn = f"dc={',dc='.join(base_dn_convert)}"
        if "administrator" in username.lower():
            self.user = 'CN=' + username.split('@')[0] + ',cn=Users,' + self.base_dn
        else:
            self.user = 'CN=' + username.split('@')[0] + ',ou=Domain Controllers,' + self.base_dn
        self.password = password
        try:
            self.connection = ldap.Connection(self.server,
                                              user=self.user,
                                              password=self.password,
                                              auto_bind=True,
                                              auto_encode=False)
        except Exception as e:
            logger.error('open ldap connection failed: {0}'.format(e))
            raise e
    
    def close(self):

        """
        Close the LDAP connection.

        Raises:
            Exception: If closing the connection fails.
        """        
        try:
            self.connection.unbind()
            # if self.connection.result["result"] != 0:
            #     logger.error("Error closing connection. Error Msg: " +
            #           self.connection.result["message"])
        except Exception as e:
            logger.error('close ldap connection failed: {0}'.format(e))
            raise e
    
    def reuse_search(self, base_dn, ldap_filter, ldap_attributes=None, search_level=None):
        """
        Searches for entries in LDAP database based on provided parameters.

        Args:
            base_dn (str): The base distinguished name (DN) for the LDAP search.
            ldap_filter (str): The filter string for the LDAP search.
            ldap_attributes (list, optional): A list of attributes to include in the search result. Defaults to ['*'].
            search_level (str, optional): The search level for the LDAP search. Defaults to None.

        Returns:
            list: A list of entries found in the LDAP search.

        Raises:
            Exception: If any error occurs during the LDAP search or connection handling.
        """        
        if not base_dn:
            base_dn = self.base_dn
        if not ldap_attributes:
            ldap_attributes = ['*']
        
        if search_level == "SUBTREE":
            search_level = SUBTREE
        elif search_level == "LEVEL":
            search_level = LEVEL
        elif search_level == 'BASE':
            search_level = BASE
        else:
            search_level = None

        result = False
        try:
            if self.connection is None:
                logger.debug("No ldap connection")
            else:
                self.connection.bind()
                if search_level:
                    result = self.connection.search(base_dn,
                                                    ldap_filter,
                                                    attributes=ldap_attributes,
                                                    search_scope=search_level)
                else:
                    result = self.connection.search(base_dn,
                                                    ldap_filter,
                                                    attributes=ldap_attributes)
                # result = self.connection.search(base_dn,ldap_filter)
                if not result:
                    logger.debug("LDAP Search failed.Error Message: " +
                          self.connection.result["message"])
                else:
                    return self.connection.entries
        except Exception as e:
            logger.error('ldap search failed: {0}'.format(e))
            raise e
        # finally:
        #     try:
        #         self.connection.unbind()
        #         if self.connection.result["result"] != 0:
        #             logger.error("Error closing connection. Error Msg: " +
        #                   self.connection.result["message"])
        #     except Exception as e:
        #         logger.error('close ldap connection failed: {0}'.format(e))
        #         raise e
    
    def search(self, base_dn, ldap_filter, ldap_attributes=None, search_level=None):
        """
        Searches for entries in LDAP database based on provided parameters.

        Args:
            base_dn (str): The base distinguished name (DN) for the LDAP search.
            ldap_filter (str): The filter string for the LDAP search.
            ldap_attributes (list, optional): A list of attributes to include in the search result. Defaults to ['*'].
            search_level (str, optional): The search level for the LDAP search. Defaults to None.

        Returns:
            list: A list of entries found in the LDAP search.

        Raises:
            Exception: If any error occurs during the LDAP search or connection handling.
        """        
        if not base_dn:
            base_dn = self.base_dn
        if not ldap_attributes:
            ldap_attributes = ['*']
        
        if search_level == "SUBTREE":
            search_level = SUBTREE
        elif search_level == "LEVEL":
            search_level = LEVEL
        elif search_level == 'BASE':
            search_level = BASE
        else:
            search_level = None

        result = False
        try:
            if self.connection is None:
                logger.debug("No ldap connection")
            else:
                self.connection.bind()
                if search_level:
                    result = self.connection.search(base_dn,
                                                    ldap_filter,
                                                    attributes=ldap_attributes,
                                                    search_scope=search_level)
                else:
                    result = self.connection.search(base_dn,
                                                    ldap_filter,
                                                    attributes=ldap_attributes)
                # result = self.connection.search(base_dn,ldap_filter)
                if not result:
                    logger.debug("LDAP Search failed.Error Message: " +
                          self.connection.result["message"])
                else:
                    return self.connection.entries
        except Exception as e:
            logger.error('ldap search failed: {0}'.format(e))
            raise e
        finally:
            try:
                self.connection.unbind()
                if self.connection.result["result"] != 0:
                    logger.error("Error closing connection. Error Msg: " +
                          self.connection.result["message"])
            except Exception as e:
                logger.error('close ldap connection failed: {0}'.format(e))
                raise e


def get_trusted_roots_map(ca_list):

    cert_map = {'ROOTS': [], "INTERMEDIATES": [], "LEAFS": [], "UNKNOWN": []}
    
    for alias, root_cert in ca_list.items():

        if not root_cert:
            continue

        try:
            skid = root_cert.get("subjectkey")
            issuer = root_cert.get("issuer")
            subject = root_cert.get("subject")
            keyusage = root_cert.get("keyusage")
            rawcert = root_cert.get("raw_cert")
            authkey = root_cert.get("authkey")
            
            if authkey and "\n" in authkey:
                # Only really seen when using openssl CA on SDDC manager, keyID will have multiple lines
                authkey = authkey.split()[0].split(":", 1)[1].strip()
            
            cert_type = ""

            if keyusage and 'Certificate Sign' not in keyusage:
                cert_type = "LEAFS"
            elif authkey and root_cert.get("subjectkey") not in authkey:
                cert_type = "INTERMEDIATES"
            elif not authkey or subject == issuer:
                cert_type = "ROOTS"
            else:
                cert_type = "UNKNOWN"
            root_map = {
                "subject": subject,
                "skid": skid,
                "issuer": issuer,
                "keyusage": keyusage,
                "thumbprint": root_cert.get("thumbprint").replace(':','').lower(),
                "raw_cert": rawcert
            }
            cert_map[cert_type].append(root_map)
        except Exception as e:
            raise e
    return cert_map


def getCaTrustList():
    """
    Get the list of CA trust certificates.

    Returns:
        None

    Raises:
        None
    """    
    
    cert_client = VecsDB()
    ca_map = {}
    trusted_list = {}
    logger.debug("Getting CA trust list")

    certlist = cert_client.list_certs_in_store("TRUSTED_ROOTS")
    
    for alias, cert in certlist['TRUSTED_ROOTS'].items():
        parsed_cert = Cert(cert)
        trusted_list[alias] = parsed_cert.__dict__
    
    ca_map = get_trusted_roots_map(trusted_list)
    logger.debug(f"got trusted_root list: {trusted_list}")
    return trusted_list, ca_map     


class ChainValidationException(Exception):
    def __init__(self, messages, errors):
        super().__init__(messages)
        self.errors = errors
        self.message = messages


class parseCert(object):
    """
    This is a class that will parse a certificate into a dictionary of certificate information.

    Attributes:
        rawcert (TYPE): Description
        x509 (TYPE): Description
    """

    def __init__(self, certdata, file=True):
        """
        Args:
            certdata (TYPE): certificate data either string or file.
            file (bool, optional): flag telling us whether or not certdata is a file.
        """
        if file == True:
            self.built_cert = certdata
            # logger.debug(built_cert)
            self.x509 = load_certificate(FILETYPE_PEM, self.built_cert)
        else:

            if not 'BEGIN CERTIFICATE' in certdata:

                stringed_cert = re.sub("(.{64})", "\\1\n", certdata, 0, re.DOTALL)
                self.built_cert = "-----BEGIN CERTIFICATE-----\n" + stringed_cert + "\n" + "-----END CERTIFICATE-----"
                lines = '\n'.join([x for x in self.built_cert.split("\n") if x.strip() != ''])
                self.built_cert = lines
            else:
                self.built_cert = certdata
            try:
                self.x509 = load_certificate(FILETYPE_PEM, self.built_cert)
                self.rawcert = self.built_cert
            except Exception as e:
                raise e

    def decode(self, item, encoding):

        """
        Decode a string or bytes-like object using the specified encoding.

        Args:
            item (str or bytes): The string or bytes-like object to be decoded.
            encoding (str): The encoding to be used for decoding.

        Returns:
            str: The decoded string.

        Raises:
            UnicodeDecodeError: If the decoding process fails.
        """        
        try:
            return decode(item, encoding, errors='surrogateescape')
        except:
            return item.decode(encoding, errors='surrogateescape')

    def format_subject_issuer(self, x509name):

        """
        Create a formatted string representation of the subject/issuer of an X509Name object.

        Args:
            x509name (X509Name): An X509Name object representing the subject/issuer.

        Returns:
            str: A string representation of the subject/issuer, with each component formatted as "key=value".

        Note:
            The input X509Name object is expected to have components returned by the get_components() method.
        """        
        items = []
        for item in x509name.get_components():
            items.append('%s=%s' % (self.decode(item[0], 'utf-8'), self.decode(item[1], 'utf-8')))
        return ", ".join(items)

    def format_asn1_date(self, d):

        """
        Format an ASN.1 date string.

        Args:
            d (bytes): The ASN.1 date string encoded as bytes.

        Returns:
            str: The formatted date string in the format 'YYYY-MM-DD HH:MM:SS GMT'.
        """        
        return datetime.strptime(self.decode(d, 'utf-8'), '%Y%m%d%H%M%SZ').strftime("%Y-%m-%d %H:%M:%S GMT")

    def merge_cert(self, extensions, certificate):

        """
        Merge a dictionary of extensions into a certificate.

        Args:
            extensions (dict): A dictionary of extensions to be merged into the certificate.
            certificate (dict): A dictionary representing a certificate.

        Returns:
            dict: A new dictionary that is a merge of the extensions and the certificate.
        """        
        z = certificate.copy()
        z.update(extensions)
        return z

    def cert(self):

        """
        Get the details of a certificate.

        Returns:
            str: A JSON string containing the details of the certificate.
        """        
        keytype = self.x509.get_pubkey().type()
        keytype_list = {TYPE_RSA: 'rsaEncryption', TYPE_DSA: 'dsaEncryption', 408: 'id-ecPublicKey'}
        extension_list = ["extendedKeyUsage",
                          "keyUsage",
                          "subjectAltName",
                          "subjectKeyIdentifier",
                          "authorityKeyIdentifier"]

        key_type_str = keytype_list[keytype] if keytype in keytype_list else 'other'

        certificate = {}
        extension = {}
        for i in range(self.x509.get_extension_count()):
            critical = 'critical' if self.x509.get_extension(i).get_critical() else ''

            if self.decode(self.x509.get_extension(i).get_short_name(), 'utf-8') in extension_list:
                try:
                    extension[
                        self.decode(self.x509.get_extension(i).get_short_name(), 'utf-8')] = self.x509.get_extension(
                        i).__str__()
                except Exception as e:
                    name = self.x509.get_extension(i).get_short_name()
                    extension[self.decode(name, 'utf-8')] = "FAILED_TO_DECODE"
                    logger.debug("Failed to parse certificate extension %s" % name)

        certificate = {'Thumbprint': self.decode(self.x509.digest('sha1'), 'utf-8'),
                       'Version': self.x509.get_version(),
                       'SignatureAlg': self.decode(self.x509.get_signature_algorithm(), 'utf-8'),
                       'Issuer': self.format_subject_issuer(self.x509.get_issuer()),
                       'Valid From': self.format_asn1_date(self.x509.get_notBefore()),
                       'Valid Until': self.format_asn1_date(self.x509.get_notAfter()),
                       'Subject': self.format_subject_issuer(self.x509.get_subject()),
                       'Raw Cert': self.built_cert}
        combined = self.merge_cert(extension, certificate)

        cert_output = json.dumps(combined)
        return cert_output

    def __str__(self):
        """
        Returns the certificate in string form if desired.
        """
        return self.cert()


class Cert(object):
    """
    A class representing a certificate.

    Attributes:
        subjectAltName (str): The subject alternative name of the certificate.
        subject (str): The subject of the certificate.
        validfrom (str): The start date of the validity period of the certificate.
        validuntil (str): The end date of the validity period of the certificate.
        thumbprint (str): The thumbprint of the certificate.
        subjectkey (str): The subject key identifier of the certificate.
        authkey (str): The authority key identifier of the certificate.
        sigalg (str): The signature algorithm used in the certificate.
        keyusage (str): The key usage of the certificate.
        extkeyusage (str): The extended key usage of the certificate.
        issuer (str): The issuer of the certificate.
        combined (dict): The combined information of the certificate.
    """    
    def __init__(self, cert, file=True):
        """
        Initialize a Certificate object.

        Args:
            cert (str): The certificate in string format.

        Attributes:
            subjectAltName (str): The subject alternative name of the certificate.
            subject (str): The subject of the certificate.
            validfrom (str): The validity start date of the certificate.
            validuntil (str): The validity end date of the certificate.
            thumbprint (str): The thumbprint of the certificate.
            subjectkey (str): The subject key identifier of the certificate.
            authkey (str): The authority key identifier of the certificate.
            sigalg (str): The signature algorithm used in the certificate.
            keyusage (str): The key usage information of the certificate.
            extkeyusage (str): The extended key usage information of the certificate.
            issuer (str): The issuer of the certificate.
        """        
        parsed_cert = parseCert(cert,file)
        combined = json.loads(str(parsed_cert))
        self.subjectAltName = combined.get('subjectAltName')
        self.subject = combined.get('Subject')
        self.validfrom = combined.get('Valid From')
        self.validuntil = combined.get('Valid Until')
        self.thumbprint = combined.get('Thumbprint')
        self.subjectkey = combined.get('subjectKeyIdentifier')
        self.authkey = combined.get('authorityKeyIdentifier')
        
        if self.authkey:
            self.authkey = self.authkey.split('\n', 1)[0]
            if 'keyid:' in self.authkey:
                self.authkey = self.authkey.replace('keyid:', '')
        self.sigalg = combined.get('SignatureAlg')
        self.keyusage = combined.get('keyUsage')
        self.extkeyusage = combined.get('extendedKeyUsage')
        self.issuer = combined.get('Issuer')
        self.raw_cert = combined.get('Raw Cert')


class GetVecs(object):
    """
    A class for interacting with VMware vSphere Certificate Store (VECS).

    Attributes:
        vecscli (str): The path to the vecs-cli binary.
        ignore_list (list): A list of stores to ignore when listing stores.

    Methods:
        GetVecsStores: Retrieves a list of VECS stores.
        ListStoreCerts: Retrieves a list of certificates in a specific store.
        getCertCountFromStore: Retrieves the number of certificates in a specific store.
        GetVecsCert: Retrieves a specific certificate from a store.
        all: Retrieves all certificates from all stores.
    """    
    def __init__(self, ignore_list=None):
        """
        Initializes an instance of the class.

        Args:
            ignore_list (list): A list of items to ignore.

        Attributes:
            vecscli (str): The path to the vecs-cli binary.
            ignore_list (list): A list of items to ignore.
        """        
        self.vecs_client = VecsDB()
        self.vecscli = "/usr/lib/vmware-vmafd/bin/vecs-cli"
        self.ignore_list = ignore_list

    def GetVecsStores(self):
        """
        Get the list of vector stores.

        Returns:
            list: A list of vector stores.
        """        
        output = []
        # logger.debug("Getting certificate with Alias: %s from Store: %s" % (alias,store))

        raw, errors, timeout = Command([self.vecscli, "store", "list"]).run()
        for store in raw.splitlines():
            if store not in self.ignore_list:
                output.append(store)
        return output

    def ListStoreCerts(self, store):
        """
        Store the certificates in a list.

        Args:
            self (class): The class instance.
            store (str): The name of the certificate store.

        Returns:
            list: A list of certificate aliases stored in the given certificate store.
        """        
        output = []
        raw, errors, timeout = Command([self.vecscli, "entry", "list", "--store", store]).run()
        for line in raw.splitlines():
            if 'Alias' in line:
                output.append(line.split(":", 1)[1].strip())
        return output

    def getCertCountFromStore(self, store):
        """
        Get the count of certificates from a specified store.

        Args:
            store (str): The name of the store.

        Returns:
            str: The count of certificates in the store.
        """        
        raw, errors, timeout = Command([self.vecscli, "entry", "list", "--store", store]).run()
        for line in raw.splitlines():
            if "Number of entries in store" in line:
                return line.split(":")[1].strip()

    def GetVecsCert(self, store, alias):
        """
        Get the certificate with a specified alias from a store.

        Args:
            store (str): The store name.
            alias (str): The alias of the certificate.

        Returns:
            str: The certificate.

        Raises:
            None.
        """        
        logger.debug("Getting certificate with Alias: %s from Store: %s" % (alias, store))
        cert, errors, timeout = Command([self.vecscli, "entry", "getcert", "--store", store, "--alias", alias]).run()
        return cert

    def all(self):
        """
        Return a dictionary containing all store-certificate pairs.

        Returns:
            dict: A dictionary with store names as keys and another dictionary as values. The inner dictionary contains aliases as keys and corresponding certificates as values.
        """        
        output = self.vecs_client.get_all_certs()
        # output = {}
        # for store in self.GetVecsStores():
        #     output[store] = {}
        #     for alias in self.ListStoreCerts(store):
        #         output[store][alias] = self.GetVecsCert(store, alias)
        return output
