import sys
import os
import logging
import ssl
from vcenter.vc_lib.common import Command, psqlQuery, Cert, ChainValidationException
from vcenter.vc_cfg.current_defaults import httpsPort, hostname, ca_list, root_map
sys.path.append(os.environ['VMWARE_PYTHON_PATH'])
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from pyVmomi.VmomiSupport import newestVersions
from pyVmomi import Vim, SoapStubAdapter


logger = logging.getLogger(__name__)
trusted_list = None

class exManager(object):
    """
    A class representing an extension manager.

    Attributes:
        username (str): The username for authentication.
        password (str): The password for authentication.
    """    
    def __init__(self, username, password):
        # (httpPort, httpsPort, endpointsDir) = get_rhttpProxy_config()
        """
        Initialize an instance of the class.

        Args:
            username (str): The username for authentication.
            password (str): The password for authentication.

        Raises:
            Exception: If the user credentials are invalid.
        """        
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

        try:
            stub = SoapStubAdapter(host='localhost', port=httpsPort, path='/sdk',
                                   version=newestVersions.GetName('vpx'), sslContext=context)
        except:
            stub = SoapStubAdapter(host='localhost', port=httpsPort, path='/sdk',
                                   version=newestVersions.Get('vpx'), sslContext=context)
        si = Vim.ServiceInstance('ServiceInstance', stub)

        self.sessionMgr = None
        try:
            self.sessionMgr = si.content.sessionManager
            self.sessionMgr.Login(username, password)
        except Vim.fault.InvalidLogin:
            raise Exception("Invalid user credentials")
        self.em = si.content.extensionManager
        self.settings = si.content.setting.setting

    def getSetting(self, setting_key):
        """
        Get the value of a specific setting.

        Args:
            setting_key (str): The key of the setting to retrieve.

        Returns:
            object: The value of the specified setting.

        Raises:
            KeyError: If the specified setting key does not exist.
        """        
        for setting in self.settings:
            if setting.key == setting_key:
                return setting.value

    def getExtThumbprint(self, ext_name):
        """
        Get the thumbprint of a specific extension.

        Args:
            ext_name (str): The name of the extension.

        Returns:
            str: The thumbprint of the extension.
        """        
        output = psqlQuery('SELECT thumbprint from vpx_ext where ext_id=\'%s\'' % ext_name)
        return output

    def list(self):
        """
        List the details of extensions.

        Returns:
            dict: A dictionary of extension details. The keys are the extension keys and the values are dictionaries containing the label, description, company, version, hostname, and thumbprint of each extension.

        Raises:
            AssertionError: If the session manager is not initialized or if the logout fails.
        """        
        results = {}
        try:
            for extension in self.em.extensionList:
                ex_key = extension.GetKey()

                results[ex_key] = {}
                results[ex_key]['label'] = extension.description.label
                results[ex_key]['description'] = extension.description.summary
                results[ex_key]['company'] = extension.company
                results[ex_key]['version'] = extension.version
                dbtp = self.getExtThumbprint(ex_key)
                try:
                    results[ex_key]['hostname'] = urlparse.urlparse(extension.server[0].url).hostname
                    if dbtp == "":
                        results[ex_key]['thumbprint'] = extension.server[0].serverThumbprint
                    else:
                        results[ex_key]['thumbprint'] = dbtp
                except:
                    results[ex_key]['thumbprint'] = dbtp
            return results
        finally:
            assert self.sessionMgr is not None
            self.sessionMgr.Logout()
            self.sessionMgr = None

    def findByExtName(self, ex_name):
        """
        Find dictionary entries by extension name.

        Args:
            ex_name (str): The extension name to search for in the dictionary keys.

        Returns:
            dict: A dictionary containing the entries with the matching extension name.
        """        
        extensions = self.list()
        results = {}
        for extension in extensions:
            if ex_name in extension:
                results[extension] = extensions[extension]
        return results

def split_pem(pem):
    """Splits a PEM file into individual certificate files.

    Args:
        pem_filepath: Path to the input PEM file.
        output_dir: Directory to save the individual certificate files.
                    Defaults to the current directory.
    """
    cert_list = []
    cert = ""
    roots = []

    # little redundancy here parsing to string then re-encoding later.  Have to do this to account
    # for potential differences in openssl version.
    if os.path.exists(pem):
        with open(pem, 'rb') as f:
            pem_data = f.read()
        pem_data = pem_data.decode('utf-8')
    
    elif '-----BEGIN CERTIFICATE-----' in pem:
        try:
            pem = pem.decode()
        except (UnicodeDecodeError, AttributeError):
            pass
        pem_data = pem

    else:
        logger.error("filepath or pem data invalid!")

    for line in pem_data.splitlines():
        cert += f"\n{line}"
        if 'END CERTIFICATE' in line:
            try:
                cert_list.append(x509.load_pem_x509_certificate(bytes(cert, 'utf-8')))
            except:
                # if cryptography module is <=35, we have to do  this.
                cert_list.append(x509.load_pem_x509_certificate(bytes(cert, 'utf-8'), backend=default_backend()))
            cert = ""

    leaf = cert_list[0].public_bytes(encoding=serialization.Encoding.PEM).decode('utf-8')
    if len(cert_list) > 1:
        for temp_cert in [x.public_bytes(encoding=serialization.Encoding.PEM).decode('utf-8') for x in cert_list[1:]]:
            cert = Cert(temp_cert)
            roots.append(cert)
    return leaf, roots


def get_signer(cert, include_inter=True):

    signer = None
    cert_type = None
    roots = root_map['ROOTS']
    intermediates = root_map['INTERMEDIATES']


    for inter in intermediates:
        if cert.subjectkey == inter.get('skid'):
            continue

        if cert.authkey == inter.get('skid'):
            signer = Cert(inter.get('raw_cert'))
            cert_type = 'INTERMEDIATE'
            logger.debug(f"Found intermediate cert {signer.subject}")
            break
    
    if not cert_type:
        logger.debug("No matching intermediate.  Looking for root cert.")
        for root in roots:
            if cert.authkey == root.get('skid'):
                signer = Cert(root.get('raw_cert'))
                cert_type = 'ROOT'
                break
            
        if not cert_type:
            logger.debug("No matching root either!")
    
    if signer:
        logger.debug(f"Signer of {cert.subject} is {signer.subject}")
    else:
        logger.debug(f"couldn't find signer of {cert.subject}")
    
    return signer, cert_type

def identify_cert_type(cert):
    if isinstance(cert, dict):
        curr_cert = Cert(cert.get('raw_cert'))
    elif isinstance(cert, str):
        curr_cert = Cert(cert)
    else:
        curr_cert = cert
    
    if curr_cert.keyusage and 'Certificate Sign' not in curr_cert.keyusage:
        cert_type = "LEAF"
    elif curr_cert.authkey and curr_cert.subjectkey not in curr_cert.authkey:
        cert_type = "INTERMEDIATE"
    elif not curr_cert.authkey or curr_cert.subject == curr_cert.issuer:
        cert_type = "ROOT"
    else:
        raise ChainValidationException("UNKNOWN_TYPE", f"Certificate: {curr_cert.subject} Unable to determine leaf/inter/root type")
    
    logger.debug(f"cert {curr_cert.subject} is of type: {cert_type}")
    return cert_type

def build_chain(cert):
    cert_chain = []
    missing_issuer = ""
    missing_authkey = ""
    complete_flag = True
    signer = None
    if isinstance(cert, dict):
        curr_cert = Cert(cert.get('raw_cert'))
    elif isinstance(cert, str):
        curr_cert = Cert(cert)
    else:
        curr_cert = cert
    cert_type = identify_cert_type(cert)
    
    if cert_type != "ROOT":
        logger.debug("Cert is not a root")
        while True:
            prev_cert = curr_cert

            cert_chain.append(curr_cert)
            curr_cert, cert_type = get_signer(curr_cert)

            if cert_type == 'ROOT':
                cert_chain.append(curr_cert)
                logger.debug(f"Found root: {curr_cert.subject}")
                break
            
            if not curr_cert:
                logger.debug("Did not find signer.")
                complete_flag = False
                missing_issuer = prev_cert.issuer
                missing_authkey = prev_cert.authkey
                break
            
            prev_cert = None
            cert_type = ""
    if len(cert_chain) > 1:
        signer = cert_chain[1]
    
    return complete_flag, signer, missing_issuer, missing_authkey

def get_current_vmca_cert():
    vmca_cert_path = "/var/lib/vmware/vmca/root.cer"
    with open(vmca_cert_path) as f:
        vmca_cert_str = f.read()
    return Cert(vmca_cert_str)

def validate_chain(cert, roots=None, ignore_chain=False):
    """
    Validate the chain of trust on a certificate.

    Args:
        cert (str): the base64 encoded string from a pem cert.
        roots (list, optional): list of root certificates against which to check trust.
        ignore_chain (bool, optional): whether or not the certificate .

    Returns:
        bytes: The output of the command as bytes.

    Raises:
        ChainValidationException: If the certificate chain is un-parseable, or the chain is incomplete.

    """ 
    chain = ""
    parsed_cert = Cert(cert, False)
    status = ""
    keyusage = parsed_cert.keyusage
    cert_result = 'TRUSTED'
    cert_to_check = parsed_cert
    msg = ""

    if not roots:
        leaf, detected_roots = split_pem(cert)
        if detected_roots:
            cert_to_check = detected_roots[-1]
            status = "CA-CHAIN"


        elif keyusage and 'Certificate Sign' not in keyusage:
            if hostname in parsed_cert.issuer or "OU=VMware" in parsed_cert.issuer:
                status = "VMCA-SIGNED"
            else:
                current_vmca = get_current_vmca_cert()
                if parsed_cert.issuer == current_vmca.subject:
                    status = "VMCA-SIGNED"
                else:
                    status = "UNKNOWN-SIGNED"

        else:
            if parsed_cert.subject == parsed_cert.issuer:
                status = f"SELF-SIGNED"
            else:
                status = "SIGNED-INTERMEDIATE"
        
        if "SIGNED" in status or ignore_chain:
            
            roots = ca_list

    if not parsed_cert.subjectkey:
        #Can't reliably determine chain if there's no SKID.  
        #Technically you could go off of subject/issuer, but its not reliable.
        cert_result = "SKID MISSING"
        msg = f"Certificate: {parsed_cert.subject} doesn't have a subject key!"  
    
    success, signer, missing_issuer, missing_authkey = build_chain(cert_to_check)
    if not success:
        missing_info = f"\n\nMissing Subject: \n    {missing_issuer}\nMissing Authority Key: \n    {missing_authkey}\n"
        cert_result = "INCOMPLETE"
        if status == "VMCA-SIGNED":
            msg = f"\nMissing VMCA in TRUSTED_ROOTS!{missing_info}"
        else:
            msg = f"\nMissing signing CA in TRUSTED_ROOTS!{missing_info}"
    else:
        if signer:
            msg = f"Issuer Alias/Thumbprint: {signer.thumbprint}\nIssuer DN:{signer.subject}"
        else:
            msg = ""

        
    status = f"{cert_result}|{status}"
    return msg, status
