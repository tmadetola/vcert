#!/usr/bin/env python
import sys
import os
import ssl
import logging
import getpass
import datetime
import time
import configparser
from lib.vdt_formatter import ColorWrap, escape_ansi
from lib.vdt_base import get_logger_enh
from lib.vdt_formatter import Formatter, ColorWrap
if os.getenv('VMWARE_PYTHON_PATH') not in sys.path:
    sys.path.append(os.getenv('VMWARE_PYTHON_PATH'))

import vmafd

cfgfile = os.path.join(os.path.dirname(__file__), "vks_cfg", "vks_vdt.ini")
config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
config.read(cfgfile)

logdir = config['logging'].get('logdir')
logname = config['logging'].get('logname')
loglevel = config['logging'].get('level')
title = config['vdt'].get('title')

date_time = f"{datetime.date.today().strftime('%A, %B %d')} {time.strftime('%H:%M:%S', time.localtime())}"
runtime_info = f"{ColorWrap.title(title)}\n\tToday: {date_time}\n\tLog Level: {loglevel}\n"

get_logger_enh(loglevel, logdir, logname)
logger = logging.getLogger(__name__)

# Runtime defaults (service_status, vc_version, httpsPort, sso_domain) are loaded in main() via _load_runtime_defaults()
# so that unsupported-version exits avoid heavy work. These are set as globals in main() before use.
service_status = None
vc_version = None
httpsPort = None
sso_domain = None

from vks.vks_lib.vks_supervisor_manager import supervisor_manager
from vks.vks_scripts.vks_sv_checks import (
    supervisor_port_22_check,
    supervisor_port_6443_check,
)

def logandprint(string_text, level="info"):
    """
    Log and print a string message with a specified log level.

    Args:
        string_text (str): The string message to log and print.
        level (str, optional): The log level to use. Default is 'info'.

    Raises:
        None

    Returns:
        None
    """    

    if level == "info":
        print(string_text)
        logger.debug(f"INFO: {escape_ansi(string_text)}")
    elif level == "error":
        logger.debug(f"ERROR: {escape_ansi(string_text)}")
    if level == "debug":
        print(string_text)
        logger.debug(escape_ansi(string_text))
    if level == "warn":
        print(string_text)
        logger.debug(f"WARNING: {escape_ansi(string_text)}")

logandprint(runtime_info)
login_retry_limit = 3


def _load_runtime_defaults():
    """
    Load runtime defaults (service_status, vc_version, httpsPort, sso_domain).
    Called at start of main() so unsupported-version exits avoid later heavy work.
    Returns tuple (service_status, vc_version, httpsPort, sso_domain).
    """
    from vks.vks_cfg import current_defaults
    return (
        current_defaults.service_status,
        current_defaults.vc_version,
        current_defaults.httpsPort,
        current_defaults.sso_domain,
    )


def _update_vm_support():
    """
    Utility function to include vdt log directory in support bundles.
    """
    mfx = f"""
% Manifest name: vdt
% Manifest group: VirtualAppliance
% Manifest default: Enabled
# action Options file/command
copy IGNORE_MISSING,RECURSE {logdir}/
    """
    vmsupportpath = os.path.join(os.environ['VMWARE_CFG_DIR'], 'vm-support','vdt.mfx')
    if not os.path.exists(vmsupportpath):
        answer = input(
            "When running this tool, a log file is created and included in all future log bundles.  Would you like to continue?[Yy|Nn]: ")
        if answer.lower() == 'n':
            logandprint("Exiting.")
            sys.exit()
        elif answer.lower() == 'y':
            try:
                with open(vmsupportpath,"w+") as f:
                    f.writelines(mfx)
                logger.debug("vdt logs will be included in support bundles.")
            except Exception as e:
                error_msg = "Couldn't add support bundle config file: %s" % vmsupportpath
                logger.debug(f"ERROR: You will have to collect vdt logs manually!  Error was: {error_msg}")
        else:
            logandprint("\nInvalid option.  Please try again.\n")
            sys.exit()
    else:
        logger.debug("%s already exists." % vmsupportpath)

def loadMachineCredentials():
    """
        Retrieve machine account and machine account password from vmafd.

        Returns:
            tuple: A tuple containing the machine account and machine account password from vmafd.

            The tuple has the format (username, password).

            If VMAFD is not running, it returns (None, None).

        Raises:
            None.
    """

    if 'vmafdd service required!' in sso_domain:
        print(sso_domain)
        logandprint("VMAFD not running.  checks requiring authentication may not run.", level="error")
        return None, None

    vmafdclient = vmafd.client('localhost')
    name = vmafdclient.GetMachineName()
    domain = vmafdclient.GetDomainName()
    username = '{}@{}'.format(name, domain)
    password = vmafdclient.GetMachinePassword()
    return username, password

def TestLogin(username=None, password=None, retry=0, userauth=False):

    """
    Test login with provided username and password.

    Args:
        username (str, optional): The username to use for login. If not provided, it prompts the user to enter the username.
        password (str, optional): The password to use for login. If not provided, it prompts the user to enter the password.
        retry (int, optional): The number of login retry attempts made. Default is 0.
        failout (bool, optional): If failed over from machine account creds to admin creds.

    Returns:
        tuple: A tuple containing the username, password, and success status.
            - username (str or None): The username used for login. If the login was not successful, returns None.
            - password (str or None): The password used for login. If the login was not successful, returns None.
            - success (bool): True if the login was successful, False otherwise.

    Raises:
        None

    Note:
        The function internally handles invalid user credentials and prompts for retry or exit options.
    """

    if not username:
        # username, password = prompt()
        if not userauth:
            username, password = loadMachineCredentials()
        else:
            username, password = prompt()
    if not username:
        success = False
        return None, None, success
    from pyVmomi import SoapStubAdapter, Vim
    from pyVmomi.VmomiSupport import newestVersions
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        try:
            stub = SoapStubAdapter(host='localhost', port=httpsPort, path='/sdk',
                                   version=newestVersions.GetName('vpx'), sslContext=context,
                                   httpConnectionTimeout=10)
        except Exception:
            stub = SoapStubAdapter(host='localhost', port=httpsPort, path='/sdk',
                                   version=newestVersions.Get('vpx'), sslContext=context,
                                   httpConnectionTimeout=10)
        si = Vim.ServiceInstance('ServiceInstance', stub)
        sessionMgr = si.content.sessionManager
        sessionMgr.Login(username, password)
        logger.debug(f"INFO: Login successful")
        rc = 1
    except Vim.fault.InvalidLogin:
        if retry < login_retry_limit:
            retry += 1
            logandprint("Invalid user credentials.  Please try again. [retry %s/%s] " % (retry, login_retry_limit), level="debug")
            return TestLogin(retry=retry, userauth=userauth)
        else:
            logandprint("Invalid user credentials.  Retry limit reached.\n", level="debug")
            if userauth:
                answer = input("Would you like to continue?  Any check requiring authentication will not be run [Yy|Nn] ")
                if answer.lower() == "n":
                    sys.exit()
                elif answer.lower() == "y":
                    rc = 0
                else:
                    print(f"{answer} is not a valid answer.  Please run again.")
                    sys.exit()
            else:
                rc = 0
    except Exception as e:
        logger.debug(str(e))
        logandprint("Error attempting login (not related to credentials).  Checks requiring authentication will not be run.", level="error")
        rc = 0

    if rc == 1:
        success = True
        return username, password, success
    else:
        success = False
        if not userauth:
            logandprint("Automatic login with machine account credentials failed")
        return None, None, success
    
def prompt():

    """
    Prompt the user for username and password.

    Returns:
        tuple: A tuple containing the username and password provided by the user.

        The tuple has the format (username, password).

        If VMAFD is not running, it returns (None, None).

    Raises:
        None.
    """    
    if 'vmafdd service required!' in sso_domain:
        print(sso_domain)
        logandprint("VMAFD not running.  checks requiring authentication may not run.", level="error")
        # input("Press any key to continue...\n")
        return None, None
    username = "administrator@" + sso_domain
    # Get password with no echo
    passwd = getpass.getpass("\nProvide password for %s: " % username)
    return username, passwd

def _mark_skipped_checks(Runner, success):
    """
    Populate Runner.skipped for checks that require services or auth.
    Returns (servicefail, authfail) for use by main().
    """
    servicefail = False
    authfail = False
    for check in Runner.checks:
        check_params = Runner.cfg.get(f"check:{check}") or {}
        if 'req_services' in check_params:
            if reqServicesStarted(check_params['req_services']) == 0:
                servicefail = True
                Runner.skipped.update({check_params['name']: {'reason': 'service not running', 'result': 'FAIL'}})
            elif reqServicesStarted(check_params['req_services']) == 2:
                Runner.skipped.update({check_params['name']: {'reason': 'service disabled', 'result': 'INFO'}})
        if not success:
            authfail = True
            if check_params.get('auth_req') is True:
                if check_params['name'] not in Runner.skipped.keys():
                    Runner.skipped.update({check_params['name']: {'reason': 'authentication failure', 'result': "FAIL"}})
    return servicefail, authfail


def reqServicesStarted(services):
    """
    Check the status of requested services.

    Args:
        services (list or str): A list of services or a single service.

    Returns:
        int: 1 if all services are running, 2 if any service is disabled, 0 otherwise.

    Raises:
        None

    Note:
        - The function checks the status of services provided and returns a corresponding code.
        - If `services` is a list, it checks if all services are running or if any service is disabled.
        - If `services` is a string, it checks the status of that specific service.
        - The function assumes that the status of services is stored in the dictionary `service_status`.
    """    
    if isinstance(services, list):
        if all(service in service_status['RUNNING'] for service in services):
            return 1
        elif any(x in services for x in service_status['DISABLED']):
            return 2
        else:
            return 0
    elif isinstance(services, str):
        if services in service_status['RUNNING']:
            return 1
        elif services in service_status['DISABLED']:
            return 2
        else:
            return 0
          
def main():
    """
    Main function that performs a series of checks.

    Raises:
        None
    Returns:
        None
    """
    global service_status, vc_version, httpsPort, sso_domain
    service_status, vc_version, httpsPort, sso_domain = _load_runtime_defaults()

    _update_vm_support()
    if vc_version.startswith('6') or vc_version.startswith('7'):
        print("\nThis tool is only supported on vCenter 8 and later.\n")
        sys.exit(1)
    if vc_version.startswith('8'):
        userauth = False
    else:
        print("\nMachine account credential auth is only available in VC 8+\n")
        userauth = True
    required_services = ['vmafdd', 'vmdird', 'vmware-stsd', 'wcp']
    if not reqServicesStarted(required_services):
        success = False
        username = ""
        password = ""
    else:
        username, password, success = TestLogin(userauth=userauth)
        if not success and not userauth:
            username, password, success = TestLogin(userauth=True)

    # TODO pass supervisor name
    Runner = Formatter(name=__name__, item_type='check', cfgfile=cfgfile, username=username,
                     password=password)

    # Initialize supervisor cache at startup
    supervisor_manager.initialize_supervisor_cache()

    # Exit point 1: No supervisor clusters in DB
    if supervisor_manager.get_supervisor_details() is None or not supervisor_manager.get_supervisors():
        logandprint("No supervisor clusters found in the database (or no supervisor VMs). Exiting.", level="error")
        sys.exit(1)

    # Exit point 2: Port 22 and 6443 must be reachable
    port_22_result = supervisor_port_22_check()
    if port_22_result.get("result") == "FAIL":
        logandprint(f"{port_22_result.get('title', 'Supervisor Port 22 Check')}: FAIL", level="error")
        logandprint(port_22_result.get("details", ""), level="error")
        sys.exit(1)
    port_6443_result = supervisor_port_6443_check()
    if port_6443_result.get("result") == "FAIL":
        logandprint(f"{port_6443_result.get('title', 'Supervisor Port 6443 Check')}: FAIL", level="error")
        logandprint(port_6443_result.get("details", ""), level="error")
        sys.exit(1)

    servicefail, authfail = _mark_skipped_checks(Runner, success)

    if authfail:
        logandprint(f"{ColorWrap.warn('WARNING')}: Authentication failed!  Checks that require authentication will be skipped.")

    if servicefail:
        logandprint(f"{ColorWrap.warn('WARNING')}: Some required services aren't running!  Dependent checks will be skipped.")

    if authfail or servicefail:
        input("\n\nPress any key to continue with the remaining checks...\n\n")

    report_location = Runner.generate_report(True, header=runtime_info)
    logandprint(f"""
    ---
Report location: {report_location}
Feedback Contact: vcf-gs-sa-vdt.PDL@broadcom.com
    ---""")

if __name__ == '__main__':
    main()