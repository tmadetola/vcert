import os 
import sys
import json
from vks.vks_lib.common import psqlQuery, run_command

WCP_TABLE_DIR = "/tmp/vdt/"

def get_wcp_tables():
    """
    Get all WCP table names from the VCDB database.

    Returns:
        list: A list of WCP table names.
    
    Raises:
        None
    """
    cmd = ["psql", "-d", "VCDB", "-U", "postgres", "-At", "-c", "\\dt wcp.*"]
    output = run_command(cmd).decode().strip()
    tables = [line.split('|')[1] for line in output.splitlines() if line]
    return tables

def export_wcp_tables_to_json(output_dir="/tmp/vdt"):
    """
    Export all WCP tables from the VCDB database to JSON files.
    Args:
        output_dir (str): The directory where the JSON files will be saved. Defaults to "/tmp/vdt".
    """
    import os
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    tables = get_wcp_tables()
    for table in tables:
        cmd = ["psql", "-d", "VCDB", "-U", "postgres", "-At", "-c", f"select json_agg({table}) from wcp.{table};"]
        output = run_command(cmd).decode().strip()
        with open(os.path.join(output_dir, f"{table}.json"), 'w') as f:
            f.write(output)

def remove_exported_wcp_tables(output_dir="/tmp/vdt"):
    """
    Remove all exported WCP table JSON files from the specified directory.

    Args:
        output_dir (str): The directory where the JSON files are stored. Defaults to "/tmp/vdt".
    """
    for filename in os.listdir(output_dir):
        if filename.endswith(".json"):
            file_path = os.path.join(output_dir, filename)
            try:
                os.remove(file_path)
            except OSError as e:
                pass

def read_wcp_table(filename):
    """
    Reads and parses a JSON file from the WCP_TABLE_DIR.

    Args:
        filename (str): The name of the file to read.

    Returns:
        dict or list: The parsed JSON data, or None if an error occurs.
    """
    file_path = WCP_TABLE_DIR + filename
    try:
        with open(file_path, "r") as f:
            data = f.read()
        return json.loads(data)
    except FileNotFoundError:
        #print(f"Error: File not found at {file_path}")
        return None
    except json.JSONDecodeError:
        #print(f"Error: Could not decode JSON from {file_path}")
        return None

def getSupervisorName():
    """
    Get the supervisor name from the cluster_db_configs.json file.

    Returns:
        str: The supervisor name if found, otherwise an empty string.
    """
    cluster_db_configs = read_wcp_table("cluster_db_configs.json")
    
    # Check if there is more than one supervisor
    if len(cluster_db_configs) > 1:
        if "SUPERVISOR_NAME" in os.environ:
            return os.environ["SUPERVISOR_NAME"]
        else:
            # Ensure the result of .get() is not None
            name = cluster_db_configs[0].get("desired_config", {}).get("Name")
            return name if name is not None else ""
    else:
        # Ensure the result of .get() is not None
        name = cluster_db_configs[0].get("desired_config", {}).get("Name")
        return name if name is not None else ""

def getSvcpvmDetails():
    vm_id_query = "select id,name from vpx_entity where name like '%SupervisorControlPlaneVM%';"
    vm_id_output = psqlQuery(vm_id_query, return_all=True).splitlines()

    vm_id_list = []

    for vm in vm_id_output:
        parts = vm.split("|")
        if len(parts) == 2:
            vm_id = parts[0]
            vm_name = parts[1]
            vm_id_list.append({"vm_id": vm_id, "vm_name": vm_name, "vm_dns": "", "vm_ip": "", "eam_agency_id": ""})
        else:
            print(f"Warning: Skipping invalid line: {vm}")

    for vm in vm_id_list:
        vm_query = f"select dns_name,ip_address from vpx_vm where id={vm['vm_id']};"
        vm_output = psqlQuery(vm_query, return_all=True)

        if vm_output:
            parts = vm_output.split("|")
            if len(parts) >= 2:
                vm['vm_dns'] = parts[0]
                vm['vm_ip'] = parts[1].strip()
            else:
                print(f"Warning: Could not parse DNS/IP output for VM ID {vm['vm_id']}: {vm_output}")

    return vm_id_list 

def main():
    """
    Main function to export WCP tables to JSON files.
    """
    export_wcp_tables_to_json()

if __name__ == "__main__":
    main()