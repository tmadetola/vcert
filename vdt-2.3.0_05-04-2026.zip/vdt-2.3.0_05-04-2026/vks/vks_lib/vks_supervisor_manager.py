"""
VKS Supervisor Manager - Handles supervisor VM selection, caching, and SSH operations
"""
import os
import logging
import subprocess
import socket
import json
import warnings

# Handle optional imports with fallbacks
try:
    from cryptography.utils import CryptographyDeprecationWarning
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=CryptographyDeprecationWarning)
        import paramiko
except ImportError as e:
    # Fallback for environments where paramiko/cryptography is not available
    logging.getLogger(__name__).debug(f"WARNING: SSH functionality will be limited: {e}")
    paramiko = None

from .vks_db_utils import export_wcp_tables_to_json, read_wcp_table, psqlQuery

logger = logging.getLogger(__name__)

class SupervisorManager:
    """
    Manages supervisor VM selection, caching, and SSH operations for multi-cluster environments.
    Caches all supervisor information at startup to avoid repeated database queries.
    
    This class uses the same startup logic as vks_startup_utils.py to ensure consistency
    in how supervisor clusters and VMs are discovered and cached.
    """
    
    _instance = None
    _supervisor_details = None
    _ssh_connection_status = {}
    _chosen_supervisor_vm = None
    _cached_password = None
    _ssh_keys_cleared = False
    
    def __new__(cls):
        """Singleton pattern to ensure only one instance exists."""
        if cls._instance is None:
            cls._instance = super(SupervisorManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self):
        """Initialize the supervisor manager."""
        if not hasattr(self, '_initialized'):
            self._initialized = True
            logger.debug("SupervisorManager initialized")
    
    def _check_ssh_availability(self, ip, username="root", timeout=5):
        """
        Check if SSH is available on a given IP address.
        
        Args:
            ip (str): IP address to check
            username (str): Username for SSH connection
            timeout (int): Connection timeout in seconds
            
        Returns:
            bool: True if SSH is available, False otherwise
        """
        # Check cache first
        cache_key = f"{ip}:{username}"
        if cache_key in self._ssh_connection_status:
            logger.debug(f"Returning cached SSH status for {ip}: {self._ssh_connection_status[cache_key]}")
            return self._ssh_connection_status[cache_key]
        
        logger.debug(f"Checking SSH availability for {ip}")
        
        if paramiko is None:
            logger.debug(f"WARNING: paramiko not available, cannot check SSH connectivity")
            self._ssh_connection_status[cache_key] = False
            return False
        
        try:
            # First check if port 22 is open
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, 22))
            sock.close()
            
            if result != 0:
                logger.debug(f"SSH port 22 not reachable on {ip}")
                self._ssh_connection_status[cache_key] = False
                return False
            
            # Port is open, try SSH connection
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(ip, username=username, timeout=timeout, look_for_keys=True, allow_agent=True)
            ssh.close()
            
            logger.debug(f"SSH connection successful to {ip}")
            self._ssh_connection_status[cache_key] = True
            return True
            
        except Exception as e:
            logger.debug(f"SSH connection failed to {ip}: {e}")
            self._ssh_connection_status[cache_key] = False
            return False
    
    def _get_supervisor_ips(self, vm_ids):
        """
        Get supervisor VM IPs from database using VM IDs.
        
        Args:
            vm_ids (list): List of VM IDs to query
            
        Returns:
            list: List of supervisor VM details with IPs
        """
        supervisor_vms = []

        for vm_id in vm_ids:
            logger.debug(f"Processing VM ID: {vm_id}")
            # Extract numeric part of VM ID (e.g., vm-5031 -> 5031)
            if vm_id.startswith('vm-'):
                numeric_id = vm_id.split('-')[1]
            else:
                numeric_id = vm_id
                
            logger.debug(f"Using numeric ID: {numeric_id}")
            vm_query = f"select dns_name,ip_address from vpx_vm where id={numeric_id};"
            logger.debug(f"Executing query: {vm_query}")
            
            try:
                vm_output = psqlQuery(vm_query, return_all=True)
                logger.debug(f"Query result for VM {vm_id}: {vm_output}")
                
                if vm_output:
                    parts = vm_output.split("|")
                    if len(parts) >= 2:
                        supervisor_vms.append({
                            "vm_id": vm_id,
                            "vm_name": parts[0],  # DNS name acts as VM name
                            "vm_dns": parts[0],
                            "vm_ip": parts[1].strip(),
                            "ssh_available": None  # Will be checked later
                        })
                        logger.debug(f"Added VM: {vm_id} -> {parts[0]} ({parts[1].strip()})")
                    else:
                        logger.debug(f"WARNING: Could not parse DNS/IP output for VM ID {vm_id}: {vm_output}")
                else:
                    logger.debug(f"WARNING: No output for VM ID {vm_id}")
            except Exception as e:
                logger.debug(f"ERROR: Error querying VM {vm_id}: {e}")

        logger.debug(f"INFO: Found {len(supervisor_vms)} supervisor VMs from {len(vm_ids)} VM IDs")
        return supervisor_vms
    
    def _get_supervisor_details(self, supervisor_name=""):
        """
        Get supervisor cluster details including VMs.
        
        Args:
            supervisor_name (str): Name of supervisor cluster to get details for
            
        Returns:
            dict: Supervisor cluster details with VMs
        """
        cluster_id = ""
        supervisor_instance_id = ""
        vm_ids = []

        supervisor_cluster_configs = read_wcp_table("cluster_db_configs.json")
        
        if not supervisor_cluster_configs:
            logger.debug(f"ERROR: No cluster configurations found")
            return None

        if not supervisor_name:
            # Single cluster case
            if len(supervisor_cluster_configs) == 1:
                config = supervisor_cluster_configs[0]
                cluster_id = config.get("cluster")
                supervisor_instance_id = config.get("instance_id")
                supervisor_name = config.get("desired_config", {}).get("Name", "")
                for vm in config.get("cluster_netifs", []):
                    vm_id = vm.get("VMmoID", "")
                    if vm_id:
                        vm_ids.append(vm_id)
            else:
                logger.debug(f"ERROR: Multiple clusters found but no supervisor_name specified")
                return None
        else:
            # Multi-cluster case - find specific supervisor
            for config in supervisor_cluster_configs:
                if config.get("desired_config", {}).get("Name") == supervisor_name:
                    cluster_id = config.get("cluster")
                    supervisor_instance_id = config.get("instance_id")
                    for vm in config.get("cluster_netifs", []):
                        vm_id = vm.get("VMmoID", "")
                        if vm_id:
                            vm_ids.append(vm_id)
                    break
            
            if not cluster_id:
                logger.debug(f"ERROR: Supervisor cluster '{supervisor_name}' not found")
                return None

        supervisor_vms = self._get_supervisor_ips(vm_ids)
        
        return {
            "cluster_id": cluster_id,
            "supervisor_instance_id": supervisor_instance_id,
            "supervisor_name": supervisor_name,
            "supervisor_vms": supervisor_vms
        }
    
    def _check_for_multiple_supervisors(self):
        """
        Check if there are multiple supervisors in the cluster.
        
        Returns:
            bool: True if multiple supervisors are found, False otherwise.
        """
        supervisors = read_wcp_table("cluster_db_configs.json")
        if not supervisors:
            return False
            
        if len(supervisors) > 1:
            logger.debug(f"INFO: Multiple supervisors found in the cluster")
            return True
        else:
            logger.debug(f"INFO: Single supervisor found in the cluster")
            return False
    
    def initialize_supervisor_cache(self, force_refresh=False):
        """
        Initialize supervisor cache with cluster details and VM information.
        This should be called once at startup to cache all supervisor information.
        
        Args:
            force_refresh (bool): Force refresh of cached data
            
        Returns:
            dict: Supervisor details or None if initialization fails
        """
        if self._supervisor_details is not None and not force_refresh:
            logger.debug("Returning cached supervisor details")
            return self._supervisor_details
        
        logger.debug(f"INFO: Initializing supervisor cache")
        
        try:
            # Export WCP tables to ensure we have the latest data
            logger.debug("Exporting WCP tables...")
            export_wcp_tables_to_json()
            logger.debug("WCP tables exported successfully")
        except Exception as e:
            logger.debug(f"ERROR: Failed to export WCP tables: {e}")
            return None
        
        try:
            # Check for multiple supervisors
            logger.debug("Checking for multiple supervisors...")
            multiple_supervisors = self._check_for_multiple_supervisors()
            logger.debug(f"Multiple supervisors: {multiple_supervisors}")
            
            if not multiple_supervisors:
                # Single supervisor case
                logger.debug("Getting supervisor details for single cluster...")
                self._supervisor_details = self._get_supervisor_details()
            else:
                # Multiple supervisors case - check for environment variable
                supervisor_name = os.environ.get("SUPERVISOR_NAME")
                if not supervisor_name:
                    logger.debug(f"ERROR: Multiple supervisors found, but SUPERVISOR_NAME environment variable is not set.")
                    available_names = []
                    configs = read_wcp_table("cluster_db_configs.json")
                    if configs:
                        available_names = [config.get("desired_config", {}).get("Name", "unknown") for config in configs]
                    logger.debug(f"ERROR: Available supervisor names: {available_names}")
                    raise Exception(f"Multiple supervisors found, but SUPERVISOR_NAME environment variable is not set. Available: {available_names}")
                else:
                    logger.debug(f"Getting supervisor details for cluster: {supervisor_name}")
                    self._supervisor_details = self._get_supervisor_details(supervisor_name)
            
            if self._supervisor_details:
                logger.debug(f"INFO: Supervisor cache initialized for cluster: {self._supervisor_details['supervisor_name']}")
                logger.debug(f"INFO: Found {len(self._supervisor_details['supervisor_vms'])} supervisor VMs")
                for i, vm in enumerate(self._supervisor_details['supervisor_vms']):
                    logger.debug(f"  Supervisor VM {i+1}: {vm['vm_name']} ({vm['vm_ip']})")
            else:
                logger.debug(f"ERROR: Failed to get supervisor details")
                
        except Exception as e:
            logger.debug(f"ERROR: Failed to initialize supervisor cache: {e}")
            self._supervisor_details = None
        
        return self._supervisor_details
    
    def get_supervisors(self):
        """
        Get all supervisor VMs from cached data.
        Auto-initializes cache if not already done.
        
        Returns:
            list: List of supervisor VM details from cache, or empty list if initialization fails
        """
        if self._supervisor_details is None:
            logger.debug(f"INFO: Supervisor cache not initialized. Initializing now...")
            self.initialize_supervisor_cache()
        
        if self._supervisor_details is None:
            logger.debug(f"ERROR: Failed to initialize supervisor cache")
            return []
        
        supervisor_vms = self._supervisor_details.get('supervisor_vms', [])
        logger.debug(f"Returning {len(supervisor_vms)} cached supervisor VMs")
        return supervisor_vms
    
    def get_supervisor_details(self):
        """
        Get the complete supervisor details from cache.
        Auto-initializes cache if not already done.
        
        Returns:
            dict: Complete supervisor details including cluster info and VMs, or None if initialization fails
        """
        if self._supervisor_details is None:
            logger.debug(f"INFO: Supervisor cache not initialized. Initializing now...")
            self.initialize_supervisor_cache()
        
        return self._supervisor_details
    
    def get_cluster_id(self):
        """
        Get the cluster ID from cached supervisor details.
        Auto-initializes cache if not already done.
        
        Returns:
            str: Cluster ID, or None if not available
        """
        if self._supervisor_details is None:
            logger.debug(f"INFO: Supervisor cache not initialized. Initializing now...")
            self.initialize_supervisor_cache()
        
        if self._supervisor_details is None:
            return None
        
        return self._supervisor_details.get('cluster_id')
    
    def get_cluster_name(self):
        """
        Get the supervisor cluster name from cached details.
        Auto-initializes cache if not already done.
        
        Returns:
            str: Supervisor cluster name, or None if not available
        """
        if self._supervisor_details is None:
            logger.debug(f"INFO: Supervisor cache not initialized. Initializing now...")
            self.initialize_supervisor_cache()
        
        if self._supervisor_details is None:
            return None
        
        return self._supervisor_details.get('supervisor_name')
    
    def get_instance_id(self):
        """
        Get the supervisor instance ID from cached details.
        Auto-initializes cache if not already done.
        
        Returns:
            str: Supervisor instance ID, or None if not available
        """
        if self._supervisor_details is None:
            logger.debug(f"INFO: Supervisor cache not initialized. Initializing now...")
            self.initialize_supervisor_cache()
        
        if self._supervisor_details is None:
            return None
        
        return self._supervisor_details.get('supervisor_instance_id')
    
    def choose_supervisor(self, check_ssh=True, force_refresh=False):
        """
        Choose a single supervisor VM for operations from cached data.
        
        Args:
            check_ssh (bool): Check SSH connectivity before choosing
            force_refresh (bool): Force refresh of chosen supervisor
            
        Returns:
            dict: Chosen supervisor VM details, or None if none available
        """
        if self._chosen_supervisor_vm is not None and not force_refresh:
            logger.debug(f"Returning cached chosen supervisor: {self._chosen_supervisor_vm.get('vm_ip')}")
            return self._chosen_supervisor_vm
        
        logger.debug(f"INFO: Choosing supervisor VM from cached data")
        supervisors = self.get_supervisors()
        
        if not supervisors:
            logger.debug(f"ERROR: No supervisor VMs available in cache")
            return None
        
        # Try to find a supervisor with SSH connectivity if requested
        if check_ssh:
            for sv in supervisors:
                vm_ip = sv.get("vm_ip")
                vm_name = sv.get("vm_name", sv.get("vm_dns", "unknown"))
                
                if not vm_ip:
                    logger.debug(f"WARNING: Supervisor {vm_name} has no IP address, skipping")
                    continue
                
                if self._check_ssh_availability(vm_ip):
                    logger.debug(f"INFO: Chosen supervisor: {vm_name} ({vm_ip}) - SSH available")
                    sv['ssh_available'] = True
                    self._chosen_supervisor_vm = sv
                    return sv
                else:
                    logger.debug(f"WARNING: Supervisor {vm_name} ({vm_ip}) - SSH not available, trying next")
                    sv['ssh_available'] = False
        
        # If no supervisor with SSH was found or SSH check was skipped, use the first one
        first_sv = supervisors[0]
        vm_ip = first_sv.get("vm_ip", "unknown")
        vm_name = first_sv.get("vm_name", first_sv.get("vm_dns", "unknown"))
        
        if check_ssh:
            logger.debug(f"WARNING: No supervisor with SSH found, using first: {vm_name} ({vm_ip})")
        else:
            logger.debug(f"INFO: Chosen supervisor: {vm_name} ({vm_ip}) - SSH check skipped")
        
        self._chosen_supervisor_vm = first_sv
        return first_sv
    
    def get_chosen_supervisor_ip(self, check_ssh=True, force_refresh=False):
        """
        Get the IP address of the chosen supervisor.
        
        Args:
            check_ssh (bool): Check SSH connectivity before choosing
            force_refresh (bool): Force refresh of supervisor selection
            
        Returns:
            str: IP address of chosen supervisor, or None if none available
        """
        supervisor = self.choose_supervisor(check_ssh, force_refresh)
        if supervisor:
            return supervisor.get("vm_ip")
        return None
    
    def clear_ssh_keys_once(self):
        """
        Clear SSH keys once per session to avoid repeated clearing.
        This is a compatibility method for vks_sv_utils.py
        """
        logger.debug("Clearing SSH keys once per session")
        
        # Get supervisor VMs from our cache
        supervisors = self.get_supervisors()
        
        if not supervisors:
            logger.debug(f"WARNING: No supervisor VMs found, skipping SSH key clearing")
            return
        
        keys_cleared = 0
        for vm in supervisors:
            vm_ip = vm.get("vm_ip")
            if vm_ip:
                command = f"ssh-keygen -R {vm_ip}"
                try:
                    subprocess.run(command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    keys_cleared += 1
                    logger.debug(f"Cleared SSH key for {vm_ip}")
                except subprocess.SubprocessError as e:
                    logger.debug(f"Failed to clear SSH key for {vm_ip}: {e}")
        
        logger.debug(f"Cleared SSH keys for {keys_cleared} supervisor VMs")
    
    def get_chosen_supervisor_cluster_id(self):
        """
        Get the cluster ID of the chosen supervisor.
        This is a compatibility method for vks_sv_utils.py
        
        Returns:
            str: Cluster ID of the chosen supervisor, or None if not available
        """
        return self.get_cluster_id()
    
    def get_cached_password(self):
        """
        Get the cached supervisor root password.
        If not cached, retrieves it once and caches for future use.
        
        Returns:
            str: Supervisor root password, or None if not available
        """
        if self._cached_password is not None:
            logger.debug("Returning cached supervisor root password")
            return self._cached_password
        
        # Import here to avoid circular imports
        from .vks_sv_utils import getSvRootPassword
        
        cluster_id = self.get_cluster_id()
        logger.debug(f"Getting supervisor root password for cluster: {cluster_id}")
        
        password = getSvRootPassword(cluster_id)
        if password:
            self._cached_password = password
            logger.debug("Supervisor root password cached successfully")
        else:
            logger.debug(f"ERROR: Failed to get supervisor root password")
        
        return self._cached_password
    
    def clear_password_cache(self):
        """
        Clear the cached password (useful if password has changed).
        """
        logger.debug("Clearing cached supervisor root password")
        self._cached_password = None
    
    def clear_ssh_status_cache(self):
        """
        Clear the SSH connection status cache.
        This forces SSH availability to be re-checked on next access.
        """
        logger.debug(f"INFO: Clearing SSH connection status cache")
        self._ssh_connection_status.clear()
    
    def reset_cache(self):
        """
        Reset all cached data (useful for testing or forcing refresh).
        """
        logger.debug(f"INFO: Resetting SupervisorManager cache")
        self._supervisor_details = None
        self._chosen_supervisor_vm = None
        self._ssh_connection_status.clear()
        self._cached_password = None
        self._ssh_keys_cleared = False
    
    def get_supervisor_info(self):
        """
        Get information about the current supervisor cache state.
        
        Returns:
            dict: Information about cached supervisors and chosen supervisor
        """
        supervisor_vms = self.get_supervisors()
        return {
            "cache_initialized": self._supervisor_details is not None,
            "supervisor_count": len(supervisor_vms),
            "chosen_supervisor": self._chosen_supervisor_vm,
            "cluster_id": self.get_cluster_id(),
            "cluster_name": self.get_cluster_name(),
            "instance_id": self.get_instance_id()
        }
    
    def debug_cache_state(self):
        """
        Debug method to show the current state of the supervisor cache.
        """
        logger.debug(f"INFO: === SupervisorManager Debug Info ===")
        logger.debug(f"INFO: Cache initialized: {self._supervisor_details is not None}")
        
        if self._supervisor_details:
            logger.debug(f"INFO: Cluster ID: {self._supervisor_details.get('cluster_id')}")
            logger.debug(f"INFO: Cluster Name: {self._supervisor_details.get('supervisor_name')}")
            logger.debug(f"INFO: Instance ID: {self._supervisor_details.get('supervisor_instance_id')}")
            supervisor_vms = self._supervisor_details.get('supervisor_vms', [])
            logger.debug(f"INFO: Supervisor VMs count: {len(supervisor_vms)}")
            for i, vm in enumerate(supervisor_vms):
                logger.debug(f"INFO:   VM {i+1}: {vm}")
        else:
            logger.debug(f"INFO: No cached supervisor details available")
            
        logger.debug(f"INFO: Chosen supervisor: {self._chosen_supervisor_vm}")
        logger.debug(f"INFO: SSH status cache entries: {len(self._ssh_connection_status)}")
        logger.debug(f"INFO: === End Debug Info ===")
        
        return self._supervisor_details
    
    def execute_ssh_command(self, command, vm_ip=None, username="root", timeout=30):
        """
        Execute a command via SSH on a supervisor VM.
        
        Args:
            command (str): Command to execute
            vm_ip (str): IP address of VM to connect to (uses chosen supervisor if None)
            username (str): SSH username
            timeout (int): Command timeout in seconds
            
        Returns:
            tuple: (return_code, stdout, stderr)
        """
        if vm_ip is None:
            supervisor = self.choose_supervisor(check_ssh=True)
            if not supervisor:
                logger.debug(f"ERROR: No supervisor VM available for SSH command")
                return -1, "", "No supervisor VM available"
            vm_ip = supervisor.get("vm_ip")
        
        if paramiko is None:
            logger.debug(f"ERROR: paramiko not available, cannot execute SSH commands")
            return -1, "", "paramiko not available"
        
        logger.debug(f"Executing SSH command on {vm_ip}: {command}")
        
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect(vm_ip, username=username, timeout=10, look_for_keys=True, allow_agent=True)
            
            stdin, stdout, stderr = ssh.exec_command(command, timeout=timeout)
            
            # Wait for command to complete
            return_code = stdout.channel.recv_exit_status()
            stdout_data = stdout.read().decode('utf-8')
            stderr_data = stderr.read().decode('utf-8')
            
            ssh.close()
            
            logger.debug(f"SSH command completed with return code: {return_code}")
            return return_code, stdout_data, stderr_data
            
        except Exception as e:
            logger.debug(f"ERROR: SSH command failed on {vm_ip}: {e}")
            return -1, "", str(e)

# Global instance for easy access
supervisor_manager = SupervisorManager()
