import subprocess
import socket
import logging
import json
import warnings
import time
from typing import Optional, List, Dict, Any, Union, Generator
from contextlib import contextmanager
from cryptography.utils import CryptographyDeprecationWarning
with warnings.catch_warnings():
    warnings.filterwarnings('ignore', category=CryptographyDeprecationWarning)
    import paramiko
from vks.vks_lib.vks_db_utils import getSvcpvmDetails
from vks.vks_lib.common import Command

logging.getLogger("paramiko").setLevel(logging.CRITICAL)
logger = logging.getLogger(__name__)


@contextmanager
def ssh_connection(
    ip: str, 
    username: str, 
    password: str, 
    timeout: int = 30
) -> Generator[paramiko.SSHClient, None, None]:
    """
    Context manager for SSH connections that ensures proper cleanup.
    
    Args:
        ip: The IP address to connect to.
        username: The SSH username.
        password: The SSH password.
        timeout: Connection timeout in seconds.
        
    Yields:
        A connected paramiko.SSHClient instance.
        
    Example:
        with ssh_connection('192.168.1.1', 'root', 'password') as ssh:
            stdin, stdout, stderr = ssh.exec_command('ls -la')
            output = stdout.read().decode('utf-8')
    """
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.MissingHostKeyPolicy())
    try:
        paramiko.Transport._preferred_ciphers = (
            'aes128-ctr', 'aes192-ctr', 'aes256-ctr', 
            'aes128-cbc', 'aes192-cbc', 'aes256-cbc', 
            '3des-cbc', 'rsa-sha2-512', 'rsa-sha2-256', 
            'ecdsa-sha2-nistp256', 'ssh-ed25519'
        )
        ssh.connect(
            ip, 
            username=username, 
            password=password,
            look_for_keys=False,
            allow_agent=False,
            timeout=timeout
        )
        yield ssh
    finally:
        ssh.close()


def getSvRootPassword(cluster_id: Optional[str] = None) -> Optional[str]:
    """
    Get the supervisor root password for a specific cluster by parsing the output of decryptK8Pwd.py.
    If cluster_id is None, returns the first password found (for backward compatibility).
    """
    logger.debug("Getting supervisor root password")
    command = "/usr/lib/vmware-wcp/decryptK8Pwd.py"
    try:
        process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        output, error = process.communicate(timeout=15)

        if process.returncode != 0:
            logger.debug(f"ERROR: Failed to get supervisor root password: {error}")
            return None

        # Parse output for multiple clusters
        current_cluster = None
        current_pwd = None
        for line in output.splitlines():
            if line.startswith("Cluster:"):
                current_cluster = line.split("Cluster:", 1)[1].strip()
            elif line.startswith("PWD:"):
                current_pwd = line.split("PWD:", 1)[1].strip()
                if cluster_id is None or (current_cluster and current_cluster == cluster_id):
                    logger.debug(f"Successfully retrieved supervisor root password for cluster {current_cluster}")
                    return current_pwd
        logger.debug(f"ERROR: No root password found for cluster {cluster_id}")
        return None
    except subprocess.TimeoutExpired:
        logger.debug(f"ERROR: Timeout while getting supervisor root password")
        return None
    except Exception as e:
        logger.debug(f"ERROR: Exception while getting supervisor root password: {e}")
        return None 

def checkSshAvailability(ip: str, username: str = "root", timeout: int = 5) -> bool:
    """Check if SSH is available on the given IP address."""
    logger.debug(f"Checking SSH availability for {ip}:{22}")
    command = f"nc -z -w {timeout} {ip} 22"
    try:
        result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        is_available = result.returncode == 0
        if is_available:
            logger.debug(f"SSH is available on {ip}")
        else:
            logger.debug(f"SSH is not available on {ip}")
        return is_available
    except Exception as e:
        logger.debug(f"ERROR: Exception while checking SSH availability for {ip}: {e}")
        return False

def clearSvSshKeys() -> None:
    """
    Clear the SSH known hosts file for the supervisor VMs.
    This function removes any existing SSH keys for the supervisor VMs to avoid connection issues.
    """
    logger.debug("Clearing supervisor SSH keys from known_hosts")
    supervisor_vms = getSvcpvmDetails()
    
    if not supervisor_vms:
        logger.debug(f"WARNING: No supervisor VMs found, skipping SSH key clearing")
        return
    
    keys_cleared = 0
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            command = f"ssh-keygen -R {vm_ip}"
            try:
                subprocess.run(command, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                keys_cleared += 1
                logger.debug(f"Cleared SSH key for {vm_ip}")
            except Exception as e:
                logger.debug(f"WARNING: Failed to clear SSH key for {vm_ip}: {e}")
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping SSH key clearing")
    
    logger.debug(f"Cleared SSH keys for {keys_cleared} supervisor VMs")

def run_ssh_command(
    ip: str, 
    username: str, 
    command: str, 
    timeout: int = 30, 
    clear_keys_once: bool = True, 
    cluster_id: Optional[str] = None,
    max_retries: int = 2
) -> Optional[str]:
    """
    Run a command on a remote host via SSH with retry support.

    Args:
        ip: The hostname or IP address of the remote host.
        username: The username to use for SSH authentication.
        command: The command to run on the remote host.
        timeout: SSH timeout in seconds.
        clear_keys_once: Clear SSH keys only once per session.
        cluster_id: The cluster ID to use for password retrieval. If None, will auto-detect.
        max_retries: Maximum number of retry attempts for transient failures (default: 2).

    Returns:
        The output of the command executed on the remote host, or None on failure.
    """
    logger.debug(f"Running SSH command on {ip}: {command[:100]}{'...' if len(command) > 100 else ''}")
    
    # Clear SSH keys only once per session to avoid repeated clearing
    if clear_keys_once:
        from .vks_supervisor_manager import supervisor_manager
        supervisor_manager.clear_ssh_keys_once()
    else:
        clearSvSshKeys()
    
    # Use cached password from supervisor_manager to avoid repeated decryptK8Pwd.py calls
    from .vks_supervisor_manager import supervisor_manager
    password = supervisor_manager.get_cached_password()
    if not password:
        logger.debug(f"ERROR: Failed to get supervisor root password")
        return None
    
    last_error = None
    for attempt in range(max_retries + 1):
        try:
            # Use context manager for proper resource cleanup
            with ssh_connection(ip, username, password, timeout) as ssh:
                stdin, stdout, stderr = ssh.exec_command(command, timeout=timeout)
                output = stdout.read().decode('utf-8')
                error_output = stderr.read().decode('utf-8')
                
                if error_output:
                    logger.debug(f"WARNING: SSH command stderr on {ip}: {error_output[:200]}{'...' if len(error_output) > 200 else ''}")
                
                logger.debug(f"SSH command completed on {ip}, output length: {len(output)} chars")
                return output.strip()
        
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                # Retry on transient errors like "Timer expired" or connection issues
                logger.debug(f"WARNING: SSH command failed on {ip} (attempt {attempt + 1}/{max_retries + 1}): {e}. Retrying...")
                time.sleep(0.5)  # Brief pause before retry
            else:
                logger.debug(f"ERROR: SSH command failed on {ip} after {max_retries + 1} attempts: {e}")
    
    return None

def check_crictl_container_running(supervisor_ip: str, container_name: str) -> bool:
    """
    Check if a specific container is running on the supervisor VM.

    Args:
        supervisor_ip: The IP address of the supervisor VM.
        container_name: The name of the container to check.

    Returns:
        True if the container is running, False otherwise.
    """
    logger.debug(f"Checking if container '{container_name}' is running on {supervisor_ip}")
    
    try:
        output = run_ssh_command(supervisor_ip, "root", "crictl ps --name %s --quiet | xargs -r crictl inspect --output go-template --template '{{.status.state}}' 2>/dev/null" % container_name)
        is_running = output == "CONTAINER_RUNNING"
        
        if is_running:
            logger.debug(f"Container '{container_name}' is running on {supervisor_ip}")
        else:
            logger.debug(f"Container '{container_name}' is not running on {supervisor_ip} (state: {output})")
        
        return is_running
    except Exception as e:
        logger.debug(f"ERROR: Failed to check container '{container_name}' on {supervisor_ip}: {e}")
        return False

def run_kubectl_get_command(
    supervisor_ip: str, 
    resource: str, 
    namespace: str = "-A", 
    fields: Optional[List[str]] = None
) -> Union[Dict[str, Any], str]:
    """
    Run a kubectl command on the supervisor VM.

    Args:
        supervisor_ip: The IP address of the supervisor VM.
        resource: The Kubernetes resource to get.
        namespace: The namespace to use. Defaults to "-A" (all namespaces).
        fields: List of fields to return using jsonpath. Defaults to None.

    Returns:
        The JSON output of the kubectl command as a dict, or raw string if fields specified.
    """
    try:
        command = f"kubectl get {resource}"
        
        if fields:
            field_selector = ",".join(fields)
            command += f" -o jsonpath='{field_selector}'"
        else:
            command += " -o json"
            
        if namespace != "-A":
            command += f" -n {namespace}"
        else:
            command += " -A"
            
        logger.debug(f"Running kubectl command on {supervisor_ip}: {command}")
        result = run_ssh_command(supervisor_ip, "root", command)
        logger.debug(f"Kubectl command completed on {supervisor_ip}")
        
        if not fields:  # Only parse JSON if we're not using jsonpath
            return json.loads(result)
        else:
            return result
            
    except Exception as e:
        logger.debug(f"ERROR: Kubectl command failed on {supervisor_ip}: {e}")
        raise

def check_port_connectivity(ip: str, port: int, timeout: int = 5) -> bool:
    """
    Check if a specific port is open on a given IP address.

    Args:
        ip: The IP address to check.
        port: The port number to check.
        timeout: Timeout in seconds for the connection attempt.

    Returns:
        True if the port is open, False otherwise.
    """
    logger.debug(f"Checking port {port} on {ip}")
    command = f"nc -z -w {timeout} {ip} {port}"
    
    try:
        result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        is_open = result.returncode == 0
        
        if is_open:
            logger.debug(f"Port {port} is open on {ip}")
        else:
            logger.debug(f"Port {port} is closed on {ip}")
        
        return is_open
    except Exception as e:
        logger.debug(f"ERROR: Exception while checking port {port} on {ip}: {e}")
        return False