import logging
import json
import os
import base64
import stat
from .vks_sv_utils import run_ssh_command
from .vks_supervisor_manager import supervisor_manager

logger = logging.getLogger(__name__)

# Module-level caches for TKC manager and SSH keys
_tkc_manager_cache = {}
_ssh_key_cache = {}


def get_tkc_manager():
    """
    Get or create a TKCManager instance using the chosen supervisor IP.
    Returns None if no supervisor is available.
    """
    logger.debug("Getting TKC manager instance")
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    if not supervisor_ip:
        logger.debug(f"ERROR: No supervisor IP available for TKC checks")
        return None
    
    if supervisor_ip not in _tkc_manager_cache:
        logger.debug(f"Creating new TKCManager for supervisor {supervisor_ip}")
        _tkc_manager_cache[supervisor_ip] = TKCManager(supervisor_ip)
    else:
        logger.debug(f"Using cached TKCManager for supervisor {supervisor_ip}")
    
    return _tkc_manager_cache[supervisor_ip]


def get_ssh_key_for_cluster(tkc_manager, cluster_name, namespace):
    """
    Get or create SSH key for a TKC cluster.
    Caches keys to avoid repeated creation.
    """
    cache_key = f"{namespace}/{cluster_name}"
    logger.debug(f"Getting SSH key for cluster {cache_key}")
    if cache_key not in _ssh_key_cache:
        logger.debug(f"Creating new SSH key for cluster {cache_key}")
        ssh_key_path = tkc_manager.create_tkc_ssh_key(cluster_name, namespace)
        if ssh_key_path:
            logger.debug(f"SSH key created at {ssh_key_path} for cluster {cache_key}")
            _ssh_key_cache[cache_key] = ssh_key_path
        else:
            logger.debug(f"ERROR: Failed to create SSH key for cluster {cache_key}")
            return None
    else:
        logger.debug(f"Using cached SSH key for cluster {cache_key}")
    return _ssh_key_cache[cache_key]


def run_kubectl_on_tkc(tkc_manager, cluster_name, namespace, ssh_key_path, command):
    """
    Run a kubectl command on a TKC cluster's control plane.
    Returns the parsed JSON output or None on failure.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Running kubectl command on TKC cluster {cluster_id}: {command}")
    try:
        result = tkc_manager.run_kubectl_command_on_tkc_control_plane(
            cluster_name, namespace, ssh_key_path, command
        )
        if result:
            logger.debug(f"kubectl command succeeded on cluster {cluster_id}, parsing JSON output")
            return json.loads(result)
        logger.debug(f"WARNING: kubectl command returned empty result on cluster {cluster_id}")
        return None
    except json.JSONDecodeError as e:
        logger.debug(f"ERROR: Failed to parse kubectl output for cluster {cluster_id}: {e}")
        return None
    except Exception as e:
        logger.debug(f"ERROR: Failed to run kubectl on cluster {cluster_id}: {e}")
        return None


def parse_cluster_version(cluster):
    """
    Parse Kubernetes version from a Cluster resource (from get_tkc_clusters).
    Prefers spec.topology.version, fallback spec.version.
    Returns (major, minor) tuple or None if unparseable/missing.
    Example: "v1.32.3+vmware.1-fips" -> (1, 32).
    """
    if not cluster or not isinstance(cluster, dict):
        return None
    spec = cluster.get("spec") or {}
    version_str = spec.get("topology", {}).get("version") or spec.get("version")
    if not version_str or not isinstance(version_str, str):
        return None
    version_str = version_str.strip()
    if version_str.startswith("v"):
        version_str = version_str[1:]
    if "+" in version_str:
        version_str = version_str.split("+")[0]
    parts = version_str.split(".")
    if len(parts) < 2:
        return None
    try:
        major = int(parts[0])
        minor = int(parts[1])
        return (major, minor)
    except (ValueError, TypeError):
        return None


def run_kubectl_on_supervisor(tkc_manager, command):
    """
    Run a kubectl command on the supervisor (SSH to supervisor, then kubectl).
    Returns raw output string or None on failure.
    """
    if not tkc_manager:
        return None
    try:
        output = run_ssh_command(
            tkc_manager.supervisor_ip,
            getattr(tkc_manager, "supervisor_username", "root"),
            command,
        )
        return output
    except Exception as e:
        logger.debug(f"ERROR: Failed to run kubectl on supervisor: {e}")
        return None


def run_check_on_all_clusters(single_cluster_check_func, title, check_name):
    """
    Generic iterator for running a check across all TKC clusters.
    
    Args:
        single_cluster_check_func: Function that takes (tkc_manager, cluster_name, namespace, ssh_key_path)
                                   and returns (result, details) tuple
        title: Title for the check result
        check_name: Name used in log messages (e.g., "nodes", "pods")
    
    Returns:
        dict: Result dict with title, result, and details
    """
    result = "PASS"
    details_list = []
    
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        clusters = tkc_manager.get_tkc_clusters()
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        
        failed_count = 0
        warn_count = 0
        checked_count = 0
        
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            phase = cluster.get("status", {}).get("phase", "unknown")
            
            # Skip clusters that aren't provisioned
            if phase != "Provisioned":
                details_list.append(f"Cluster {namespace}/{name}: Skipped (phase={phase})")
                continue
            
            ssh_key_path = get_ssh_key_for_cluster(tkc_manager, name, namespace)
            if not ssh_key_path:
                details_list.append(f"Cluster {namespace}/{name}: Failed to get SSH key")
                result = "FAIL"
                failed_count += 1
                continue
            
            check_result, check_details = single_cluster_check_func(
                tkc_manager, name, namespace, ssh_key_path
            )
            
            details_list.append(check_details)
            checked_count += 1
            
            if check_result == "FAIL":
                result = "FAIL"
                failed_count += 1
            elif check_result == "WARN":
                warn_count += 1
                if result != "FAIL":
                    result = "WARN"
        
        if not details_list:
            details = "No TKC clusters to check"
        else:
            details = "\n".join(details_list[:10])
            if len(details_list) > 10:
                details += f"\n(and {len(details_list) - 10} more clusters)"
        
        logger.debug(f"INFO: TKC {check_name} check completed: {result} ({failed_count}/{checked_count} failed)")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check TKC cluster {check_name}: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check TKC cluster {check_name}: {e}"}


def parse_kubeadm_cert_output(output):
    """
    Parse kubeadm certs check-expiration output.
        
    Returns list of dicts with cert_name, expires, residual_time, residual_days.
    """
    certs = []
    if not output:
        return certs
    
    lines = output.strip().split('\n')
    in_cert_section = False
    in_ca_section = False
    
    for line in lines:
        line = line.strip()
        
        # Skip empty lines and header lines
        if not line:
            continue
        if line.startswith('[check-expiration]'):
            continue
        if line.startswith('CERTIFICATE') and 'EXPIRES' in line:
            # This is a header line - determine which section
            if 'CERTIFICATE AUTHORITY' in line and line.startswith('CERTIFICATE AUTHORITY'):
                in_ca_section = True
                in_cert_section = False
            else:
                in_cert_section = True
                in_ca_section = False
            continue
        
        # Parse certificate lines
        if in_cert_section or in_ca_section:
            # Split by multiple spaces to handle variable column widths
            parts = line.split()
            if len(parts) >= 5:
                cert_name = parts[0]
                
                # Find the date pattern (e.g., "Jan 22, 2027 08:09 UTC")
                # The date spans multiple parts
                try:
                    # Look for month name to find date start
                    date_start_idx = None
                    for i, part in enumerate(parts):
                        if part in ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                                   'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']:
                            date_start_idx = i
                            break
                    
                    if date_start_idx is not None and date_start_idx + 4 < len(parts):
                        # Date format: "Jan 22, 2027 08:09 UTC"
                        expires = f"{parts[date_start_idx]} {parts[date_start_idx+1]} {parts[date_start_idx+2]} {parts[date_start_idx+3]} {parts[date_start_idx+4]}"
                        residual_time = parts[date_start_idx + 5] if date_start_idx + 5 < len(parts) else "unknown"
                        
                        # Parse residual time to days
                        residual_days = parse_residual_time(residual_time)
                        
                        certs.append({
                            "cert_name": cert_name,
                            "expires": expires,
                            "residual_time": residual_time,
                            "residual_days": residual_days,
                            "is_ca": in_ca_section
                        })
                except (IndexError, ValueError) as e:
                    logger.debug(f"Failed to parse cert line '{line}': {e}")
                    continue
    
    return certs


def parse_residual_time(residual_time):
    """
    Parse residual time string to days.
    Examples: "363d", "9y", "30d", "invalid"
    Returns integer days or -1 if expired/invalid.
    """
    if not residual_time or residual_time == "unknown":
        return -1
    
    try:
        residual_time = residual_time.strip()
        if residual_time.endswith('d'):
            return int(residual_time[:-1])
        elif residual_time.endswith('y'):
            return int(residual_time[:-1]) * 365
        elif residual_time.endswith('h'):
            hours = int(residual_time[:-1])
            return max(0, hours // 24)  # Convert hours to days
        elif residual_time.endswith('m'):
            # Minutes - essentially 0 days
            return 0
        else:
            # Try to parse as plain number (days)
            return int(residual_time)
    except (ValueError, AttributeError):
        return -1

class TKCManager:
    """
    Manages TKC (Tanzu Kubernetes Cluster) operations with cached data and single supervisor session.
    """
    
    def __init__(self, supervisor_ip, supervisor_username="root"):
        """
        Initialize TKC manager with a specific supervisor.
        
        Args:
            supervisor_ip (str): IP address of the supervisor to use for all operations
            supervisor_username (str): Username for supervisor SSH (default: root)
        """
        self.supervisor_ip = supervisor_ip
        self.supervisor_username = supervisor_username
        self._clusters_cache = None
        self._control_plane_ips_cache = {}
        logger.debug(f"TKC Manager initialized with supervisor: {supervisor_ip}")
    
    def get_tkc_clusters(self, force_refresh=False):
        """
        Get the list of TKG clusters from all namespaces (cached).
        
        Args:
            force_refresh (bool): Force refresh of cached data
            
        Returns:
            dict: JSON output containing cluster information, or None if failed
        """
        if self._clusters_cache is not None and not force_refresh:
            logger.debug("Returning cached TKC clusters")
            return self._clusters_cache
        
        logger.debug(f"INFO: Getting TKG cluster list from all namespaces")
        
        try:
            command = "kubectl get cluster -A -o json"
            output = run_ssh_command(self.supervisor_ip, self.supervisor_username, command)
            
            if not output:
                logger.debug(f"ERROR: No output from kubectl get cluster command")
                return None
            
            clusters = json.loads(output)
            
            if clusters and "items" in clusters:
                logger.debug(f"INFO: Found {len(clusters['items'])} TKG clusters")
                for cluster in clusters["items"]:
                    namespace = cluster.get("metadata", {}).get("namespace", "unknown")
                    name = cluster.get("metadata", {}).get("name", "unknown")
                    phase = cluster.get("status", {}).get("phase", "unknown")
                    logger.debug(f"Cluster: {name} in namespace {namespace}, phase: {phase}")
            else:
                logger.debug(f"WARNING: No TKG clusters found or invalid response")
            
            # Cache the results
            self._clusters_cache = clusters
            return clusters
            
        except json.JSONDecodeError as e:
            logger.debug(f"ERROR: Failed to parse cluster JSON: {e}")
            return None
        except Exception as e:
            logger.debug(f"ERROR: Failed to get TKG clusters: {e}")
            return None
    
    def create_tkc_ssh_key(self, cluster_name, namespace, temp_dir="/tmp"):
        """
        Create SSH key file for TKG cluster access on the supervisor VM.
        
        Args:
            cluster_name (str): Name of the TKG cluster
            namespace (str): Namespace where the cluster exists
            temp_dir (str): Directory on supervisor to store the SSH key file
            
        Returns:
            str: Path to the created SSH key file on supervisor, or None if failed
        """
        logger.debug(f"INFO: Creating SSH key for TKG cluster {cluster_name} in namespace {namespace}")
        
        try:
            # Get the SSH private key from the secret
            secret_name = f"{cluster_name}-ssh"
            logger.debug(f"Getting SSH key from secret: {secret_name}")
            
            command = f"kubectl get secret {secret_name} -o jsonpath='{{.data.ssh-privatekey}}' -n {namespace}"
            encoded_key = run_ssh_command(self.supervisor_ip, self.supervisor_username, command)
            
            if not encoded_key:
                logger.debug(f"ERROR: Failed to get SSH key from secret {secret_name}")
                return None
            
            # Create the key file path on supervisor
            key_file_path = f"{temp_dir}/{cluster_name}-ssh-key"
            logger.debug(f"Creating SSH key file at: {key_file_path}")
            
            # Write the key directly on the supervisor using echo and base64 decode
            # Use a command that returns success/failure status we can check
            write_key_command = f"echo '{encoded_key}' | base64 -d > {key_file_path} && echo 'KEY_WRITTEN_OK'"
            
            write_result = run_ssh_command(self.supervisor_ip, self.supervisor_username, write_key_command)
            
            # Verify the write command succeeded
            if write_result is None or "KEY_WRITTEN_OK" not in str(write_result):
                logger.debug(f"ERROR: Failed to write SSH key file for cluster {cluster_name}")
                return None
            
            logger.debug(f"INFO: Successfully created SSH key file: {key_file_path}")
            
        except Exception as e:
            logger.debug(f"ERROR: Failed to create SSH key for cluster {cluster_name}: {e}")
            return None
        
        # Set correct permissions (read-only for owner) - best effort, non-fatal
        # This is outside the try/except so a timeout here won't fail the whole operation
        try:
            chmod_command = f"chmod 400 {key_file_path}"
            chmod_result = run_ssh_command(self.supervisor_ip, self.supervisor_username, chmod_command)
            if chmod_result is None:
                logger.debug(f"WARNING: Failed to set permissions on {key_file_path}, but key file is usable")
            else:
                logger.debug(f"Set permissions 400 on {key_file_path} on supervisor VM")
        except Exception as chmod_error:
            logger.debug(f"WARNING: chmod failed for {key_file_path}: {chmod_error}, but key file was created successfully")
        
        return key_file_path
    
    def find_control_plane_ip(self, cluster_name, namespace, force_refresh=False):
        """
        Find the control plane VM IP for a given TKC cluster (cached).
        
        Args:
            cluster_name (str): Name of the TKG cluster
            namespace (str): Namespace where the cluster exists
            force_refresh (bool): Force refresh of cached data
            
        Returns:
            str: IP address of the control plane node, or None if not found
        """
        cache_key = f"{namespace}/{cluster_name}"
        
        if cache_key in self._control_plane_ips_cache and not force_refresh:
            logger.debug(f"Returning cached control plane IP for {cache_key}")
            return self._control_plane_ips_cache[cache_key]
        
        logger.debug(f"INFO: Finding control plane IP for cluster {cluster_name}")
        
        try:
            # Get VMs for the cluster
            command = f"kubectl get vm -n {namespace} -l cluster.x-k8s.io/cluster-name={cluster_name},capv.vmware.com/cluster.role=controlplane -o json"
            logger.debug(f"Getting control plane VMs with command: {command}")
            
            vm_result = run_ssh_command(self.supervisor_ip, self.supervisor_username, command)
            if not vm_result:
                logger.debug(f"WARNING: Failed to get control plane VMs")
                return None
            
            try:
                vms_data = json.loads(vm_result)
            except json.JSONDecodeError as e:
                logger.debug(f"ERROR: Failed to parse VM JSON data: {e}")
                return None
            
            if not vms_data.get("items"):
                logger.debug(f"WARNING: No control plane VMs found for cluster {cluster_name}")
                return None
            
            # Get the first control plane VM
            control_plane_vm = vms_data["items"][0]
            vm_name = control_plane_vm.get("metadata", {}).get("name", "unknown")
            
            # Extract the primary IP
            primary_ip = control_plane_vm.get("status", {}).get("network", {}).get("primaryIP4")
            
            if primary_ip:
                logger.debug(f"INFO: Found control plane VM {vm_name} with IP: {primary_ip}")
                # Cache the result
                self._control_plane_ips_cache[cache_key] = primary_ip
                return primary_ip
            else:
                logger.debug(f"WARNING: No primary IP found for control plane VM {vm_name}")
                return None
                
        except Exception as e:
            logger.debug(f"WARNING: Failed to find control plane IP: {e}")
            return None
    
    def find_all_control_plane_ips(self, cluster_name, namespace, force_refresh=False):
        """
        Find all control plane VM IPs for a given TKC cluster.
        
        Args:
            cluster_name (str): Name of the TKG cluster
            namespace (str): Namespace where the cluster exists
            force_refresh (bool): Force refresh of cached data
            
        Returns:
            list: List of dicts with 'name' and 'ip' keys for each control plane node,
                  or empty list if none found
        """
        logger.debug(f"INFO: Finding all control plane IPs for cluster {cluster_name}")
        
        try:
            # Get VMs for the cluster with controlplane role
            command = f"kubectl get vm -n {namespace} -l cluster.x-k8s.io/cluster-name={cluster_name},capv.vmware.com/cluster.role=controlplane -o json"
            logger.debug(f"Getting control plane VMs with command: {command}")
            
            vm_result = run_ssh_command(self.supervisor_ip, self.supervisor_username, command)
            if not vm_result:
                logger.debug(f"WARNING: Failed to get control plane VMs")
                return []
            
            try:
                vms_data = json.loads(vm_result)
            except json.JSONDecodeError as e:
                logger.debug(f"WARNING: Failed to parse VM JSON data: {e}")
                return []
            
            if not vms_data.get("items"):
                logger.debug(f"WARNING: No control plane VMs found for cluster {cluster_name}")
                return []
            
            control_plane_nodes = []
            for vm in vms_data["items"]:
                vm_name = vm.get("metadata", {}).get("name", "unknown")
                primary_ip = vm.get("status", {}).get("network", {}).get("primaryIP4")
                
                if primary_ip:
                    control_plane_nodes.append({
                        "name": vm_name,
                        "ip": primary_ip
                    })
                    logger.debug(f"Found control plane VM {vm_name} with IP: {primary_ip}")
                else:
                    logger.debug(f"WARNING: No primary IP found for control plane VM {vm_name}")
            
            logger.debug(f"INFO: Found {len(control_plane_nodes)} control plane nodes for cluster {cluster_name}")
            return control_plane_nodes
                
        except Exception as e:
            logger.debug(f"WARNING: Failed to find all control plane IPs: {e}")
            return []
    
    def ssh_to_tkc_node(self, node_ip, ssh_key_path, command_to_run="whoami"):
        """
        SSH into a specific TKC node and execute a command as root.
        
        Args:
            node_ip (str): IP address of the TKC node to connect to
            ssh_key_path (str): Path to the SSH private key file on supervisor
            command_to_run (str): Command to execute on the node
            
        Returns:
            str: Output of the command, or None if failed
        """
        logger.debug(f"SSHing to TKC node {node_ip}")
        
        try:
            logger.debug(f"Connecting to node {node_ip} via supervisor {self.supervisor_ip}")
            
            # Create the SSH command to connect to the TKC node and run command as root
            ssh_command = f"""ssh -i {ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null vmware-system-user@{node_ip} 'sudo su -l -c "{command_to_run}"'"""
            
            logger.debug(f"Executing SSH command: {ssh_command[:100]}...")
            
            # Execute the SSH command from the supervisor
            result = run_ssh_command(self.supervisor_ip, self.supervisor_username, ssh_command)
            
            if result:
                logger.debug(f"Successfully executed command on TKC node {node_ip}")
                return result.strip()
            else:
                logger.debug(f"WARNING: Failed to execute command on TKC node {node_ip}")
                return None
                
        except Exception as e:
            logger.debug(f"WARNING: Failed to SSH to TKC node {node_ip}: {e}")
            return None
    
    def ssh_to_tkc_control_plane(self, cluster_name, namespace, ssh_key_path, command_to_run="whoami"):
        """
        SSH into the TKC control plane node and execute a command as root.
        
        Args:
            cluster_name (str): Name of the TKG cluster
            namespace (str): Namespace where the cluster exists  
            ssh_key_path (str): Path to the SSH private key file on supervisor
            command_to_run (str): Command to execute on the control plane node
            
        Returns:
            str: Output of the command, or None if failed
        """
        logger.debug(f"SSHing to TKC control plane for cluster {cluster_name}")
        
        try:
            # Find the control plane IP (uses cache if available)
            control_plane_ip = self.find_control_plane_ip(cluster_name, namespace)
            if not control_plane_ip:
                logger.debug(f"WARNING: Could not find control plane IP")
                return None
            
            logger.debug(f"Connecting to control plane {control_plane_ip} via supervisor {self.supervisor_ip}")
            
            # Create the SSH command to connect to the TKC control plane and run command as root
            ssh_command = f"""ssh -i {ssh_key_path} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null vmware-system-user@{control_plane_ip} 'sudo su -l -c "{command_to_run}"'"""
            
            logger.debug(f"Executing SSH command: {ssh_command[:100]}...")
            
            # Execute the SSH command from the supervisor
            result = run_ssh_command(self.supervisor_ip, self.supervisor_username, ssh_command)
            
            if result:
                logger.debug(f"Successfully executed command on TKC control plane")
                return result.strip()
            else:
                logger.debug(f"WARNING: Failed to execute command on TKC control plane")
                return None
                
        except Exception as e:
            logger.debug(f"WARNING: Failed to SSH to TKC control plane: {e}")
            return None
    
    def run_kubectl_command_on_tkc_control_plane(self, cluster_name, namespace, ssh_key_path, command):
        """
        Run a kubectl command on the TKC control plane node.
        
        Args:
            cluster_name (str): Name of the TKG cluster
            namespace (str): Namespace where the cluster exists
            ssh_key_path (str): Path to the SSH private key file on supervisor
            command (str): The kubectl command to run
            
        Returns:
            str: Output of the kubectl command, or None if failed
        """
        logger.debug(f"Running kubectl command on TKC control plane for cluster {cluster_name}")
        
        commands = [
            "export KUBECONFIG=/etc/kubernetes/admin.conf",
            command
        ]
        combined_command = " && ".join(commands)
        logger.debug(f"Combined command to run: {combined_command}")
        try:
            # SSH to the control plane and run the combined command
            result = self.ssh_to_tkc_control_plane(cluster_name, namespace, ssh_key_path, combined_command)
            if result:
                logger.debug(f"Successfully ran kubectl command: {command}")
                return result.strip()
            else:
                logger.debug(f"WARNING: Failed to run kubectl command on TKC control plane")
                return None
        except Exception as e:
            logger.debug(f"WARNING: Exception occurred while running kubectl command: {e}")
            return None

    def run_etcdctl_command_on_tkc_node(self, node_ip, ssh_key_path, etcdctl_args):
        """
        Run etcdctl command on a TKC control plane node with proper path and certificates.
        
        On TKC guest cluster control plane nodes, etcdctl is located in a containerd
        snapshot directory and requires explicit certificate paths.
        
        Args:
            node_ip (str): IP address of the TKC control plane node
            ssh_key_path (str): Path to the SSH private key file on supervisor
            etcdctl_args (str): Arguments to pass to etcdctl (e.g., "member list -w json")
            
        Returns:
            str: Output of the etcdctl command, or None if failed
        """
        logger.debug(f"Running etcdctl command on TKC node {node_ip}: {etcdctl_args}")
        
        # etcdctl binary is in containerd snapshot directory with glob pattern for snapshot ID
        # Certificate paths are standard Kubernetes PKI locations
        etcdctl_cmd = (
            '/var/lib/containerd/io.containerd.snapshotter.v1.overlayfs/snapshots/*/fs/usr/local/bin/etcdctl '
            '--cert /etc/kubernetes/pki/etcd/peer.crt '
            '--key /etc/kubernetes/pki/etcd/peer.key '
            '--cacert /etc/kubernetes/pki/etcd/ca.crt'
        )
        full_command = f"{etcdctl_cmd} {etcdctl_args}"
        
        try:
            result = self.ssh_to_tkc_node(node_ip, ssh_key_path, full_command)
            if result:
                logger.debug(f"Successfully ran etcdctl command on TKC node {node_ip}")
                return result.strip()
            else:
                logger.debug(f"WARNING: Failed to run etcdctl command on TKC node {node_ip}")
                return None
        except Exception as e:
            logger.debug(f"WARNING: Exception occurred while running etcdctl command on {node_ip}: {e}")
            return None

    def setup_tkc_kubectl_access(self, cluster_name, namespace, ssh_key_path):
        """
        Set up kubectl access on the TKC control plane and run some basic checks.
        
        Args:
            cluster_name (str): Name of the TKG cluster
            namespace (str): Namespace where the cluster exists
            ssh_key_path (str): Path to the SSH private key file on supervisor
            
        Returns:
            dict: Results of the kubectl checks
        """
        logger.debug(f"INFO: Setting up kubectl access for TKC cluster {cluster_name}")
        
        try:
            # Test basic connectivity first
            whoami_result = self.ssh_to_tkc_control_plane(cluster_name, namespace, ssh_key_path, "whoami")
            if not whoami_result or "root" not in whoami_result:
                logger.debug(f"ERROR: Failed to establish root access to TKC control plane")
                return {"error": "Failed to establish root access"}
            
            logger.debug(f"INFO: Successfully established root access to TKC control plane")
            
            # Set up KUBECONFIG and run kubectl commands
            kubectl_commands = [
                "export KUBECONFIG=/etc/kubernetes/admin.conf",
                "kubectl get nodes",
                "kubectl get pods -A | head -10",
                "kubectl version"  # Removed --short flag as it's not supported
            ]
            
            # Combine commands with && to ensure KUBECONFIG is set for all
            combined_command = " && ".join(kubectl_commands)
            
            logger.debug(f"Running kubectl commands on TKC control plane")
            kubectl_result = self.ssh_to_tkc_control_plane(cluster_name, namespace, ssh_key_path, combined_command)
            
            if kubectl_result:
                logger.debug(f"INFO: Successfully executed kubectl commands on TKC control plane")
                return {
                    "status": "success",
                    "whoami": whoami_result,
                    "kubectl_output": kubectl_result
                }
            else:
                logger.debug(f"ERROR: Failed to execute kubectl commands")
                return {
                    "status": "partial_success", 
                    "whoami": whoami_result,
                    "error": "Failed to execute kubectl commands"
                }
                
        except Exception as e:
            logger.debug(f"ERROR: Failed to set up TKC kubectl access: {e}")
            return {"error": f"Exception occurred: {e}"}
    
    def get_first_cluster_info(self):
        """
        Get information about the first available TKC cluster.
        
        Returns:
            tuple: (cluster_info, cluster_name, namespace) or (None, None, None) if no clusters
        """
        clusters = self.get_tkc_clusters()
        if not clusters or not clusters.get("items"):
            logger.debug(f"ERROR: No TKG clusters found")
            return None, None, None
        
        # Pick the first cluster
        first_cluster = clusters["items"][0]
        cluster_name = first_cluster.get("metadata", {}).get("name")
        namespace = first_cluster.get("metadata", {}).get("namespace")
        
        if not cluster_name or not namespace:
            logger.debug(f"ERROR: Invalid cluster metadata")
            return first_cluster, None, None
        
        logger.debug(f"INFO: Selected first cluster: {cluster_name} in namespace {namespace}")
        return first_cluster, cluster_name, namespace
    
    def setup_first_tkc_complete(self, temp_dir="/tmp"):
        """
        Complete setup for the first TKC cluster: get cluster, create SSH key, and test kubectl access.
        
        Args:
            temp_dir (str): Directory on supervisor to store SSH key
            
        Returns:
            dict: Complete results of the setup process
        """
        logger.debug(f"INFO: Setting up complete access for first TKG cluster")
        
        try:
            # Get first cluster info
            cluster_info, cluster_name, namespace = self.get_first_cluster_info()
            if not cluster_name or not namespace:
                return {
                    "status": "fail",
                    "error": "No valid TKG clusters found"
                }
            
            # Create SSH key
            ssh_key_path = self.create_tkc_ssh_key(cluster_name, namespace, temp_dir)
            if not ssh_key_path:
                return {
                    "status": "fail", 
                    "cluster_name": cluster_name,
                    "error": "Failed to create SSH key"
                }
            
            # Test kubectl access
            kubectl_results = self.setup_tkc_kubectl_access(cluster_name, namespace, ssh_key_path)
            
            return {
                "status": kubectl_results.get("status", "fail"),
                "cluster_info": cluster_info,
                "cluster_name": cluster_name,
                "namespace": namespace,
                "ssh_key_path": ssh_key_path,
                "kubectl_output": kubectl_results.get("kubectl_output"),
                "error": kubectl_results.get("error")
            }
            
        except Exception as e:
            logger.debug(f"ERROR: Failed to setup first TKC cluster: {e}")
            return {
                "status": "fail",
                "error": f"Exception occurred: {e}"
            }
