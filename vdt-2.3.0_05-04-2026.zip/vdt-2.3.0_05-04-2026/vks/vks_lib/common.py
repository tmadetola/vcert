import sys
import threading
import shlex
import subprocess as subproc
import logging
import json 
from typing import Optional, List, Union

logger = logging.getLogger(__name__)
_DefaultCommmandEncoding = sys.getfilesystemencoding()


def run_command(cmd: Union[List[str], str], stdin: Optional[str] = None, 
                quiet: bool = False, close_fds: bool = False,
                encoding: str = _DefaultCommmandEncoding, 
                log_command: bool = True) -> bytes:
    """
    Run a command and return the output.

    Args:
        cmd (list or str): The command to run. If it is a string, the command will be executed through the shell.
        stdin (str, optional): Input to be passed to the command. The input will be sent via stdin.
        quiet (bool, optional): If True, suppresses any output to stdout and stderr. Defaults to False.
        close_fds (bool, optional): If True, close all file descriptors, except stdin, stdout, and stderr before executing the command. Defaults to False.
        encoding (str, optional): The encoding to be used for stdin, stdout, and stderr. Defaults to _DefaultCommmandEncoding.
        log_command (bool, optional): If True, logs the executed command. Defaults to True.

    Returns:
        bytes: The output of the command.

    Note:
        This function uses subprocess.Popen to run the command.
    """
    process = subproc.Popen(cmd, stdout=subproc.PIPE,
                            stderr=subproc.PIPE, stdin=subproc.PIPE)
    if sys.version_info[0] >= 3 and isinstance(stdin, str):
        stdin_bytes = stdin.encode(encoding)
    else:
        stdin_bytes = stdin
    stdout, stderr = process.communicate(stdin_bytes)
    return stdout


class RunCommand(object):
    # Based on jcollado's solution:
    # http://stackoverflow.com/questions/1191374/subprocess-with-timeout/4825933#4825933
    """
    A class representing a command to be executed.

    Attributes:
        cmd (str or list): The command to be executed. If a string, it will be split into a list of arguments.
        stdin (str): The input to be passed to the command's standard input.
        quiet (bool): If True, suppresses the output of the command.
        close_fds (bool): If True, closes all file descriptors before executing the command.
        encoding (str): The encoding to be used for the input and output of the command.
        shell (bool): If True, runs the command through the shell.
        response (str): The response to be passed to the command's standard input.
        command_timeout (int): The maximum time in seconds to wait for the command to complete.
    """
    def __init__(self, cmd, stdin=None, quiet=False, close_fds=False, encoding=_DefaultCommmandEncoding, shell=False,
                 response=None):
        """
        Initialize a Command object.

        Args:
            cmd (str or list): The command to execute. If it is a string, it will be split into a list of arguments.
            stdin (str or None): Input to be passed to the subprocess.
            quiet (bool): Flag indicating whether to suppress output from the subprocess.
            close_fds (bool): Flag indicating whether to close all file descriptors except stdin, stdout, and stderr.
            encoding (str): The character encoding to be used for the subprocess.
            shell (bool): Flag indicating whether the command should be executed through the shell.
            response (str or None): Output of the subprocess command.
            command_timeout (int): Timeout value in seconds for the command execution.

        Raises:
            None

        Returns:
            None
        """
        self.shell = shell
        self.stdin = stdin
        self.encoding = encoding
        try:
            if isinstance(cmd, basestring):
                cmd = shlex.split(cmd)
        except NameError:
            # basestring doesn't exist in Python 3
            if isinstance(cmd, str):
                cmd = shlex.split(cmd)
        self.cmd = cmd
        self.process = None
        self.error = None
        self.response = response

    def run(self):
        """
        Executes a command with optional input and captures the output and error streams.

        Raises an error if the Python version is less than 3 or the input stream is not a string.

        Returns:
            Tuple[str, str, bool]: A tuple containing the command output as a string, the error message as a string.

        Raises:
            TypeError: If the Python version is less than 3 or the input stream is not a string.
        """
        if sys.version_info[0] >= 3 and isinstance(self.stdin, str):
            self.stdin = self.stdin.encode(self.encoding)
        if self.response:
            self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=subproc.PIPE,
                                         shell=self.shell)
            self.process.stdin.write(self.response.encode(self.encoding))
        else:
            self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=self.stdin,
                                         shell=self.shell)
        self.output, self.error = self.process.communicate(self.stdin)

        return self.output.decode('utf-8'), self.error.decode('utf-8')

class FailedCommand(Exception):
    """
    Helps when handling command failures.
    """

    def __init__(self, cmd, error, msg="Command failed!"):
        """
        Initialize a CommandError instance.

        Args:
            cmd (str): The command that failed.
            error (str): The specific error message related to the failure.
            msg (str, optional): The custom error message to display. Defaults to 'Command failed!'.

        Raises:
            None.

        Returns:
            None.
        """        
        self.cmd = cmd
        self.error = error
        self.msg = msg
        super().__init__(self.msg)


class Command(object):
    # Based on jcollado's solution:
    # http://stackoverflow.com/questions/1191374/subprocess-with-timeout/4825933#4825933
    """
    A class representing a command to be executed.

    Attributes:
        cmd (str or list): The command to be executed. If a string, it will be split into a list of arguments.
        stdin (str): The input to be passed to the command's standard input.
        quiet (bool): If True, suppresses the output of the command.
        close_fds (bool): If True, closes all file descriptors before executing the command.
        encoding (str): The encoding to be used for the input and output of the command.
        shell (bool): If True, runs the command through the shell.
        response (str): The response to be passed to the command's standard input.
        command_timeout (int): The maximum time in seconds to wait for the command to complete.
    """    
    def __init__(self, cmd, stdin=None, quiet=False, close_fds=False, encoding=_DefaultCommmandEncoding, shell=False,
                 response=None, command_timeout=30):
        """
        Initialize a Command object.

        Args:
            cmd (str or list): The command to execute. If it is a string, it will be split into a list of arguments.
            stdin (str or None): Input to be passed to the subprocess.
            quiet (bool): Flag indicating whether to suppress output from the subprocess.
            close_fds (bool): Flag indicating whether to close all file descriptors except stdin, stdout, and stderr.
            encoding (str): The character encoding to be used for the subprocess.
            shell (bool): Flag indicating whether the command should be executed through the shell.
            response (str or None): Output of the subprocess command.
            command_timeout (int): Timeout value in seconds for the command execution.

        Raises:
            None

        Returns:
            None
        """        
        self.shell = shell
        self.stdin = stdin
        self.encoding = encoding
        try:
            if isinstance(cmd, basestring):
                cmd = shlex.split(cmd)
        except NameError:
            # basestring doesn't exist in Python 3
            if isinstance(cmd, str):
                cmd = shlex.split(cmd)
        self.cmd = cmd
        self.process = None
        self.error = None
        self.response = response
        self.command_timeout = command_timeout

    def run(self):
        """
        Run a command and return the output, error, and timeout status.

        Returns:
            Tuple[str, str, bool]: A tuple containing the command output as a string, the error message as a string, and a boolean indicating if the command timed out.

        Raises:
            None.
        """        
        timedout = False

        def target():
            """
            Executes a command with optional input and captures the output and error streams.

            Raises an error if the Python version is less than 3 or the input stream is not a string.

            Args:
                None

            Returns:
                None

            Raises:
                TypeError: If the Python version is less than 3 or the input stream is not a string.
            """            
            if sys.version_info[0] >= 3 and isinstance(self.stdin, str):
                self.stdin = self.stdin.encode(self.encoding)
            if self.response:
                self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=subproc.PIPE,
                                             shell=self.shell)
                self.process.stdin.write(self.response.encode(self.encoding))
            else:
                self.process = subproc.Popen(self.cmd, stdout=subproc.PIPE, stderr=subproc.PIPE, stdin=self.stdin,
                                             shell=self.shell)
            self.output, self.error = self.process.communicate(self.stdin)

        thread = threading.Thread(target=target)
        thread.start()
        thread.join(self.command_timeout)
        if thread.is_alive():
            self.process.terminate()
            thread.join()
        if self.process.returncode != 0:
            if len(self.error.decode()) <= 0:
                timedout = True

        return self.output.decode('utf-8'), self.error.decode('utf-8'), timedout

def psqlQuery(query, return_all=False):
    """
    Run a PostgreSQL query and return the output.

    Args:
        query (str): The SQL query to be executed.
        return_all (bool, optional): If True, return all output. If False, return only the third line of the output. 
                                     Defaults to False.

    Returns:
        str: The output of the query.

    Raises:
        Exception: If there is an error executing the query or if the vPostgres service is not available.
    """    
    logger.debug("running SQL query: %s" % query)
    psqlpath = "/opt/vmware/vpostgres/current/bin/psql"
    cmd = [psqlpath, '-d', 'VCDB', 'postgres', '-At', '-c', query]
    try:
        output, errors, timeout = Command(cmd).run()
        if return_all:
            return output
        else:
            output = output.split('\n')[2]
            return output.strip()
    except Exception:
        msg = "Requires vPostgres service!"
        return msg
