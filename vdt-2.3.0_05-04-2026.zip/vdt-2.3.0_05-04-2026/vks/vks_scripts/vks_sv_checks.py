import datetime
import logging
import asyncio
import os
import configparser
from lib.vdt_base import set_force_flag
from vks.vks_lib.vks_supervisor_manager import supervisor_manager
from vks.vks_lib.vks_sv_utils import run_ssh_command, check_crictl_container_running, check_port_connectivity
from vks.vks_lib.common import psqlQuery

logger = logging.getLogger(__name__)

# Load configuration
_cfgfile = os.path.join(os.path.dirname(os.path.dirname(__file__)), "vks_cfg", "vks_vdt.ini")
_config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
_config.read(_cfgfile)

# Thresholds from config (with defaults)
DISK_SPACE_WARNING = int(_config.get('thresholds', 'disk_space_warning', fallback='80'))
DISK_SPACE_CRITICAL = int(_config.get('thresholds', 'disk_space_critical', fallback='90'))
CERT_EXPIRY_WARNING = int(_config.get('thresholds', 'cert_expiry_warning', fallback='30'))
CERT_EXPIRY_CRITICAL = int(_config.get('thresholds', 'cert_expiry_critical', fallback='7'))

def supervisor_disk_space_check():
    """
    Check if the supervisor has enough disk space available.

    Args:
        None

    Returns:
        dict: A dictionary containing the title, result, and details of the disk space check.

    Notes:
    """
    logger.debug(f"INFO: Starting supervisor disk space check")
    vm_space = []
    supervisor_vms = supervisor_manager.get_supervisors()
    
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for disk space check")
        return {"title": "Supervisor Disk Space Check", "result": "FAIL", "details": "No supervisor VMs found"}
    
    logger.debug(f"Found {len(supervisor_vms)} supervisor VMs to check")
    
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking disk space for VM {vm.get('vm_name')} ({vm_ip})")
            space_pct = run_ssh_command(vm_ip, "root", "df -h / | tail -1 | awk '{print $5}' | sed 's/%//g'")
            vm_space.append({"vm_name": vm.get("vm_name"), "vm_ip": vm_ip, "space_pct": space_pct})
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping disk space check")
    
    title = "Supervisor Disk Space Check"
    result = "PASS"
    details = ""
    for vm in vm_space:
        try:
            space_usage = int(vm['space_pct'])
            if space_usage > DISK_SPACE_CRITICAL:
                result = "FAIL"
                details += f"VM {vm['vm_name']} ({vm['vm_ip']}) has {vm['space_pct']}% disk space used.\n"
                logger.debug(f"ERROR: Critical disk space usage on {vm['vm_name']}: {space_usage}%")
            elif space_usage > DISK_SPACE_WARNING:
                result = "WARNING"
                details += f"VM {vm['vm_name']} ({vm['vm_ip']}) has {vm['space_pct']}% disk space used.\n"
                logger.debug(f"WARNING: High disk space usage on {vm['vm_name']}: {space_usage}%")
            else:
                logger.debug(f"Disk space usage on {vm['vm_name']}: {space_usage}% (OK)")
        except (ValueError, TypeError) as e:
            logger.debug(f"ERROR: Failed to parse disk space percentage for {vm['vm_name']}: {e}")
            result = "FAIL"
            details += f"Failed to check disk space for VM {vm['vm_name']} ({vm['vm_ip']})\n"
    
    if result != "PASS":
        details += "Refer to KB https://knowledge.broadcom.com/external/article/383369"
    
    logger.debug(f"INFO: Supervisor disk space check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }

def supervisor_port_22_check():
    """
    Check if port 22 is open on each supervisor VM.

    Returns:
        dict: A dictionary containing the title, result, and details of the port check.
    """
    logger.debug(f"INFO: Starting supervisor port 22 check")
    supervisor_vms = supervisor_manager.get_supervisors()
    
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for port 22 check")
        return {"title": "Supervisor Port 22 Check", "result": "FAIL", "details": "No supervisor VMs found"}
    
    title = "Supervisor Port 22 Check"
    result = "PASS"
    details = ""
    
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking port 22 on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                response = check_port_connectivity(vm_ip, 22)
                if response:
                    logger.debug(f"Port 22 is open on {vm['vm_name']}")
                else:
                    result = "FAIL"
                    details += f"Port 22 is not open on VM {vm['vm_name']} ({vm_ip}).\n"
                    logger.debug(f"ERROR: Port 22 check failed on {vm['vm_name']}: {response}")
            except Exception as e:
                result = "FAIL"
                details += f"Failed to check port 22 on VM {vm['vm_name']} ({vm_ip}): {e}\n"
                details += "Refer to https://ports.broadcom.com/ for required ports.\n"
                logger.debug(f"ERROR: Failed to check port 22 on {vm['vm_name']}: {e}")
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping port check")
    
    logger.debug(f"INFO: Port 22 check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }

def supervisor_port_5000_check():
    """
    Check if port 5000 is open on each supervisor VM.

    Returns:
        dict: A dictionary containing the title, result, and details of the port check.
    """
    logger.debug(f"INFO: Starting supervisor port 5000 check")
    supervisor_vms = supervisor_manager.get_supervisors()
    
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for port 5000 check")
        return {"title": "Supervisor Port 5000 Check", "result": "FAIL", "details": "No supervisor VMs found"}
    
    title = "Supervisor Port 5000 Check"
    result = "PASS"
    details = ""
    
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking port 5000 on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                response = check_port_connectivity(vm_ip, 5000)
                if response:
                    logger.debug(f"Port 5000 is open on {vm['vm_name']}")
                else:
                    result = "FAIL"
                    details += f"Port 5000 is not open on VM {vm['vm_name']} ({vm_ip}).\n"
                    logger.debug(f"ERROR: Port 5000 check failed on {vm['vm_name']}: {response}")
            except Exception as e:
                result = "FAIL"
                details += f"Failed to check port 5000 on VM {vm['vm_name']} ({vm_ip}): {e}\n"
                details += "Refer to https://ports.broadcom.com/ for required ports.\n"
                logger.debug(f"ERROR: Failed to check port 5000 on {vm['vm_name']}: {e}")
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping port check")
    
    logger.debug(f"INFO: Port 5000 check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }

def supervisor_port_6443_check():
    """
    Check if port 6443 is open on each supervisor VM.

    Returns:
        dict: A dictionary containing the title, result, and details of the port check.
    """
    logger.debug(f"INFO: Starting supervisor port 6443 check")
    supervisor_vms = supervisor_manager.get_supervisors()
    
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for port 6443 check")
        return {"title": "Supervisor Port 6443 Check", "result": "FAIL", "details": "No supervisor VMs found"}
    
    title = "Supervisor Port 6443 Check"
    result = "PASS"
    details = ""
    
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking port 6443 on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                response = check_port_connectivity(vm_ip, 6443)
                if response:
                    logger.debug(f"Port 6443 is open on {vm['vm_name']}")
                else:
                    result = "FAIL"
                    details += f"Port 6443 is not open on VM {vm['vm_name']} ({vm_ip}).\n"
                    logger.debug(f"ERROR: Port 6443 check failed on {vm['vm_name']}: {response}")
            except Exception as e:
                result = "FAIL"
                details += f"Failed to check port 6443 on VM {vm['vm_name']} ({vm_ip}): {e}\n"
                details += "Refer to https://ports.broadcom.com/ for required ports.\n"
                logger.debug(f"ERROR: Failed to check port 6443 on {vm['vm_name']}: {e}")
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping port check")
    
    logger.debug(f"INFO: Port 6443 check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }


def supervisor_esxi_host_port_10250_check():
    """
    Check connectivity from each supervisor VM to ESXi hosts in the cluster on port 10250 (kubelet).
    Uses cluster ID from cluster_db_config (e.g. domain-c8 -> id 8) to get host list from VCDB
    vpx_entity, then runs a port check from the supervisor VM to each host.
    """
    logger.debug("INFO: Starting supervisor ESXi host port 10250 check")
    title = "Supervisor to ESXi Host Port 10250 Check"
    result = "PASS"
    details = ""

    cluster_id = supervisor_manager.get_cluster_id()
    if not cluster_id:
        logger.debug("ERROR: Could not determine cluster ID for ESXi host port check")
        return {"title": title, "result": "FAIL", "details": "Could not determine cluster ID (supervisor not initialized or cluster_db_config missing)."}

    cluster_id_str = str(cluster_id).strip()
    if "domain-c" in cluster_id_str:
        vcdb_cluster_id = cluster_id_str.split("domain-c", 1)[1].split(":")[0].strip()
    else:
        vcdb_cluster_id = cluster_id_str
    if not vcdb_cluster_id or not vcdb_cluster_id.isdigit():
        return {"title": title, "result": "FAIL", "details": "Could not parse numeric cluster ID from '%s' (expected domain-cN or domain-cN:uuid)." % cluster_id_str}

    query = (
        "SELECT h.name AS host_name FROM vpx_entity h "
        "JOIN vpx_entity c ON h.parent_id = c.id "
        "WHERE c.id = %s AND h.type_id = 1;"
    ) % (vcdb_cluster_id,)
    try:
        raw = psqlQuery(query, return_all=True)
    except Exception as e:
        logger.debug("ERROR: Failed to query VCDB for ESXi hosts: %s", e)
        return {"title": title, "result": "FAIL", "details": "Failed to query VCDB for cluster hosts: %s" % e}

    if not raw or "Requires vPostgres" in (raw or ""):
        return {"title": title, "result": "FAIL", "details": "Could not get ESXi host list from VCDB (vPostgres required)."}

    host_names = [line.strip() for line in (raw or "").strip().splitlines() if line.strip()]
    if not host_names:
        logger.debug("INFO: No ESXi hosts found for cluster id %s", vcdb_cluster_id)
        return {"title": title, "result": "PASS", "details": "No ESXi hosts in cluster (domain-c%s); nothing to check." % vcdb_cluster_id}

    supervisor_vms = supervisor_manager.get_supervisors()
    if not supervisor_vms:
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found."}

    failures = []
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        vm_name = vm.get("vm_name", "unknown")
        if not vm_ip:
            continue
        for host in host_names:
            # From supervisor VM: test telnet to host:10250 (curl connects then we treat as OK)
            cmd = (
                "timeout 3 bash -c 'echo q | curl -s -o /dev/null telnet://%s:10250 2>/dev/null' && echo OK || echo FAIL"
            ) % host
            try:
                out = run_ssh_command(vm_ip, "root", cmd)
                out = (out or "").strip()
                if out == "FAIL" or (out != "OK" and out != ""):
                    failures.append("%s -> %s:10250 (from %s)" % (vm_name, host, vm_ip))
                    logger.debug("ERROR: Port 10250 check failed from %s to %s", vm_name, host)
            except Exception as e:
                failures.append("%s -> %s:10250 (from %s): %s" % (vm_name, host, vm_ip, e))
                logger.debug("ERROR: Failed to check 10250 from %s to %s: %s", vm_name, host, e)

    if failures:
        result = "FAIL"
        details = "Supervisor VM(s) could not reach ESXi host port 10250:\n" + "\n".join(failures[:20])
        if len(failures) > 20:
            details += "\n(and %d more)" % (len(failures) - 20)
        details += "\nRefer to https://ports.broadcom.com/ for required ports."
    else:
        details = "All supervisor VMs can reach ESXi hosts on port 10250 (cluster domain-c%s, %d host(s))." % (vcdb_cluster_id, len(host_names))

    logger.debug("INFO: Supervisor ESXi host port 10250 check completed: %s", result)
    return {"title": title, "result": result, "details": details}


def supervisor_certificate_check():
    logger.debug(f"INFO: Starting supervisor certificate check")
    supervisor_vms = supervisor_manager.get_supervisors()
    
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for certificate check")
        return {"title": "Supervisor Certificate Check", "result": "FAIL", "details": "No supervisor VMs found"}
    
    

    title = "Supervisor Certificate Check"
    result = "PASS"
    details = ""
    cert_statuses = []

    set_force_flag(enabled=True)
    
    certificate_paths = [
        "/etc/vmware/wcp/tls/vip.crt",
        "/etc/vmware/wcp/tls/mgmt.crt",
        "/etc/vmware/wcp/tls/ncp/lb-default.cert",
        "/etc/vmware/wcp/tls/wcpusr.cert",
        "/etc/vmware/wcp/tls/schedext.cert",
        "/etc/vmware/wcp/tls/authproxy.crt",
        "/etc/vmware/wcp/tls/docker-reg.crt",
        "/etc/vmware/wcp/tls/wcpagent.cert",
        "/etc/vmware/wcp/tls/mgmt-image-proxy.crt",
        "/etc/vmware/wcp/tls/apiserver-webhook-client.crt",
        "/var/lib/kubelet/pki/kubelet.crt",
        "/etc/kubernetes/pki/scheduler.crt",
        "/etc/kubernetes/pki/apiserver.crt",
        "/etc/kubernetes/pki/apiserver-etcd-client.crt",
        "/etc/kubernetes/pki/apiserver-kubelet-client.crt",
        "/etc/kubernetes/pki/front-proxy-client.crt",
        "/etc/kubernetes/pki/etcd/server.crt",
        "/etc/kubernetes/pki/etcd/peer.crt",
        "/etc/kubernetes/pki/etcd/healthcheck-client.crt",
        "/etc/kubernetes/pki/bootstrapper.crt",
        "/etc/kubernetes/pki/front-proxy-ca.crt",
        "/etc/kubernetes/pki/etcd/ca.crt",
        "/etc/kubernetes/pki/ca.crt"
    ]
    

    async def check_certificates_async(vm, certificate_paths):
        vm_ip = vm.get("vm_ip")
        results = []
        local_result = "PASS"  # Track result locally to avoid race conditions
        if not vm_ip:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping certificate check")
            return local_result, results
        logger.debug(f"Checking certificates on VM {vm.get('vm_name')} ({vm_ip})")
        loop = asyncio.get_event_loop()
        for cert_path in certificate_paths:
            try:
                logger.debug(f"Checking certificate: {cert_path}")
                
                # First check if the certificate file exists
                exists_command = f"test -f {cert_path} && echo 'exists' || echo 'not_found'"
                exists_result = await loop.run_in_executor(
                    None, run_ssh_command, vm_ip, "root", exists_command
                )
                
                if exists_result is None or exists_result.strip() != 'exists':
                    logger.debug(f"Certificate {cert_path} not found on {vm.get('vm_name')}, skipping")
                    continue
                
                # Use the same method as your shell command
                expiry_command = f"date --date=\"$(openssl x509 -in {cert_path} -noout -enddate | awk -F '=' '{{print $NF}}')\" --iso-8601"
                expiry_date_str = await loop.run_in_executor(
                    None, run_ssh_command, vm_ip, "root", expiry_command
                )
                
                if expiry_date_str is None:
                    logger.debug(f"ERROR: Failed to get expiry date for {cert_path} on {vm.get('vm_name')}")
                    results.append(f"Failed to get expiry date for {cert_path} on {vm.get('vm_name')}\n")
                    local_result = "FAIL"
                    continue
                
                if expiry_date_str.strip():
                    try:
                        # Parse the ISO date format (YYYY-MM-DD)
                        expiration_date = datetime.datetime.strptime(expiry_date_str.strip(), "%Y-%m-%d")
                        days_remaining = (expiration_date - datetime.datetime.now()).days

                        if days_remaining < CERT_EXPIRY_CRITICAL:
                            local_result = "FAIL"
                            results.append(f"{cert_path} on {vm.get('vm_name')} expires in {days_remaining} days ({expiry_date_str.strip()}).\n")
                            logger.debug(f"ERROR: Certificate {cert_path} on {vm.get('vm_name')} expires in {days_remaining} days ({expiry_date_str.strip()})")
                        elif days_remaining < CERT_EXPIRY_WARNING:
                            if local_result != "FAIL":
                                local_result = "WARN"
                            results.append(f"{cert_path} on {vm.get('vm_name')} expires in {days_remaining} days ({expiry_date_str.strip()}).\n")
                            logger.debug(f"WARNING: Certificate {cert_path} on {vm.get('vm_name')} expires in {days_remaining} days")
                        else:
                            logger.debug(f"Certificate {cert_path} on {vm.get('vm_name')} expires in {days_remaining} days (OK)")
                    except ValueError as e:
                        logger.debug(f"ERROR: Failed to parse expiry date {expiry_date_str} for {cert_path} on {vm.get('vm_name')}: {e}")
                        results.append(f"Failed to parse expiry date for {cert_path} on {vm.get('vm_name')}\n")
                else:
                    logger.debug(f"ERROR: Empty expiry date returned for {cert_path} on {vm.get('vm_name')}")
                    results.append(f"Could not determine expiry date for {cert_path} on {vm.get('vm_name')}\n")
                
            except Exception as e:
                logger.debug(f"ERROR: Failed to check certificate {cert_path} on {vm.get('vm_name')}: {e}")
                results.append(f"Failed to check certificate {cert_path} on {vm.get('vm_name')}: {e}\n")
        return local_result, results

    async def run_certificate_checks():
        tasks = [check_certificates_async(vm, certificate_paths) for vm in supervisor_vms]
        all_results = await asyncio.gather(*tasks)
        return all_results

    check_results = asyncio.run(run_certificate_checks())

    set_force_flag(enabled=False)

    # Aggregate results from all VMs - avoid race conditions by collecting after gather
    for local_result, messages in check_results:
        if local_result == "FAIL":
            result = "FAIL"
        elif local_result == "WARN" and result != "FAIL":
            result = "WARN"
        cert_statuses.extend(messages)

    logger.debug(f"INFO: Certificate check completed. Checked {len(certificate_paths)} certificates with result: {result}")
    details += "\n".join(cert_statuses)
    if result != "PASS":
        details += "\nRefer to KB https://knowledge.broadcom.com/external/article/322994"

    return {
        "title": title,
        "result": result,
        "details": details
    }

def supervisor_kubelet_status_check():
    """
    Check if the kubelet service is running on each supervisor VM.

    Returns:
        dict: A dictionary containing the title, result, and details of the kubelet status check.
    """
    logger.debug(f"INFO: Starting supervisor kubelet status check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor kubelet Status Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for kubelet status check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    logger.debug(f"Checking kubelet status on {len(supervisor_vms)} supervisor VMs")
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking kubelet status on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                kubelet_status = run_ssh_command(vm_ip, "root", "systemctl is-active kubelet")
                if kubelet_status != "active":
                    result = "FAIL"
                    details += f"VM {vm['vm_name']} ({vm['vm_dns']}) kubelet service is not running.\n"
                    logger.debug(f"ERROR: Kubelet service not active on {vm['vm_name']}: status={kubelet_status}")
                else:
                    logger.debug(f"Kubelet service active on {vm['vm_name']}")
            except Exception as e:
                logger.debug(f"ERROR: Failed to check kubelet status on {vm['vm_name']}: {e}")
                result = "FAIL"
                details += f"Failed to check kubelet status on VM {vm['vm_name']} ({vm_ip})\n"
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping kubelet check")

    logger.debug(f"INFO: Kubelet status check completed with result: {result}")
    return {"title": title, "result": result, "details": details}

def supervisor_containerd_status_check():
    """
    Check if the containerd service is running on each supervisor VM.

    Returns:
        dict: A dictionary containing the title, result, and details of the containerd status check.
    """
    logger.debug(f"INFO: Starting supervisor containerd status check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor containerd Status Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for containerd status check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    logger.debug(f"Checking containerd status on {len(supervisor_vms)} supervisor VMs")
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking containerd status on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                containerd_status = run_ssh_command(vm_ip, "root", "systemctl is-active containerd")
                if containerd_status != "active":
                    result = "FAIL"
                    details += f"VM {vm['vm_name']} ({vm['vm_dns']}) containerd service is not running.\n"
                    logger.debug(f"ERROR: Containerd service not active on {vm['vm_name']}: status={containerd_status}")
                else:
                    logger.debug(f"Containerd service active on {vm['vm_name']}")
            except Exception as e:
                logger.debug(f"ERROR: Failed to check containerd status on {vm['vm_name']}: {e}")
                result = "FAIL"
                details += f"Failed to check containerd status on VM {vm['vm_name']} ({vm_ip})\n"
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping containerd check")

    logger.debug(f"INFO: Containerd status check completed with result: {result}")
    return {"title": title, "result": result, "details": details}

def supervisor_wcpsync_status_check():
    """
    Check if the wcp-sync service is running on each supervisor VM.

    Returns:
        dict: A dictionary containing the title, result, and details of the wcp-sync status check.
    """
    logger.debug(f"INFO: Starting supervisor wcp-sync status check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor wcp-sync Status Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for wcp-sync status check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    logger.debug(f"Checking wcp-sync status on {len(supervisor_vms)} supervisor VMs")
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking wcp-sync status on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                wcp_sync_status = run_ssh_command(vm_ip, "root", "systemctl is-active wcp-sync")
                if wcp_sync_status != "active":
                    result = "FAIL"
                    details += f"VM {vm['vm_name']} ({vm['vm_dns']}) wcp-sync service is not running.\n"
                    logger.debug(f"ERROR: WCP-sync service not active on {vm['vm_name']}: status={wcp_sync_status}")
                else:
                    logger.debug(f"WCP-sync service active on {vm['vm_name']}")
            except Exception as e:
                logger.debug(f"ERROR: Failed to check wcp-sync status on {vm['vm_name']}: {e}")
                result = "FAIL"
                details += f"Failed to check wcp-sync status on VM {vm['vm_name']} ({vm_ip})\n"
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping wcp-sync check")

    logger.debug(f"INFO: WCP-sync status check completed with result: {result}")
    return {"title": title, "result": result, "details": details}

def supervisor_core_container_running_check():
    """
    Check if the core containers are running on the supervisor VMs.

    Returns:
        dict: A dictionary containing the title, result, and details of the core container check.
    """
    logger.debug(f"INFO: Starting supervisor core container running check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor Core Container Running Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for core container check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    #TODO: split this into a required and optional list of containers
    core_containers = ["coredns", "docker-registry",
                       "etcd", "kube-apiserver",
                       "kube-controller-manager", "kube-scheduler"]
    
    logger.debug(f"Checking {len(core_containers)} core containers on {len(supervisor_vms)} supervisor VMs")
    
    async def check_core_containers_async(vm, core_containers):
        vm_ip = vm.get("vm_ip")
        if not vm_ip:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping container check")
            return []
        
        logger.debug(f"Checking core containers on VM {vm.get('vm_name')} ({vm_ip})")
        set_force_flag(enabled=True)
        results = []
        loop = asyncio.get_event_loop()
        
        try:
            for container in core_containers:
                # Run check_crictl_container_running in a thread to avoid blocking
                container_status = await loop.run_in_executor(
                    None, check_crictl_container_running, vm_ip, container
                )
                if not container_status:
                    results.append(f"{container} container is not running on Supervisor {vm['vm_name']} ({vm_ip}).\n")
                    logger.debug(f"ERROR: Container {container} not running on {vm['vm_name']}")
                else:
                    logger.debug(f"Container {container} running on {vm['vm_name']}")
        except Exception as e:
            logger.debug(f"ERROR: Failed to check containers on {vm['vm_name']}: {e}")
            results.append(f"Failed to check containers on {vm['vm_name']} ({vm_ip}): {e}\n")
        finally:
            set_force_flag(enabled=False)
        
        return results

    try:
        async def run_checks():
            tasks = [check_core_containers_async(vm, core_containers) for vm in supervisor_vms]
            all_results = await asyncio.gather(*tasks)
            return [item for sublist in all_results for item in sublist]

        details_list = asyncio.run(run_checks())
        if details_list:
            result = "FAIL"
            details += "".join(details_list)
    except Exception as e:
        logger.debug(f"ERROR: Failed to run async container checks: {e}")
        result = "FAIL"
        details = f"Failed to check core containers: {e}"
    
    logger.debug(f"INFO: Core container check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }

# cat /etc/vmware/wcp/.node_configure_status on each supervisor VM and make sure it's not "FAILED"
def supervisor_vm_node_configured_check():
    """
    Check if the supervisor VMs are properly configured.
    This involves checking the /etc/vmware/wcp/.node_configure_status file on each VM.
    """
    logger.debug(f"INFO: Starting supervisor VM node configured check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor VM Node Configured Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for node configured check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    logger.debug(f"Checking node configuration on {len(supervisor_vms)} supervisor VMs")
    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        if vm_ip:
            logger.debug(f"Checking node configuration on VM {vm.get('vm_name')} ({vm_ip})")
            try:
                config_status = run_ssh_command(vm_ip, "root", "cat /etc/vmware/wcp/.node_configuration_status")
                if config_status == "FAILED":
                    result = "FAIL"
                    details += f"VM {vm['vm_name']} ({vm['vm_dns']}) is not properly configured.\n"
                    logger.debug(f"ERROR: VM {vm['vm_name']} is not properly configured")
                else:
                    logger.debug(f"VM {vm['vm_name']} is properly configured")
            except Exception as e:
                logger.debug(f"ERROR: Failed to check node configuration on {vm['vm_name']}: {e}")
                result = "FAIL"
                details += f"Failed to check node configuration on VM {vm['vm_name']} ({vm_ip}): {e}\n"
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no IP address, skipping node configuration check")

    logger.debug(f"INFO: Node configuration check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }


def supervisor_wcp_schedext_whitelist_check():
    """
    Check that wcp-schedext-admission-controller-user-whitelist is not empty on each supervisor VM.
    Empty file causes namespaces to get stuck in configuring state after vCenter 8.0 Update 3b+ (KB 381404).
    """
    logger.debug("INFO: Starting supervisor WCP schedext whitelist check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor WCP Schedext User Whitelist Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug("ERROR: No supervisor VMs found for schedext whitelist check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    whitelist_path = "/etc/vmware/wcp/wcp-schedext-admission-controller-user-whitelist"
    expected_prefixes = ("kubernetes-admin", "kubeadm", "system:", "sso:wcp-", "vmware-system-")

    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        vm_name = vm.get("vm_name", "unknown")
        if not vm_ip:
            logger.debug(f"WARNING: VM {vm_name} has no IP address, skipping schedext whitelist check")
            continue
        try:
            content = run_ssh_command(vm_ip, "root", f"cat {whitelist_path} 2>/dev/null || echo ''")
            if content is None:
                content = ""
            content = (content or "").strip()
            if not content:
                result = "FAIL"
                details += f"VM {vm_name} ({vm_ip}): {whitelist_path} is empty or missing.\n"
                logger.debug(f"ERROR: {whitelist_path} empty or missing on {vm_name}")
                continue
            missing = [p for p in expected_prefixes if p not in content]
            if missing:
                if result != "FAIL":
                    result = "WARN"
                details += f"VM {vm_name} ({vm_ip}): whitelist may be incomplete (missing: {', '.join(missing)}).\n"
                logger.debug(f"WARNING: {vm_name} whitelist missing expected prefixes: {missing}")
        except Exception as e:
            result = "FAIL"
            details += f"Failed to check {whitelist_path} on VM {vm_name} ({vm_ip}): {e}\n"
            logger.debug(f"ERROR: Failed to check schedext whitelist on {vm_name}: {e}")

    if result != "PASS":
        details += "Refer to KB https://knowledge.broadcom.com/external/article/381404\n"

    logger.debug(f"INFO: Supervisor WCP schedext whitelist check completed with result: {result}")
    return {"title": title, "result": result, "details": details}


def supervisor_openssl_authoritykeyidentifier_check():
    """
    Check that /etc/vmware/wcp/openssl.conf on each supervisor CP VM has
    authorityKeyIdentifier = keyid,issuer (not just keyid). Missing ',issuer' causes
    Supervisor upgrade to fail (KB 379207).
    """
    logger.debug("INFO: Starting supervisor OpenSSL authorityKeyIdentifier check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor OpenSSL authorityKeyIdentifier Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        logger.debug("ERROR: No supervisor VMs found for openssl check")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    openssl_path = "/etc/vmware/wcp/openssl.conf"
    bad_vms = []

    for vm in supervisor_vms:
        vm_ip = vm.get("vm_ip")
        vm_name = vm.get("vm_name", "unknown")
        if not vm_ip:
            logger.debug(f"WARNING: VM {vm_name} has no IP, skipping openssl check")
            continue
        try:
            out = run_ssh_command(vm_ip, "root", f"grep -E 'authorityKeyIdentifier' {openssl_path} 2>/dev/null || echo ''")
            if out is None:
                continue
            for line in (out or "").strip().splitlines():
                line = line.strip()
                if "authorityKeyIdentifier" in line and "keyid" in line and ",issuer" not in line:
                    bad_vms.append(f"{vm_name} ({vm_ip}): authorityKeyIdentifier = keyid without ,issuer")
                    break
        except Exception as e:
            logger.debug(f"ERROR: Failed to check openssl on {vm_name}: {e}")
            details += f"Failed to check {openssl_path} on {vm_name}: {e}\n"

    if bad_vms:
        result = "FAIL"
        details = "OpenSSL authorityKeyIdentifier missing ',issuer' on:\n" + "\n".join(bad_vms)
        details += "\nRefer to KB https://knowledge.broadcom.com/external/article/379207"
    else:
        details = "authorityKeyIdentifier correctly set (keyid,issuer) on checked supervisor VMs."

    logger.debug(f"INFO: Supervisor OpenSSL authorityKeyIdentifier check completed: {result}")
    return {"title": title, "result": result, "details": details}


def supervisor_local_dns_check():
    """
    Check for .local DNS configuration on supervisor (KB 323444).
    .local requires master_DNS_search_domains / resolvectl; WARN if .local in use without workaround.
    """
    logger.debug("INFO: Starting supervisor .local DNS check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor .local DNS Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}
    vm_ip = supervisor_vms[0].get("vm_ip") if supervisor_vms else None
    if not vm_ip:
        return {"title": title, "result": "WARN", "details": "No supervisor IP for DNS check"}
    try:
        out = run_ssh_command(vm_ip, "root", "cat /etc/systemd/network/*.network 2>/dev/null | grep -i Domains || true")
        if out and ".local" in (out or ""):
            result = "WARN"
            details = ".local domain detected in supervisor network config. Ensure master_DNS_search_domains includes .local. Refer to KB https://knowledge.broadcom.com/external/article/323444"
        else:
            details = "No .local DNS issue detected."
        logger.debug("INFO: Supervisor .local DNS check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed .local DNS check: %s", e)
        return {"title": title, "result": "WARN", "details": f"Could not check: {e}. Refer to KB https://knowledge.broadcom.com/external/article/323444"}


def supervisor_management_dns_check():
    """
    Check that supervisor CP can reach management DNS (KB 392239).
    SSH to one CP and run nslookup; WARN if unreachable.
    """
    logger.debug("INFO: Starting supervisor management DNS check")
    supervisor_vms = supervisor_manager.get_supervisors()
    title = "Supervisor Management DNS Check"
    result = "PASS"
    details = ""

    if not supervisor_vms:
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}
    vm_ip = supervisor_vms[0].get("vm_ip") if supervisor_vms else None
    if not vm_ip:
        return {"title": title, "result": "WARN", "details": "No supervisor IP for DNS check"}
    try:
        out = run_ssh_command(vm_ip, "root", "resolvectl status 2>/dev/null | head -20 || true")
        if not out or "DNS Server" not in (out or ""):
            result = "WARN"
            details = "Could not verify DNS from supervisor CP. If PVC/Pods fail with dial tcp lookup timeout, refer to KB https://knowledge.broadcom.com/external/article/392239"
        else:
            details = "Supervisor CP DNS config present."
        logger.debug("INFO: Supervisor management DNS check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed management DNS check: %s", e)
        return {"title": title, "result": "WARN", "details": f"Could not check: {e}. Refer to KB https://knowledge.broadcom.com/external/article/392239"}


def supervisor_vsphere_pod_timeout_check():
    """
    Check for vSphere Pod ClusterIP/timeout symptoms (KB 312199).
    Supervisor pods ErrImagePull/CrashLoopBackOff with timeout messages.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor vSphere Pod Timeout Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    try:
        command = "kubectl get pods -A -o json 2>/dev/null"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "PASS", "details": "Could not get pods (skipped)"}
        import json
        data = json.loads(output)
        items = data.get("items") or []
        keywords = ("i/o timeout", "dial tcp", "clusterip", "timeout", "lookup")
        timeout_pods = []
        for pod in items:
            phase = pod.get("status", {}).get("phase", "")
            name = pod.get("metadata", {}).get("name", "")
            ns = pod.get("metadata", {}).get("namespace", "")
            for cs in pod.get("status", {}).get("containerStatuses") or []:
                state = cs.get("state", {}) or {}
                waiting = state.get("waiting", {}) or {}
                msg = (waiting.get("message") or waiting.get("reason") or "").lower()
                if any(k in msg for k in keywords) or phase in ("ErrImagePull", "CrashLoopBackOff"):
                    timeout_pods.append(f"{ns}/{name}: {phase or msg[:50]}")
                    break
        if timeout_pods:
            result = "WARN"
            details = "Pods with timeout/ClusterIP symptoms (VDS):\n" + "\n".join(timeout_pods[:5])
            if len(timeout_pods) > 5:
                details += f"\n(and {len(timeout_pods) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/312199"
        else:
            details = "No vSphere Pod timeout symptoms detected."
        logger.debug("INFO: Supervisor vSphere pod timeout check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed vSphere pod timeout check: %s", e)
        return {"title": title, "result": "WARN", "details": f"Could not check: {e}. Refer to KB https://knowledge.broadcom.com/external/article/312199"}


def main():
    # run all checks and print all results
    logger.debug(f"INFO: Running supervisor checks")
    checks = [
        supervisor_disk_space_check(),
        supervisor_certificate_check(),
        supervisor_kubelet_status_check(),
        supervisor_containerd_status_check(),
        supervisor_wcpsync_status_check(),
        supervisor_vm_node_configured_check(),
        supervisor_core_container_running_check()
    ]
    
    for check in checks:
        logger.debug(f"INFO: Check: {check['title']}, Result: {check['result']}")
        logger.debug(f"INFO: Details:\n{check['details']}")
    
    logger.debug(f"INFO: Supervisor checks completed")

if __name__ == "__main__":
    main()