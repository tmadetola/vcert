"""
TKC Checks - Main Entry Point

Aggregates all TKC cluster checks from:
- vks_tkc_system_checks: Port, etcd, certificate checks
- vks_tkc_resource_checks: Kubernetes resource checks
"""
import logging
from vks.vks_scripts.vks_tkc_system_checks import tkc_system_all_checks
from vks.vks_scripts.vks_tkc_resource_checks import tkc_resource_all_checks

# Re-export individual checks for backward compatibility
from vks.vks_scripts.vks_tkc_system_checks import (
    tkc_control_plane_port_6443_check,
    tkc_control_plane_port_10250_check,
    tkc_control_plane_port_2379_check,
    tkc_control_plane_port_2380_check,
    tkc_all_clusters_etcd_member_list_check,
    tkc_all_clusters_etcd_endpoint_health_check,
    tkc_all_clusters_etcd_endpoint_status_check,
    tkc_all_clusters_cert_check,
)
from vks.vks_scripts.vks_tkc_resource_checks import (
    tkc_all_clusters_status_check,
    tkc_all_clusters_nodes_check,
    tkc_all_clusters_pods_check,
    tkc_all_clusters_deployments_check,
    tkc_all_clusters_daemonsets_check,
    tkc_all_clusters_statefulsets_check,
    tkc_all_clusters_replicasets_check,
    tkc_all_clusters_services_check,
    tkc_all_clusters_pvc_check,
    tkc_all_clusters_pkgi_check,
    tkc_all_clusters_pdb_check,
    tkc_all_clusters_vmware_system_user_daemonset_check,
    tkc_all_clusters_antrea_health_check,
    tkc_all_clusters_pause_image_check,
    tkc_all_clusters_third_party_webhook_check,
    tkc_all_clusters_upgrade_stuck_check,
    tkc_all_clusters_volume_attachment_check,
    tkc_all_clusters_control_plane_roles_check,
    tkc_all_clusters_pv_released_check,
    tkc_all_clusters_volume_mount_swap_check,
    tkc_all_clusters_nfs_mount_check,
    tkc_all_clusters_pre_upgrade_133_cloud_provider_check,
    tkc_all_clusters_pre_upgrade_133_legacy_managed_fields_check,
)

logger = logging.getLogger(__name__)


def tkc_all_checks():
    """Run all TKC cluster checks and return a list of result dicts."""
    results = []
    try:
        # Resource checks (K8s objects)
        results.extend(tkc_resource_all_checks())
        # System checks (ports, etcd, certs)
        results.extend(tkc_system_all_checks())
    except Exception as e:
        logger.debug(f"ERROR: Failed to run TKC checks: {e}")
        results.append({
            "title": "TKC Clusters Check",
            "result": "FAIL",
            "details": f"Failed to run TKC checks: {e}"
        })
    return results


def main():
    """Run all TKC checks and print results."""
    results = tkc_all_checks()
    for result in results:
        print(f"{result['title']}: {result['result']}")
        print(f"  Details: {result['details']}")
        print()


if __name__ == "__main__":
    main()
