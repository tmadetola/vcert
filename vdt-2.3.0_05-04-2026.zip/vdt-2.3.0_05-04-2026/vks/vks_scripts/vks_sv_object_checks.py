import json
import logging
from vks.vks_lib.vks_supervisor_manager import supervisor_manager
from vks.vks_lib.vks_sv_utils import run_ssh_command

logger = logging.getLogger(__name__)

def supervisor_clusters_check():
    """
    Check if all clusters are provisioned and ready.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Clusters Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get cluster -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        clusters_data = json.loads(output)
        
        if not clusters_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No clusters found"}
        
        failed_clusters = []
        provisioning_clusters = []
        
        for cluster in clusters_data["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            status = cluster.get("status", {})
            phase = status.get("phase", "unknown")
            
            # Check initialization status (new Cluster API format)
            initialization = status.get("initialization", {})
            control_plane_ready = initialization.get("controlPlaneInitialized", None)
            infrastructure_ready = initialization.get("infrastructureProvisioned", None)
            
            # Fallback to legacy fields if initialization block doesn't exist
            if control_plane_ready is None:
                control_plane_ready = status.get("controlPlaneReady", False)
            if infrastructure_ready is None:
                infrastructure_ready = status.get("infrastructureReady", False)
            
            # Check conditions for Available/Ready status
            conditions = status.get("conditions", [])
            available_condition = None
            ready_condition = None
            is_ready = False
            is_available = False
            for condition in conditions:
                # Check for Available condition (new format) or Ready condition (legacy)
                cond_type = condition.get("type")
                if cond_type == "Available":
                    available_condition = condition
                    if condition.get("status") == "True":
                        is_available = True
                if cond_type == "Ready":
                    ready_condition = condition
                    if condition.get("status") == "True":
                        is_ready = True
            
            # Also check deprecated v1beta1 conditions for backwards compatibility
            if not is_ready:
                deprecated_conditions = status.get("deprecated", {}).get("v1beta1", {}).get("conditions", [])
                for condition in deprecated_conditions:
                    if condition.get("type") == "Ready" and condition.get("status") == "True":
                        is_ready = True
                        break
            
            if phase == "Provisioning":
                provisioning_clusters.append(f"{namespace}/{name}")
            elif phase == "Provisioned" and (is_available or is_ready) and control_plane_ready and infrastructure_ready:
                # Cluster is healthy - phase is Provisioned and it's available/ready
                continue
            elif phase != "Provisioned" or not control_plane_ready or not infrastructure_ready or (not is_available and not is_ready):
                # Get failure reason if available
                failure_reason = status.get("failureReason", "")
                failure_message = status.get("failureMessage", "")
                status_details = f"phase={phase}, controlPlane={control_plane_ready}, infrastructure={infrastructure_ready}"
                if failure_reason:
                    status_details += f", reason={failure_reason}"
                if failure_message:
                    status_details += f", message={failure_message[:50]}..."
                failed_clusters.append(f"{namespace}/{name}: {status_details}")
            elif not is_available and not is_ready:
                # Phase is Provisioned but neither Available nor Ready
                status_details = f"phase={phase}, available={is_available}, ready={is_ready}"
                failed_clusters.append(f"{namespace}/{name}: {status_details}")
        
        if failed_clusters:
            result = "FAIL"
            details = f"Clusters not ready:\n" + "\n".join(failed_clusters[:3])  # Limit to first 3
            if len(failed_clusters) > 3:
                details += f"\n(and {len(failed_clusters) - 3} more)"
        elif provisioning_clusters:
            result = "WARN"
            details = f"Clusters provisioning:\n" + "\n".join(provisioning_clusters)
        else:
            details = f"All {len(clusters_data['items'])} clusters are provisioned and ready"
            
        logger.debug(f"INFO: Cluster check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check clusters: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check clusters: {e}"}

def supervisor_machines_check():
    """
    Check if all machines are in running state.
    Returns a result dict.
    
    A machine is considered healthy if:
    - Phase is "Running" AND (Ready=True OR Available=True)
    - OR Phase is "Provisioned" with infrastructure ready (still bootstrapping)
    
    A machine is considered unhealthy if:
    - Phase is not Running/Provisioned/Provisioning
    - OR Phase is Running but neither Ready nor Available
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Machines Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get machine -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        machines_data = json.loads(output)
        
        if not machines_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No machines found"}
        
        failed_machines = []
        provisioning_machines = []
        
        for machine in machines_data["items"]:
            name = machine.get("metadata", {}).get("name", "unknown")
            namespace = machine.get("metadata", {}).get("namespace", "unknown")
            status = machine.get("status", {})
            phase = status.get("phase", "unknown")
            
            # Check conditions for ready status (Cluster API v1beta2 format)
            conditions = status.get("conditions", [])
            is_ready = False
            is_available = False
            bootstrap_config_ready = False
            infra_ready = False
            
            for condition in conditions:
                cond_type = condition.get("type")
                cond_status = condition.get("status") == "True"
                if cond_type == "Ready":
                    is_ready = cond_status
                elif cond_type == "Available":
                    is_available = cond_status
                elif cond_type == "BootstrapConfigReady":
                    bootstrap_config_ready = cond_status
                elif cond_type == "InfrastructureReady":
                    infra_ready = cond_status
            
            # Also check deprecated v1beta1 conditions as fallback
            deprecated_conditions = status.get("deprecated", {}).get("v1beta1", {}).get("conditions", [])
            for condition in deprecated_conditions:
                cond_type = condition.get("type")
                cond_status = condition.get("status") == "True"
                if cond_type == "Ready" and not is_ready:
                    is_ready = cond_status
                elif cond_type == "BootstrapReady" and not bootstrap_config_ready:
                    bootstrap_config_ready = cond_status
                elif cond_type == "InfrastructureReady" and not infra_ready:
                    infra_ready = cond_status
            
            # Determine machine health based on phase and conditions
            if phase == "Provisioning":
                provisioning_machines.append(f"{namespace}/{name}")
            elif phase == "Running" and (is_ready or is_available):
                # Machine is healthy - phase is Running and it's ready/available
                continue
            elif phase == "Provisioned" and infra_ready:
                # Machine is provisioned but may still be bootstrapping - this is a transient state
                # Check if it has a health check failure
                health_check_failed = False
                for condition in conditions:
                    if condition.get("type") == "HealthCheckSucceeded" and condition.get("status") == "False":
                        health_check_failed = True
                        break
                
                if health_check_failed:
                    # Get failure details
                    failure_message = ""
                    for condition in conditions:
                        if condition.get("type") == "HealthCheckSucceeded":
                            failure_message = condition.get("message", "")[:50]
                            break
                    status_details = f"phase={phase}, healthCheck=Failed"
                    if failure_message:
                        status_details += f", message={failure_message}..."
                    failed_machines.append(f"{namespace}/{name}: {status_details}")
                else:
                    # Still bootstrapping, treat as warning
                    provisioning_machines.append(f"{namespace}/{name}")
            elif phase == "Running" and not is_ready and not is_available:
                # Phase is Running but neither Ready nor Available - this is unexpected
                status_details = f"phase={phase}, ready={is_ready}, available={is_available}"
                failed_machines.append(f"{namespace}/{name}: {status_details}")
            else:
                # Other failure cases
                failure_reason = status.get("failureReason", "")
                failure_message = status.get("failureMessage", "")
                status_details = f"phase={phase}, ready={is_ready}, available={is_available}"
                if failure_reason:
                    status_details += f", reason={failure_reason}"
                if failure_message:
                    status_details += f", message={failure_message[:50]}..."
                failed_machines.append(f"{namespace}/{name}: {status_details}")
        
        if failed_machines:
            result = "FAIL"
            details = f"Machines not running:\n" + "\n".join(failed_machines[:3])
            if len(failed_machines) > 3:
                details += f"\n(and {len(failed_machines) - 3} more)"
        elif provisioning_machines:
            result = "WARN"
            details = f"Machines provisioning:\n" + "\n".join(provisioning_machines)
        else:
            details = f"All {len(machines_data['items'])} machines are running"
            
        logger.debug(f"INFO: Machine check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check machines: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check machines: {e}"}

def supervisor_nodes_check():
    """
    Check if all nodes are ready and healthy.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Nodes Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get nodes -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        nodes_data = json.loads(output)
        
        if not nodes_data.get("items"):
            return {"title": title, "result": "FAIL", "details": "No nodes found"}
        
        not_ready_nodes = []
        warning_nodes = []
        
        for node in nodes_data["items"]:
            name = node.get("metadata", {}).get("name", "unknown")
            conditions = node.get("status", {}).get("conditions", [])
            
            # Check node conditions
            is_ready = False
            has_pressure = False
            pressure_types = []
            
            for condition in conditions:
                condition_type = condition.get("type", "")
                condition_status = condition.get("status", "")
                
                if condition_type == "Ready" and condition_status == "True":
                    is_ready = True
                elif condition_type in ["MemoryPressure", "DiskPressure", "PIDPressure", "NetworkUnavailable"] and condition_status == "True":
                    has_pressure = True
                    pressure_types.append(condition_type)
            
            if not is_ready:
                # Get the Ready condition reason if available
                ready_reason = ""
                for condition in conditions:
                    if condition.get("type") == "Ready":
                        ready_reason = condition.get("reason", "")
                        break
                not_ready_nodes.append(f"{name}: {ready_reason}" if ready_reason else name)
            elif has_pressure:
                warning_nodes.append(f"{name}: {', '.join(pressure_types)}")
        
        if not_ready_nodes:
            result = "FAIL"
            details = f"Nodes not ready:\n" + "\n".join(not_ready_nodes)
        elif warning_nodes:
            result = "WARN"
            details = f"Nodes with pressure:\n" + "\n".join(warning_nodes)
        else:
            details = f"All {len(nodes_data['items'])} nodes are ready"
            
        logger.debug(f"INFO: Node check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check nodes: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check nodes: {e}"}


def supervisor_control_plane_roles_check():
    """
    Check that Supervisor control plane nodes have expected ROLES (control-plane, master) (KB 386786).
    Missing roles cause system pods to stay Pending.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Control Plane Roles Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get nodes -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get nodes"}
        nodes_data = json.loads(output)
        items = nodes_data.get("items") or []
        missing_roles = []
        for node in items:
            name = node.get("metadata", {}).get("name", "unknown")
            labels = node.get("metadata", {}).get("labels") or {}
            # ESXi hosts have role agent; skip them
            if labels.get("node-role.kubernetes.io/agent") is not None:
                continue
            # Control plane VMs should have control-plane and master
            has_cp = "node-role.kubernetes.io/control-plane" in labels
            has_master = "node-role.kubernetes.io/master" in labels
            if not has_cp or not has_master:
                missing_roles.append(name)
        if missing_roles:
            result = "WARN"
            details = "Supervisor control plane node(s) missing control-plane and/or master role: " + ", ".join(missing_roles)
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/386786"
        else:
            details = "All supervisor control plane nodes have expected roles."
        logger.debug("INFO: Supervisor control plane roles check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check supervisor control plane roles: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed to check roles: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/386786"}


def supervisor_cluster_creation_check():
    """
    Check for clusters stuck in Pending due to osConfiguration secret (KB 398390).
    Conditions containing 'secret not found', 'failed to generate patches', 'TopologyReconciled' error.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Cluster Creation Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get cluster -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get clusters"}
        data = json.loads(output)
        items = data.get("items") or []
        keywords = ("secret not found", "failed to generate patches", "topologyreconciled")
        failed = []
        for cluster in items:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            phase = cluster.get("status", {}).get("phase", "")
            if phase != "Pending":
                continue
            conditions = cluster.get("status", {}).get("conditions") or []
            for c in conditions:
                msg = (c.get("message") or "").lower()
                reason = (c.get("reason") or "").lower()
                if any(k in msg or k in reason for k in keywords):
                    failed.append(f"{namespace}/{name}")
                    break
        if failed:
            result = "WARN"
            details = "Clusters stuck in Pending (osConfiguration/secret): " + ", ".join(failed[:10])
            if len(failed) > 10:
                details += f" (and {len(failed) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/398390"
        else:
            details = "No clusters stuck in Pending with secret/topology errors."
        logger.debug("INFO: Supervisor cluster creation check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check cluster creation: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/398390"}


def supervisor_clusterclass_reconciled_check():
    """
    Check for clusters with ClusterClass VariablesReconciled not True (KB 424003).
    Runtime-extension cert / clusterclass not successfully reconciled.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor ClusterClass Reconciled Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get cluster -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get clusters"}
        data = json.loads(output)
        items = data.get("items") or []
        failed = []
        for cluster in items:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            conditions = cluster.get("status", {}).get("conditions") or []
            for c in conditions:
                msg = (c.get("message") or "").lower()
                ctype = (c.get("type") or "").lower()
                if "variablesreconciled" in ctype and c.get("status") != "True":
                    failed.append(f"{namespace}/{name}")
                    break
                if "clusterclass" in msg and "not successfully reconciled" in msg:
                    failed.append(f"{namespace}/{name}")
                    break
        if failed:
            result = "WARN"
            details = "Clusters with ClusterClass/VariablesReconciled issue: " + ", ".join(failed[:10])
            if len(failed) > 10:
                details += f" (and {len(failed) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/424003"
        else:
            details = "No ClusterClass reconciliation issues detected."
        logger.debug("INFO: Supervisor clusterclass reconciled check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check clusterclass: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/424003"}


def supervisor_tkc_kapp_controller_stuck_check():
    """
    Check for TKC stuck with pre-existing kapp-controller (KB 403742).
    Conditions/events: 'found pre-existing kapp-controller', 'requires user remediation', 'ClusterBootstrapFailed'.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor TKC Kapp-Controller Stuck Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get tkc -A -o json 2>/dev/null || kubectl get tanzukubernetesclusters -A -o json 2>/dev/null"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get TKC list"}
        data = json.loads(output)
        items = data.get("items") or []
        keywords = ("pre-existing kapp-controller", "requires user remediation", "clusterbootstrapfailed")
        failed = []
        for tkc in items:
            name = tkc.get("metadata", {}).get("name", "unknown")
            namespace = tkc.get("metadata", {}).get("namespace", "unknown")
            conditions = tkc.get("status", {}).get("conditions") or []
            for c in conditions:
                msg = (c.get("message") or "").lower()
                reason = (c.get("reason") or "").lower()
                if any(k in msg or k in reason for k in keywords):
                    failed.append(f"{namespace}/{name}")
                    break
        if failed:
            result = "WARN"
            details = "TKC(s) stuck with kapp-controller upgrade: " + ", ".join(failed[:10])
            if len(failed) > 10:
                details += f" (and {len(failed) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/403742"
        else:
            details = "No TKC kapp-controller stuck detected."
        logger.debug("INFO: Supervisor TKC kapp-controller stuck check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check TKC kapp-controller: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/403742"}


def supervisor_ako_pods_check():
    """
    Check that AKO pods in vmware-system-ako are healthy (KB 397598).
    CrashLoopBackOff often due to x509 certificate / NCP secret.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor AKO Pods Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get pods -n vmware-system-ako -o json 2>/dev/null"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get vmware-system-ako pods (namespace may not exist)."}
        pods_data = json.loads(output)
        items = pods_data.get("items") or []
        if not items:
            return {"title": title, "result": "PASS", "details": "No pods in vmware-system-ako (OK if AKO not installed)."}
        unhealthy = []
        for pod in items:
            name = pod.get("metadata", {}).get("name", "unknown")
            phase = pod.get("status", {}).get("phase", "unknown")
            for cs in pod.get("status", {}).get("containerStatuses") or []:
                state = cs.get("state", {}) or {}
                if state.get("waiting", {}).get("reason") in ("CrashLoopBackOff", "ImagePullBackOff", "ErrImagePull"):
                    unhealthy.append(f"{name}: {state['waiting'].get('reason', '')}")
                    break
            else:
                if phase != "Running":
                    unhealthy.append(f"{name}: phase={phase}")
        if unhealthy:
            result = "FAIL"
            details = "AKO pods not healthy:\n" + "\n".join(unhealthy[:5])
            if len(unhealthy) > 5:
                details += f"\n(and {len(unhealthy) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/397598"
        else:
            details = f"All {len(items)} AKO pods in vmware-system-ako are healthy."
        logger.debug("INFO: Supervisor AKO pods check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check AKO pods: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed to check AKO pods: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/397598"}


def supervisor_storage_quota_check():
    """
    Check for storage quota issues (KB 391096).
    PVC creation may fail with 'insufficient storage quota for storage policy' due to incorrect quota usage.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Storage Quota Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        # Check for StoragePolicyQuota / StorageQuota CRs (vCenter 8.0U3+)
        command = "kubectl get storagepolicyquota,storagequota -A -o json 2>/dev/null"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "PASS", "details": "Storage quota CRs not found (OK if pre-8.0U3)."}
        try:
            data = json.loads(output)
            items = data.get("items") if isinstance(data, dict) else []
            if not items and isinstance(data, dict) and "items" not in data:
                return {"title": title, "result": "PASS", "details": "No storage quota resources."}
            # Optional: compare usage vs limit if we want to WARN on high usage; for now just report OK
            details = f"Storage quota resources present ({len(items)}). Refer to KB 391096 if PVC creation fails with insufficient quota."
            logger.debug("INFO: Supervisor storage quota check completed: %s", result)
            return {"title": title, "result": result, "details": details}
        except json.JSONDecodeError:
            pass
        details = "Could not parse storage quota output. Refer to KB https://knowledge.broadcom.com/external/article/391096 if PVC creation fails."
        return {"title": title, "result": "PASS", "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check storage quota: %s", e)
        return {"title": title, "result": "WARN", "details": f"Could not check storage quota: {e}. Refer to KB https://knowledge.broadcom.com/external/article/391096 if PVC creation fails."}


def supervisor_pods_check():
    """
    Check if all pods are in running or completed state.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Pods Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get pods -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        pods_data = json.loads(output)
        
        if not pods_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No pods found"}
        
        failed_pods = []
        pending_pods = []
        restarting_pods = []
        
        for pod in pods_data["items"]:
            name = pod.get("metadata", {}).get("name", "unknown")
            namespace = pod.get("metadata", {}).get("namespace", "unknown")
            phase = pod.get("status", {}).get("phase", "unknown")
            
            # Check container statuses for more detailed information
            container_statuses = pod.get("status", {}).get("containerStatuses", [])
            restart_count = sum(cs.get("restartCount", 0) for cs in container_statuses)
            
            # Check for high restart counts
            if restart_count > 5:
                restarting_pods.append(f"{namespace}/{name}: {restart_count} restarts")
            
            if phase == "Pending":
                # Get pending reason if available
                conditions = pod.get("status", {}).get("conditions", [])
                pending_reason = ""
                for condition in conditions:
                    if condition.get("type") == "PodScheduled" and condition.get("status") == "False":
                        pending_reason = condition.get("reason", "")
                        break
                pod_info = f"{namespace}/{name}"
                if pending_reason:
                    pod_info += f": {pending_reason}"
                pending_pods.append(pod_info)
            elif phase not in ["Running", "Succeeded"]:
                # Get failure details
                pod_info = f"{namespace}/{name}: {phase}"
                
                # Check container states for more details
                for cs in container_statuses:
                    if cs.get("state", {}).get("waiting"):
                        reason = cs.get("state", {}).get("waiting", {}).get("reason", "")
                        if reason:
                            pod_info += f", waiting: {reason}"
                    elif cs.get("state", {}).get("terminated"):
                        reason = cs.get("state", {}).get("terminated", {}).get("reason", "")
                        if reason:
                            pod_info += f", terminated: {reason}"
                
                failed_pods.append(pod_info)
        
        if failed_pods:
            result = "FAIL"
            details = f"Failed pods:\n" + "\n".join(failed_pods[:5])
            if len(failed_pods) > 5:
                details += f"\n(and {len(failed_pods) - 5} more)"
        elif pending_pods:
            result = "WARN"
            details = f"Pending pods:\n" + "\n".join(pending_pods[:3])
            if len(pending_pods) > 3:
                details += f"\n(and {len(pending_pods) - 3} more)"
        elif restarting_pods:
            result = "WARN"
            details = f"High restart pods:\n" + "\n".join(restarting_pods[:3])
            if len(restarting_pods) > 3:
                details += f"\n(and {len(restarting_pods) - 3} more)"
        else:
            details = f"All {len(pods_data['items'])} pods are running or completed"
            
        logger.debug(f"INFO: Pod check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check pods: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check pods: {e}"}


def supervisor_csi_pods_check():
    """
    Check that CSI pods in vmware-system-csi namespace are healthy.
    Unhealthy CSI (e.g. CrashLoopBackOff, not fully ready) can indicate workload_storage_management
    password sync issues (KB 345473).
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor CSI Pods Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get pods -n vmware-system-csi -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get vmware-system-csi pods (namespace may not exist)."}

        pods_data = json.loads(output)
        items = pods_data.get("items") or []

        if not items:
            return {"title": title, "result": "PASS", "details": "No pods in vmware-system-csi (OK if CSI not installed)."}

        unhealthy = []
        for pod in items:
            name = pod.get("metadata", {}).get("name", "unknown")
            phase = pod.get("status", {}).get("phase", "unknown")
            container_statuses = pod.get("status", {}).get("containerStatuses", [])
            ready_count = sum(1 for cs in container_statuses if cs.get("ready") is True)
            total = len(container_statuses)
            status_reason = ""
            for cs in container_statuses:
                state = cs.get("state", {})
                if state.get("waiting"):
                    reason = state["waiting"].get("reason", "")
                    if reason in ("CrashLoopBackOff", "ImagePullBackOff", "ErrImagePull"):
                        status_reason = reason
                        break
            if phase != "Running" or (total and ready_count != total) or status_reason:
                msg = f"vmware-system-csi/{name}: phase={phase}"
                if total:
                    msg += f", ready={ready_count}/{total}"
                if status_reason:
                    msg += f", {status_reason}"
                unhealthy.append(msg)

        if unhealthy:
            result = "FAIL"
            details = "CSI pods not healthy:\n" + "\n".join(unhealthy[:5])
            if len(unhealthy) > 5:
                details += f"\n(and {len(unhealthy) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/345473"
        else:
            details = f"All {len(items)} CSI pods in vmware-system-csi are healthy."

        logger.debug(f"INFO: Supervisor CSI pods check completed: {result}")
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug(f"ERROR: Failed to check CSI pods: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check CSI pods: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/345473"}


def supervisor_pvc_resize_check():
    """
    Check for PVCs with resize failure due to FCD snapshots (KB 313099).
    VolumeResizeFailed or message containing 'snapshot' indicates disk has snapshots.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor PVC Resize Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get pvc -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get PVC list"}
        pvcs_data = json.loads(output)
        items = pvcs_data.get("items") or []
        resize_failed = []
        for pvc in items:
            name = pvc.get("metadata", {}).get("name", "unknown")
            namespace = pvc.get("metadata", {}).get("namespace", "unknown")
            conditions = pvc.get("status", {}).get("conditions") or []
            for c in conditions:
                ctype = (c.get("type") or "").strip()
                msg = (c.get("message") or "").lower()
                reason = (c.get("reason") or "").strip()
                if "VolumeResizeFailed" in reason or "resizefailed" in msg:
                    resize_failed.append(f"{namespace}/{name}")
                    break
                if ctype in ("Resizing", "FileSystemResizePending") and ("snapshot" in msg or "expand" in msg):
                    resize_failed.append(f"{namespace}/{name}")
                    break
        if resize_failed:
            result = "FAIL"
            details = "PVCs with resize failure (disk may have snapshots):\n" + "\n".join(resize_failed[:10])
            if len(resize_failed) > 10:
                details += f"\n(and {len(resize_failed) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/313099"
        else:
            details = "No PVC resize failures detected."
        logger.debug(f"INFO: Supervisor PVC resize check completed: {result}")
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug(f"ERROR: Failed to check PVC resize: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check PVC resize: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/313099"}


# Unsupported node volume mount paths (KB 319405)
NODE_VOLUME_MOUNT_UNSUPPORTED = (
    "/", "/bin", "/sbin", "/lib", "/lib64", "/boot", "/dev", "/proc", "/sys",
    "/etc", "/run", "/usr", "/var", "/var/lib", "/var/run",
)


def _collect_mount_paths_from_spec(obj, paths, prefix=""):
    """Recursively collect mountPath-like strings from a spec dict."""
    if not isinstance(obj, dict):
        return
    for k, v in obj.items():
        if k in ("mountPath", "path") and isinstance(v, str) and v.strip():
            paths.add(v.strip().rstrip("/") or "/")
        elif isinstance(v, dict):
            _collect_mount_paths_from_spec(v, paths, prefix + k + ".")
        elif isinstance(v, list):
            for item in v:
                if isinstance(item, dict):
                    _collect_mount_paths_from_spec(item, paths, prefix)


def supervisor_node_volume_mount_check():
    """
    Check that node volume mounts on clusters use supported paths (KB 319405).
    Unsupported paths: /, /etc, /var, /usr, /bin, etc. Supported: /var/lib/containerd, /var/lib/kubelet.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Node Volume Mount Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get cluster -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get cluster list"}
        data = json.loads(output)
        items = data.get("items") or []
        unsupported_found = []
        for cluster in items:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            spec = cluster.get("spec", {}) or {}
            paths = set()
            _collect_mount_paths_from_spec(spec, paths)
            for p in paths:
                path_norm = p.rstrip("/") or "/"
                if path_norm in NODE_VOLUME_MOUNT_UNSUPPORTED:
                    unsupported_found.append(f"{namespace}/{name}: {p}")
                else:
                    for bad in NODE_VOLUME_MOUNT_UNSUPPORTED:
                        if bad != "/" and path_norm.startswith(bad + "/"):
                            unsupported_found.append(f"{namespace}/{name}: {p}")
                            break
        if unsupported_found:
            result = "WARN"
            details = "Clusters with possibly unsupported node volume mount paths:\n" + "\n".join(unsupported_found[:10])
            if len(unsupported_found) > 10:
                details += f"\n(and {len(unsupported_found) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/319405"
        else:
            details = "No unsupported node volume mount paths detected."
        logger.debug("INFO: Supervisor node volume mount check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check node volume mounts: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed to check node volume mounts: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/319405"}


def supervisor_terminating_namespace_check():
    """
    Check for namespaces stuck in Terminating (KB 382297).
    Underlying objects (Cluster, TKC, etc.) may be stuck deleting; PDBs can block node deletion (KB 345904).
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Terminating Namespace Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    try:
        command = "kubectl get ns -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        if not output:
            return {"title": title, "result": "WARN", "details": "Could not get namespaces"}
        data = json.loads(output)
        items = data.get("items") or []
        terminating = []
        for ns in items:
            name = ns.get("metadata", {}).get("name", "")
            phase = ns.get("status", {}).get("phase", "")
            if phase == "Terminating":
                terminating.append(name)
        if terminating:
            result = "WARN"
            details = "Namespaces stuck in Terminating: " + ", ".join(terminating[:10])
            if len(terminating) > 10:
                details += f" (and {len(terminating) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/382297"
            details += "\nFor workload cluster nodes stuck deleting, see KB https://knowledge.broadcom.com/external/article/345904"
        else:
            details = "No namespaces stuck in Terminating."
        logger.debug("INFO: Supervisor terminating namespace check completed: %s", result)
        return {"title": title, "result": result, "details": details}
    except Exception as e:
        logger.debug("ERROR: Failed to check terminating namespaces: %s", e)
        return {"title": title, "result": "FAIL", "details": f"Failed to check namespaces: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/382297"}


def supervisor_vms_check():
    """
    Check if all VMs are powered on and healthy.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor VMs Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get vm -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        vms_data = json.loads(output)
        
        if not vms_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No VMs found"}
        
        powered_off_vms = []
        transitioning_vms = []
        
        for vm in vms_data["items"]:
            name = vm.get("metadata", {}).get("name", "unknown")
            namespace = vm.get("metadata", {}).get("namespace", "unknown")
            power_state = vm.get("status", {}).get("powerState", "unknown")
            vm_ip = vm.get("status", {}).get("vmIp", "")
            
            # Check for transitioning states
            if power_state in ["PoweringOn", "PoweringOff", "Resetting"]:
                transitioning_vms.append(f"{namespace}/{name}: {power_state}")
            elif power_state != "PoweredOn":
                vm_info = f"{namespace}/{name}: {power_state}"
                if not vm_ip and power_state == "PoweredOn":
                    vm_info += " (no IP)"
                powered_off_vms.append(vm_info)
        
        if powered_off_vms:
            result = "FAIL"
            details = f"VMs not powered on:\n" + "\n".join(powered_off_vms)
        elif transitioning_vms:
            result = "WARN"
            details = f"VMs transitioning:\n" + "\n".join(transitioning_vms)
        else:
            details = f"All {len(vms_data['items'])} VMs are powered on"
            
        logger.debug(f"INFO: VM check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check VMs: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check VMs: {e}"}

def supervisor_pkgi_check():
    """
    Check if all package installs (PKGI) are reconcile succeeded.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Package Installs Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get pkgi -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        pkgi_data = json.loads(output)
        
        if not pkgi_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No package installs found"}
        
        failed_pkgi = []
        reconciling_pkgi = []
        
        for pkgi in pkgi_data["items"]:
            name = pkgi.get("metadata", {}).get("name", "unknown")
            namespace = pkgi.get("metadata", {}).get("namespace", "unknown")
            conditions = pkgi.get("status", {}).get("conditions", [])
            
            # Check for ReconcileSucceeded condition
            reconcile_succeeded = False
            reconciling = False
            failure_message = ""
            
            for condition in conditions:
                condition_type = condition.get("type", "")
                condition_status = condition.get("status", "")
                
                if condition_type == "ReconcileSucceeded":
                    if condition_status == "True":
                        reconcile_succeeded = True
                    else:
                        failure_message = condition.get("message", "")
                elif condition_type == "Reconciling" and condition_status == "True":
                    reconciling = True
            
            if reconciling and not reconcile_succeeded:
                reconciling_pkgi.append(f"{namespace}/{name}")
            elif not reconcile_succeeded:
                # Get the actual status if available
                status_summary = pkgi.get("status", {}).get("friendlyDescription", "")
                pkgi_info = f"{namespace}/{name}"
                if status_summary:
                    pkgi_info += f": {status_summary}"
                elif failure_message:
                    pkgi_info += f": {failure_message[:50]}..."
                else:
                    pkgi_info += ": not reconciled"
                failed_pkgi.append(pkgi_info)
        
        if failed_pkgi:
            result = "FAIL" 
            details = f"Package installs failed:\n" + "\n".join(failed_pkgi[:3])
            if len(failed_pkgi) > 3:
                details += f"\n(and {len(failed_pkgi) - 3} more)"
        elif reconciling_pkgi:
            result = "WARN"
            details = f"Package installs reconciling:\n" + "\n".join(reconciling_pkgi)
        else:
            details = f"All {len(pkgi_data['items'])} package installs are reconcile succeeded"
            
        logger.debug(f"INFO: PKGI check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check package installs: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check package installs: {e}"}

def supervisor_pvc_check():
    """
    Check PVC (Persistent Volume Claims) status.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor PVCs Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get pvc -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        pvcs_data = json.loads(output)
        
        if not pvcs_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No PVCs found"}
        
        failed_pvcs = []
        pending_pvcs = []
        terminating_pvcs = []
        for pvc in pvcs_data["items"]:
            name = pvc.get("metadata", {}).get("name", "unknown")
            namespace = pvc.get("metadata", {}).get("namespace", "unknown")
            phase = pvc.get("status", {}).get("phase", "unknown")
            if pvc.get("metadata", {}).get("deletionTimestamp"):
                terminating_pvcs.append(f"{namespace}/{name}")
            if phase == "Pending":
                pending_pvcs.append(f"{namespace}/{name}")
            elif phase not in ["Bound", "Available"]:
                failed_pvcs.append(f"{namespace}/{name}: {phase}")
        
        if failed_pvcs:
            result = "FAIL"
            details = f"Failed PVCs:\n" + "\n".join(failed_pvcs)
        elif pending_pvcs:
            result = "WARN"
            details = f"Pending PVCs:\n" + "\n".join(pending_pvcs)
        else:
            details = f"All {len(pvcs_data['items'])} PVCs are bound"
        if terminating_pvcs:
            details += f"\nPVCs stuck Terminating (vCenter attach/detach spam): " + ", ".join(terminating_pvcs[:5])
            if len(terminating_pvcs) > 5:
                details += f" (and {len(terminating_pvcs) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/411248"
            
        logger.debug(f"INFO: PVC check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check PVCs: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check PVCs: {e}"}

def supervisor_service_check():
    """
    Check service status and ensure critical services exist.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Services/Endpoints Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get services -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        services_data = json.loads(output)
        
        if not services_data.get("items"):
            return {"title": title, "result": "WARN", "details": "No services found"}
        
        # Check for critical services
        critical_services = ["kubernetes", "kube-dns"]
        existing_services = []
        for svc in services_data["items"]:
            name = svc.get("metadata", {}).get("name", "unknown")
            namespace = svc.get("metadata", {}).get("namespace", "unknown")
            existing_services.append(f"{namespace}/{name}")
        
        missing_critical = []
        for critical in critical_services:
            found = any(critical in svc for svc in existing_services)
            if not found:
                missing_critical.append(critical)
        
        if missing_critical:
            result = "WARN"
            details = f"Missing critical services:\n" + "\n".join(missing_critical)
        else:
            details = f"All {len(services_data['items'])} services are present"
            
        logger.debug(f"INFO: Service check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check services: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check services: {e}"}

def supervisor_deployments_check():
    """
    Check if all deployments are ready and available.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Deployments Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get deployments -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        deployments_data = json.loads(output)
        
        if not deployments_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No deployments found"}
        
        failed_deployments = []
        scaling_deployments = []
        
        for deployment in deployments_data["items"]:
            name = deployment.get("metadata", {}).get("name", "unknown")
            namespace = deployment.get("metadata", {}).get("namespace", "unknown")
            spec_replicas = deployment.get("spec", {}).get("replicas", 0)
            status = deployment.get("status", {})
            available_replicas = status.get("availableReplicas", 0)
            ready_replicas = status.get("readyReplicas", 0)
            updated_replicas = status.get("updatedReplicas", 0)
            
            if available_replicas != spec_replicas or ready_replicas != spec_replicas:
                if updated_replicas != spec_replicas:
                    scaling_deployments.append(f"{namespace}/{name}: {available_replicas}/{spec_replicas} available, updating")
                else:
                    failed_deployments.append(f"{namespace}/{name}: {available_replicas}/{spec_replicas} available")
        
        if failed_deployments:
            result = "FAIL"
            details = f"Deployments not ready:\n" + "\n".join(failed_deployments[:3])
            if len(failed_deployments) > 3:
                details += f"\n(and {len(failed_deployments) - 3} more)"
        elif scaling_deployments:
            result = "WARN"
            details = f"Deployments scaling:\n" + "\n".join(scaling_deployments)
        else:
            details = f"All {len(deployments_data['items'])} deployments are ready"
            
        logger.debug(f"INFO: Deployment check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check deployments: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check deployments: {e}"}

def supervisor_daemonsets_check():
    """
    Check if all DaemonSets have desired number of pods ready.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor DaemonSets Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get daemonsets -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        daemonsets_data = json.loads(output)
        
        if not daemonsets_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No DaemonSets found"}
        
        failed_daemonsets = []
        updating_daemonsets = []
        
        for ds in daemonsets_data["items"]:
            name = ds.get("metadata", {}).get("name", "unknown")
            namespace = ds.get("metadata", {}).get("namespace", "unknown")
            status = ds.get("status", {})
            desired = status.get("desiredNumberScheduled", 0)
            ready = status.get("numberReady", 0)
            available = status.get("numberAvailable", 0)
            updated = status.get("updatedNumberScheduled", 0)
            
            if ready != desired or available != desired:
                if updated != desired:
                    updating_daemonsets.append(f"{namespace}/{name}: {ready}/{desired} ready, updating")
                else:
                    failed_daemonsets.append(f"{namespace}/{name}: {ready}/{desired} ready, {available}/{desired} available")
        
        if failed_daemonsets:
            result = "FAIL"
            details = f"DaemonSets not ready:\n" + "\n".join(failed_daemonsets[:3])
            if len(failed_daemonsets) > 3:
                details += f"\n(and {len(failed_daemonsets) - 3} more)"
        elif updating_daemonsets:
            result = "WARN"
            details = f"DaemonSets updating:\n" + "\n".join(updating_daemonsets)
        else:
            details = f"All {len(daemonsets_data['items'])} DaemonSets are ready"
            
        logger.debug(f"INFO: DaemonSet check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check DaemonSets: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check DaemonSets: {e}"}

def supervisor_statefulsets_check():
    """
    Check if all StatefulSets have desired number of replicas ready.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor StatefulSets Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get statefulsets -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        statefulsets_data = json.loads(output)
        
        if not statefulsets_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No StatefulSets found"}
        
        failed_statefulsets = []
        updating_statefulsets = []
        
        for sts in statefulsets_data["items"]:
            name = sts.get("metadata", {}).get("name", "unknown")
            namespace = sts.get("metadata", {}).get("namespace", "unknown")
            spec_replicas = sts.get("spec", {}).get("replicas", 0)
            status = sts.get("status", {})
            ready_replicas = status.get("readyReplicas", 0)
            current_replicas = status.get("currentReplicas", 0)
            updated_replicas = status.get("updatedReplicas", 0)
            
            if ready_replicas != spec_replicas:
                if updated_replicas != spec_replicas or current_replicas != spec_replicas:
                    updating_statefulsets.append(f"{namespace}/{name}: {ready_replicas}/{spec_replicas} ready, updating")
                else:
                    failed_statefulsets.append(f"{namespace}/{name}: {ready_replicas}/{spec_replicas} ready")
        
        if failed_statefulsets:
            result = "FAIL"
            details = f"StatefulSets not ready:\n" + "\n".join(failed_statefulsets[:3])
            if len(failed_statefulsets) > 3:
                details += f"\n(and {len(failed_statefulsets) - 3} more)"
        elif updating_statefulsets:
            result = "WARN"
            details = f"StatefulSets updating:\n" + "\n".join(updating_statefulsets)
        else:
            details = f"All {len(statefulsets_data['items'])} StatefulSets are ready"
            
        logger.debug(f"INFO: StatefulSet check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check StatefulSets: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check StatefulSets: {e}"}

def supervisor_replicasets_check():
    """
    Check if all ReplicaSets have desired number of replicas available.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor ReplicaSets Status Check"
    result = "PASS"
    details = ""
    
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        command = "kubectl get replicasets -A -o json"
        output = run_ssh_command(supervisor_ip, "root", command)
        replicasets_data = json.loads(output)
        
        if not replicasets_data.get("items"):
            return {"title": title, "result": "PASS", "details": "No ReplicaSets found"}
        
        failed_replicasets = []
        
        for rs in replicasets_data["items"]:
            name = rs.get("metadata", {}).get("name", "unknown")
            namespace = rs.get("metadata", {}).get("namespace", "unknown")
            spec_replicas = rs.get("spec", {}).get("replicas", 0)
            status = rs.get("status", {})
            ready_replicas = status.get("readyReplicas", 0)
            available_replicas = status.get("availableReplicas", 0)
            
            # Skip ReplicaSets with 0 desired replicas (old/scaled down)
            if spec_replicas == 0:
                continue
                
            if ready_replicas != spec_replicas or available_replicas != spec_replicas:
                failed_replicasets.append(f"{namespace}/{name}: {ready_replicas}/{spec_replicas} ready, {available_replicas}/{spec_replicas} available")
        
        if failed_replicasets:
            result = "FAIL"
            details = f"ReplicaSets not ready:\n" + "\n".join(failed_replicasets[:3])
            if len(failed_replicasets) > 3:
                details += f"\n(and {len(failed_replicasets) - 3} more)"
        else:
            # Count only active ReplicaSets (with replicas > 0)
            active_rs = sum(1 for rs in replicasets_data["items"] if rs.get("spec", {}).get("replicas", 0) > 0)
            details = f"All {active_rs} active ReplicaSets are ready"
            
        logger.debug(f"INFO: ReplicaSet check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check ReplicaSets: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check ReplicaSets: {e}"}

def supervisor_objects_all_checks():
    """
    Run all object checks and return a list of result dicts.
    """
    results = []
    try:
        results.append(supervisor_clusters_check())
        results.append(supervisor_machines_check())
        results.append(supervisor_nodes_check())
        results.append(supervisor_pods_check())
        results.append(supervisor_vms_check())
        results.append(supervisor_pkgi_check())
        results.append(supervisor_pvc_check())
        results.append(supervisor_service_check())
        results.append(supervisor_deployments_check())
        results.append(supervisor_daemonsets_check())
        results.append(supervisor_statefulsets_check())
        results.append(supervisor_replicasets_check())
    except Exception as e:
        logger.debug(f"ERROR: Failed to run object checks: {e}")
        results.append({
            "title": "Supervisor Objects Check",
            "result": "FAIL",
            "details": f"Failed to run object checks: {e}"
        })
    return results

if __name__ == "__main__":
    # Example usage
    results = supervisor_objects_all_checks()
    for result in results:
        print(f"{result['title']}: {result['result']} - {result['details']}")