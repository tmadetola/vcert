__title__ = "vCenter Basic Info"

import os
import sys
import subprocess
from datetime import datetime
from multiprocessing import cpu_count
from vks.vks_cfg.current_defaults import *
import logging
try:
    from urllib.parse import urlparse as urlparse
except ImportError:
    from urlparse import urlparse as urlparse

logger = logging.getLogger(__name__)
_DefaultCommmandEncoding = sys.getfilesystemencoding()


def run_command(cmd, stdin=None, quiet=False, close_fds=False,
                encoding=_DefaultCommmandEncoding, log_command=True):

    """
    Run a command and return the output.

    Args:
        cmd (list or str): The command to run. If it is a string, the command will be executed through the shell.
        stdin (str, optional): Input to be passed to the command. The input will be sent via stdin.
        quiet (bool, optional): If True, suppresses any output to stdout and stderr. Defaults to False.
        close_fds (bool, optional): If True, close all file descriptors, except stdin, stdout, and stderr before executing the command. Defaults to False.
        encoding (str, optional): The encoding to be used for stdin, stdout, and stderr. Defaults to _DefaultCommmandEncoding.
        log_command (bool, optional): If True, logs the executed command. Defaults to True.

    Returns:
        bytes: The output of the command.

    Note:
        This function uses subprocess.Popen to run the command.
    """    
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, stdin=subprocess.PIPE)
    if sys.version_info[0] >= 3 and isinstance(stdin, str):
        stdin = stdin.encode(encoding)
    stdout, stderr = process.communicate(stdin)
    return stdout

def getVcsaIp():
    """
    Get the IP address of a network interface.

    Returns:
        str: The IP address of the network interface.

    Raises:
        None
    """    
    logger.debug("Getting IP from ifconfig")
    ip = ""
    ifconfig = run_command(["ifconfig", "eth0"])
    ifconfig = ifconfig.decode()
    for line in ifconfig.split('\n'):
        mylist = list(line.split())
        for param in mylist:
            if "addr:" in param:
                ip = param.split(':')[1]
    return ip

def getMem():
    """
    Get the available system memory in gigabytes.

    Returns:
        float: The available system memory in gigabytes.
    """    
    logger.debug("Getting memory")
    mem_bytes = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES')  # e.g. 4015976448
    mem_gb = round(mem_bytes/(1024.**3), 2)
    return mem_gb


def getUptime():
    """
    Get the system uptime and load average.

    Returns:
        tuple: A tuple containing the system uptime and load average. The system uptime is a string indicating the time duration the system has been running, and the load average is a string indicating the average load on the system.
    """    
    logger.debug("Getting uptime")
    cmd = ['/usr/bin/uptime']
    output = run_command(cmd).decode().split('\n')
    output = [x for x in output if x]
    output = output[0].split(',  ')
    uptime = output[0].split(', ')[0]
    uptime = uptime.split()
    del uptime[0]
    uptime = ' '.join(uptime)
    for item in output:
        if 'load average' in item:
            loadavg = item.replace('load average: ','')
        else:
            continue
    return uptime,loadavg

def VcInfo():
    """
    Retrieve vCenter information including hostname, IP address, version, uptime, load average, and other system details.
    Returns:
        dict:
            A dictionary containing the following keys:
            - pnid: The PNID of the vCenter.
            - ssodomain: The SSO domain of the vCenter.
            - version: The version and build of the vCenter.
            - uptime: The uptime of the vCenter.
            - loadavg: The load average of the vCenter.
            - currenttime: The current time when the information was retrieved.
            - hostname: The hostname of the vCenter.
            - ip: The IP address of the vCenter.
            - numcpus: The number of CPUs in the vCenter.
            - nummem: The total memory in GB available in the vCenter.
    """
    info = {}


    info["pnid"] = pnid
    info["ssodomain"] = sso_domain
    info["version"] = vc_version + " - " + vc_build
    uptime, loadavg = getUptime()
    info['currenttime'] = datetime.now()
    info["hostname"] = hostname
    info["ip"] = getVcsaIp()
    info["numcpus"] = cpu_count()
    info["nummem"] = getMem()
    info["uptime"] = uptime
    info["loadavg"] = loadavg

    return info

def main():
    """
    The main function that retrieves vCenter information and returns formatted details.

    Returns:
        dict: A dictionary containing following keys:
            - title (str): The title of the vCenter information.
            - result (str): The result of the function, which is 'INFO'.
            - details (str): The formatted details of the vCenter information.

    Raises:
        None
    """    
    info = VcInfo()
    pnidkb = ""

    details = """
Current Time: {currenttime}
vCenter Uptime: {uptime}
vCenter Load Average: {loadavg}
Number of CPUs: {numcpus}
Total Memory: {nummem}
vCenter Hostname: {hostname}
vCenter PNID: {pnid}
vCenter IP Address: {ip}
vCenter Version: {version}""".format(**info)

    title = __title__
    result = "INFO"

    return {"title": title, "result": result, "details": details}

if __name__ == '__main__':
    main()