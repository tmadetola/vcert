import json
import logging
from vks.vks_lib.vks_tkc_utils import (
    get_tkc_manager,
    get_ssh_key_for_cluster,
    parse_cluster_version,
    run_check_on_all_clusters,
    run_kubectl_on_supervisor,
    run_kubectl_on_tkc,
)

logger = logging.getLogger(__name__)

def tkc_all_clusters_status_check():
    """
    Check the status of all TKC clusters from the Supervisor perspective.
    This checks the cluster.x-k8s.io/Cluster resources on the Supervisor.
    Returns a result dict with per-cluster status.
    
    A cluster is considered healthy if:
    - Phase is "Provisioned" AND (Available=True OR Ready=True)
    
    A cluster is considered unhealthy if:
    - Phase is "Provisioned" but neither Available nor Ready
    - Phase is something other than Provisioned/Provisioning
    """
    title = "TKC Clusters Status Check"
    result = "PASS"
    details = ""
    
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        # Force refresh to get current state
        clusters = tkc_manager.get_tkc_clusters(force_refresh=True)
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        
        failed_clusters = []
        provisioning_clusters = []
        healthy_clusters = []
        
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            status = cluster.get("status", {})
            phase = status.get("phase", "unknown")
            
            cluster_id = f"{namespace}/{name}"
            
            # Check conditions for Available/Ready status (Cluster API v1beta2 format)
            conditions = status.get("conditions", [])
            is_available = False
            is_ready = False
            
            for condition in conditions:
                cond_type = condition.get("type")
                cond_status = condition.get("status") == "True"
                if cond_type == "Available":
                    is_available = cond_status
                elif cond_type == "Ready":
                    is_ready = cond_status
            
            # Also check deprecated v1beta1 conditions as fallback for Ready status
            deprecated_conditions = status.get("deprecated", {}).get("v1beta1", {}).get("conditions", [])
            for condition in deprecated_conditions:
                cond_type = condition.get("type")
                cond_status = condition.get("status") == "True"
                if cond_type == "Ready" and not is_ready:
                    is_ready = cond_status
            
            logger.debug(f"Cluster {cluster_id}: phase={phase}, available={is_available}, ready={is_ready}")
            
            # Determine cluster health based on phase and conditions
            if phase == "Provisioning":
                provisioning_clusters.append(cluster_id)
            elif phase == "Provisioned" and (is_available or is_ready):
                healthy_clusters.append(cluster_id)
            elif phase != "Provisioned":
                # Get failure reason if available
                failure_reason = status.get("failureReason", "")
                failure_message = status.get("failureMessage", "")
                status_info = f"phase={phase}"
                if failure_reason:
                    status_info += f", reason={failure_reason}"
                if failure_message:
                    status_info += f", message={failure_message[:50]}..."
                failed_clusters.append(f"{cluster_id}: {status_info}")
            else:
                # Phase is Provisioned but neither Available nor Ready
                # Get more details about why it's not available
                not_available_reason = ""
                for condition in conditions:
                    if condition.get("type") == "Available" and condition.get("status") != "True":
                        not_available_reason = condition.get("message", "")[:80]
                        break
                
                status_info = f"phase={phase}, available={is_available}, ready={is_ready}"
                if not_available_reason:
                    status_info += f"\n    Reason: {not_available_reason}"
                failed_clusters.append(f"{cluster_id}: {status_info}")
        
        if failed_clusters:
            result = "FAIL"
            details = f"TKC clusters not ready:\n" + "\n".join(failed_clusters[:5])
            if len(failed_clusters) > 5:
                details += f"\n(and {len(failed_clusters) - 5} more)"
        elif provisioning_clusters:
            result = "WARN"
            details = f"TKC clusters provisioning:\n" + "\n".join(provisioning_clusters)
        else:
            details = f"All {len(healthy_clusters)} TKC clusters are provisioned and ready"
        
        logger.debug(f"INFO: TKC clusters status check completed: {result}")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check TKC clusters status: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check TKC clusters: {e}"}

def _tkc_single_cluster_nodes_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check nodes for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking nodes for cluster {cluster_id}")
    
    try:
        nodes_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get nodes -o json"
        )
        
        if not nodes_data:
            logger.debug(f"WARNING: Failed to get nodes data for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get nodes"
        
        if not nodes_data.get("items"):
            logger.debug(f"WARNING: No nodes found in cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: No nodes found"
        
        logger.debug(f"Found {len(nodes_data['items'])} nodes in cluster {cluster_id}")
        not_ready_nodes = []
        for node in nodes_data["items"]:
            node_name = node.get("metadata", {}).get("name", "unknown")
            conditions = node.get("status", {}).get("conditions", [])
            
            is_ready = False
            for condition in conditions:
                if condition.get("type") == "Ready" and condition.get("status") == "True":
                    is_ready = True
                    break
            
            if not is_ready:
                logger.debug(f"Node {node_name} in cluster {cluster_id} is not ready")
                not_ready_nodes.append(node_name)
        
        if not_ready_nodes:
            details = f"Cluster {cluster_id}: Nodes not ready:\n    " + "\n    ".join(not_ready_nodes[:5])
            if len(not_ready_nodes) > 5:
                details += f"\n    (and {len(not_ready_nodes) - 5} more)"
            return "FAIL", details
        
        return "PASS", f"Cluster {cluster_id}: All {len(nodes_data['items'])} nodes ready"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check nodes for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking nodes: {e}"


def tkc_all_clusters_nodes_check():
    """Check if all nodes in all TKC clusters are Ready."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_nodes_check,
        "TKC Clusters Nodes Check",
        "nodes"
    )


def _tkc_single_cluster_pods_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check pods for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking pods for cluster {cluster_id}")
    
    try:
        pods_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pods -A -o json"
        )
        
        if not pods_data:
            logger.debug(f"WARNING: Failed to get pods data for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get pods"
        
        if not pods_data.get("items"):
            logger.debug(f"No pods found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No pods found"
        
        logger.debug(f"Found {len(pods_data['items'])} pods in cluster {cluster_id}")
        failed_pods = []
        pending_pods = []
        high_restart_pods = []
        
        for pod in pods_data["items"]:
            pod_name = pod.get("metadata", {}).get("name", "unknown")
            pod_namespace = pod.get("metadata", {}).get("namespace", "unknown")
            phase = pod.get("status", {}).get("phase", "unknown")
            
            # Check container statuses for restart counts
            container_statuses = pod.get("status", {}).get("containerStatuses", [])
            restart_count = sum(cs.get("restartCount", 0) for cs in container_statuses)
            
            if restart_count > 5:
                logger.debug(f"Pod {pod_namespace}/{pod_name} in cluster {cluster_id} has {restart_count} restarts")
                high_restart_pods.append(f"{pod_namespace}/{pod_name}: {restart_count} restarts")
            
            if phase == "Pending":
                logger.debug(f"Pod {pod_namespace}/{pod_name} in cluster {cluster_id} is pending")
                pending_pods.append(f"{pod_namespace}/{pod_name}")
            elif phase not in ["Running", "Succeeded"]:
                logger.debug(f"Pod {pod_namespace}/{pod_name} in cluster {cluster_id} has phase {phase}")
                failed_pods.append(f"{pod_namespace}/{pod_name}: {phase}")
        
        if failed_pods:
            details = f"Cluster {cluster_id}: Failed pods:\n    " + "\n    ".join(failed_pods[:5])
            if len(failed_pods) > 5:
                details += f"\n    (and {len(failed_pods) - 5} more)"
            return "FAIL", details
        elif pending_pods:
            details = f"Cluster {cluster_id}: Pending pods:\n    " + "\n    ".join(pending_pods[:5])
            if len(pending_pods) > 5:
                details += f"\n    (and {len(pending_pods) - 5} more)"
            return "WARN", details
        elif high_restart_pods:
            details = f"Cluster {cluster_id}: High restart pods:\n    " + "\n    ".join(high_restart_pods[:5])
            if len(high_restart_pods) > 5:
                details += f"\n    (and {len(high_restart_pods) - 5} more)"
            return "WARN", details
        
        return "PASS", f"Cluster {cluster_id}: All {len(pods_data['items'])} pods healthy"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check pods for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking pods: {e}"


def tkc_all_clusters_pods_check():
    """Check if all pods in all TKC clusters are Running or Succeeded."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_pods_check,
        "TKC Clusters Pods Check",
        "pods"
    )

def _tkc_single_cluster_deployments_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check deployments for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking deployments for cluster {cluster_id}")
    
    try:
        deployments_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get deployments -A -o json"
        )
        
        if not deployments_data:
            logger.debug(f"WARNING: Failed to get deployments data for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get deployments"
        
        if not deployments_data.get("items"):
            logger.debug(f"No deployments found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No deployments found"
        
        logger.debug(f"Found {len(deployments_data['items'])} deployments in cluster {cluster_id}")
        failed_deployments = []
        
        for deployment in deployments_data["items"]:
            dep_name = deployment.get("metadata", {}).get("name", "unknown")
            dep_namespace = deployment.get("metadata", {}).get("namespace", "unknown")
            spec_replicas = deployment.get("spec", {}).get("replicas", 0)
            status = deployment.get("status", {})
            available_replicas = status.get("availableReplicas", 0)
            ready_replicas = status.get("readyReplicas", 0)
            
            if available_replicas != spec_replicas or ready_replicas != spec_replicas:
                logger.debug(f"Deployment {dep_namespace}/{dep_name} in cluster {cluster_id} not ready: {available_replicas}/{spec_replicas}")
                failed_deployments.append(f"{dep_namespace}/{dep_name}: {available_replicas}/{spec_replicas}")
        
        if failed_deployments:
            details = f"Cluster {cluster_id}: Deployments not ready:\n    " + "\n    ".join(failed_deployments[:5])
            if len(failed_deployments) > 5:
                details += f"\n    (and {len(failed_deployments) - 5} more)"
            return "FAIL", details
        
        logger.debug(f"All deployments ready in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {len(deployments_data['items'])} deployments ready"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check deployments for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking deployments: {e}"


def tkc_all_clusters_deployments_check():
    """Check if all deployments in all TKC clusters are available."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_deployments_check,
        "TKC Clusters Deployments Check",
        "deployments"
    )


def _tkc_single_cluster_daemonsets_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check DaemonSets for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking DaemonSets for cluster {cluster_id}")
    
    try:
        ds_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get daemonsets -A -o json"
        )
        
        if not ds_data:
            logger.debug(f"No DaemonSets data found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No DaemonSets found"
        
        if not ds_data.get("items"):
            logger.debug(f"No DaemonSets found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No DaemonSets found"
        
        logger.debug(f"Found {len(ds_data['items'])} DaemonSets in cluster {cluster_id}")
        failed_daemonsets = []
        updating_daemonsets = []
        
        for ds in ds_data["items"]:
            ds_name = ds.get("metadata", {}).get("name", "unknown")
            ds_namespace = ds.get("metadata", {}).get("namespace", "unknown")
            status = ds.get("status", {})
            desired = status.get("desiredNumberScheduled", 0)
            ready = status.get("numberReady", 0)
            available = status.get("numberAvailable", 0)
            updated = status.get("updatedNumberScheduled", 0)
            
            if ready != desired or available != desired:
                if updated != desired:
                    logger.debug(f"DaemonSet {ds_namespace}/{ds_name} in cluster {cluster_id} is updating: {ready}/{desired} ready")
                    updating_daemonsets.append(f"{ds_namespace}/{ds_name}: {ready}/{desired} ready, updating")
                else:
                    logger.debug(f"DaemonSet {ds_namespace}/{ds_name} in cluster {cluster_id} not ready: {ready}/{desired} ready")
                    failed_daemonsets.append(f"{ds_namespace}/{ds_name}: {ready}/{desired} ready, {available}/{desired} available")
        
        if failed_daemonsets:
            logger.debug(f"Found {len(failed_daemonsets)} failed DaemonSets in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: DaemonSets not ready:\n    " + "\n    ".join(failed_daemonsets[:5])
            if len(failed_daemonsets) > 5:
                details += f"\n    (and {len(failed_daemonsets) - 5} more)"
            return "FAIL", details
        elif updating_daemonsets:
            logger.debug(f"Found {len(updating_daemonsets)} updating DaemonSets in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: DaemonSets updating:\n    " + "\n    ".join(updating_daemonsets[:5])
            if len(updating_daemonsets) > 5:
                details += f"\n    (and {len(updating_daemonsets) - 5} more)"
            return "WARN", details
        
        logger.debug(f"All DaemonSets ready in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {len(ds_data['items'])} DaemonSets are ready"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check DaemonSets for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking DaemonSets: {e}"


def tkc_all_clusters_daemonsets_check():
    """Check if all DaemonSets in all TKC clusters have desired number of pods ready."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_daemonsets_check,
        "TKC Clusters DaemonSets Check",
        "DaemonSets"
    )

def _tkc_single_cluster_statefulsets_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check StatefulSets for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking StatefulSets for cluster {cluster_id}")
    
    try:
        sts_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get statefulsets -A -o json"
        )
        
        if not sts_data:
            logger.debug(f"No StatefulSets data found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No StatefulSets found"
        
        if not sts_data.get("items"):
            logger.debug(f"No StatefulSets found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No StatefulSets found"
        
        logger.debug(f"Found {len(sts_data['items'])} StatefulSets in cluster {cluster_id}")
        failed_statefulsets = []
        updating_statefulsets = []
        
        for sts in sts_data["items"]:
            sts_name = sts.get("metadata", {}).get("name", "unknown")
            sts_namespace = sts.get("metadata", {}).get("namespace", "unknown")
            spec_replicas = sts.get("spec", {}).get("replicas", 0)
            status = sts.get("status", {})
            ready_replicas = status.get("readyReplicas", 0)
            current_replicas = status.get("currentReplicas", 0)
            updated_replicas = status.get("updatedReplicas", 0)
            
            if ready_replicas != spec_replicas:
                if updated_replicas != spec_replicas or current_replicas != spec_replicas:
                    logger.debug(f"StatefulSet {sts_namespace}/{sts_name} in cluster {cluster_id} is updating: {ready_replicas}/{spec_replicas} ready")
                    updating_statefulsets.append(f"{sts_namespace}/{sts_name}: {ready_replicas}/{spec_replicas} ready, updating")
                else:
                    logger.debug(f"StatefulSet {sts_namespace}/{sts_name} in cluster {cluster_id} not ready: {ready_replicas}/{spec_replicas} ready")
                    failed_statefulsets.append(f"{sts_namespace}/{sts_name}: {ready_replicas}/{spec_replicas} ready")
        
        if failed_statefulsets:
            logger.debug(f"Found {len(failed_statefulsets)} failed StatefulSets in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: StatefulSets not ready:\n    " + "\n    ".join(failed_statefulsets[:5])
            if len(failed_statefulsets) > 5:
                details += f"\n    (and {len(failed_statefulsets) - 5} more)"
            return "FAIL", details
        elif updating_statefulsets:
            logger.debug(f"Found {len(updating_statefulsets)} updating StatefulSets in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: StatefulSets updating:\n    " + "\n    ".join(updating_statefulsets[:5])
            if len(updating_statefulsets) > 5:
                details += f"\n    (and {len(updating_statefulsets) - 5} more)"
            return "WARN", details
        
        logger.debug(f"All StatefulSets ready in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {len(sts_data['items'])} StatefulSets are ready"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check StatefulSets for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking StatefulSets: {e}"


def tkc_all_clusters_statefulsets_check():
    """Check if all StatefulSets in all TKC clusters have desired number of replicas ready."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_statefulsets_check,
        "TKC Clusters StatefulSets Check",
        "StatefulSets"
    )


def _tkc_single_cluster_replicasets_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check ReplicaSets for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking ReplicaSets for cluster {cluster_id}")
    
    try:
        rs_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get replicasets -A -o json"
        )
        
        if not rs_data:
            logger.debug(f"No ReplicaSets data found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No ReplicaSets found"
        
        if not rs_data.get("items"):
            logger.debug(f"No ReplicaSets found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No ReplicaSets found"
        
        logger.debug(f"Found {len(rs_data['items'])} ReplicaSets in cluster {cluster_id}")
        failed_replicasets = []
        active_count = 0
        
        for rs in rs_data["items"]:
            rs_name = rs.get("metadata", {}).get("name", "unknown")
            rs_namespace = rs.get("metadata", {}).get("namespace", "unknown")
            spec_replicas = rs.get("spec", {}).get("replicas", 0)
            status = rs.get("status", {})
            ready_replicas = status.get("readyReplicas", 0)
            available_replicas = status.get("availableReplicas", 0)
            
            # Skip ReplicaSets with 0 desired replicas (old/scaled down)
            if spec_replicas == 0:
                continue
            
            active_count += 1
            
            if ready_replicas != spec_replicas or available_replicas != spec_replicas:
                logger.debug(f"ReplicaSet {rs_namespace}/{rs_name} in cluster {cluster_id} not ready: {ready_replicas}/{spec_replicas} ready")
                failed_replicasets.append(f"{rs_namespace}/{rs_name}: {ready_replicas}/{spec_replicas} ready, {available_replicas}/{spec_replicas} available")
        
        if failed_replicasets:
            logger.debug(f"Found {len(failed_replicasets)} failed ReplicaSets in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: ReplicaSets not ready:\n    " + "\n    ".join(failed_replicasets[:5])
            if len(failed_replicasets) > 5:
                details += f"\n    (and {len(failed_replicasets) - 5} more)"
            return "FAIL", details
        
        logger.debug(f"All {active_count} active ReplicaSets ready in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {active_count} active ReplicaSets are ready"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check ReplicaSets for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking ReplicaSets: {e}"


def tkc_all_clusters_replicasets_check():
    """Check if all ReplicaSets in all TKC clusters have desired number of replicas available."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_replicasets_check,
        "TKC Clusters ReplicaSets Check",
        "ReplicaSets"
    )

def _tkc_single_cluster_services_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check services for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking services for cluster {cluster_id}")
    
    try:
        services_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get services -A -o json"
        )
        
        if not services_data:
            logger.debug(f"WARNING: Failed to get services data for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get services"
        
        if not services_data.get("items"):
            logger.debug(f"No services found in cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: No services found"
        
        logger.debug(f"Found {len(services_data['items'])} services in cluster {cluster_id}")
        # Check for critical services
        critical_services = ["kubernetes", "kube-dns"]
        existing_services = []
        
        for svc in services_data["items"]:
            svc_name = svc.get("metadata", {}).get("name", "unknown")
            existing_services.append(svc_name)
        
        missing_critical = []
        for critical in critical_services:
            if not any(critical in svc for svc in existing_services):
                logger.debug(f"Critical service {critical} missing in cluster {cluster_id}")
                missing_critical.append(critical)
        
        if missing_critical:
            details = f"Cluster {cluster_id}: Missing critical services:\n    " + "\n    ".join(missing_critical)
            return "WARN", details
        
        logger.debug(f"All critical services present in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {len(services_data['items'])} services present"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check services for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking services: {e}"


def tkc_all_clusters_services_check():
    """Check if critical services exist in all TKC clusters."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_services_check,
        "VKS Clusters Services Check",
        "services"
    )


def _tkc_single_cluster_pvc_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check PVCs (Persistent Volume Claims) for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking PVCs for cluster {cluster_id}")
    
    try:
        pvc_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pvc -A -o json"
        )
        
        if not pvc_data:
            logger.debug(f"No PVCs data found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No PVCs found"
        
        if not pvc_data.get("items"):
            logger.debug(f"No PVCs found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No PVCs found"
        
        logger.debug(f"Found {len(pvc_data['items'])} PVCs in cluster {cluster_id}")
        failed_pvcs = []
        pending_pvcs = []
        
        for pvc in pvc_data["items"]:
            pvc_name = pvc.get("metadata", {}).get("name", "unknown")
            pvc_namespace = pvc.get("metadata", {}).get("namespace", "unknown")
            phase = pvc.get("status", {}).get("phase", "unknown")
            
            if phase == "Pending":
                logger.debug(f"PVC {pvc_namespace}/{pvc_name} in cluster {cluster_id} is pending")
                pending_pvcs.append(f"{pvc_namespace}/{pvc_name}")
            elif phase not in ["Bound", "Available"]:
                logger.debug(f"PVC {pvc_namespace}/{pvc_name} in cluster {cluster_id} has phase {phase}")
                failed_pvcs.append(f"{pvc_namespace}/{pvc_name}: {phase}")
        
        if failed_pvcs:
            logger.debug(f"Found {len(failed_pvcs)} failed PVCs in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: Failed PVCs:\n    " + "\n    ".join(failed_pvcs[:5])
            if len(failed_pvcs) > 5:
                details += f"\n    (and {len(failed_pvcs) - 5} more)"
            return "FAIL", details
        elif pending_pvcs:
            logger.debug(f"Found {len(pending_pvcs)} pending PVCs in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: Pending PVCs:\n    " + "\n    ".join(pending_pvcs[:5])
            if len(pending_pvcs) > 5:
                details += f"\n    (and {len(pending_pvcs) - 5} more)"
            return "WARN", details
        
        logger.debug(f"All PVCs bound in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {len(pvc_data['items'])} PVCs are bound"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check PVCs for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking PVCs: {e}"


def tkc_all_clusters_pvc_check():
    """Check if all PVCs in all TKC clusters are bound."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_pvc_check,
        "TKC Clusters PVCs Check",
        "PVCs"
    )

def _tkc_single_cluster_pkgi_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check package installs (PKGI) for a single TKC cluster.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking package installs for cluster {cluster_id}")
    
    try:
        pkgi_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pkgi -A -o json"
        )
        
        if not pkgi_data:
            # PKGI might not exist in all clusters, treat as pass
            logger.debug(f"No package installs CRD found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No package installs found"
        
        if not pkgi_data.get("items"):
            logger.debug(f"No package installs found in cluster {cluster_id}")
            return "PASS", f"Cluster {cluster_id}: No package installs found"
        
        logger.debug(f"Found {len(pkgi_data['items'])} package installs in cluster {cluster_id}")
        failed_pkgi = []
        reconciling_pkgi = []
        carvel_issue = False  # KB 387022: server unable to handle request / data.packaging.carvel.dev
        
        for pkgi in pkgi_data["items"]:
            pkgi_name = pkgi.get("metadata", {}).get("name", "unknown")
            pkgi_namespace = pkgi.get("metadata", {}).get("namespace", "unknown")
            conditions = pkgi.get("status", {}).get("conditions", [])
            
            # Check for ReconcileSucceeded condition
            reconcile_succeeded = False
            reconciling = False
            failure_message = ""
            
            for condition in conditions:
                condition_type = condition.get("type", "")
                condition_status = condition.get("status", "")
                
                if condition_type == "ReconcileSucceeded":
                    if condition_status == "True":
                        reconcile_succeeded = True
                    else:
                        failure_message = condition.get("message", "")
                elif condition_type == "Reconciling" and condition_status == "True":
                    reconciling = True
            
            if failure_message:
                fm_lower = failure_message.lower()
                if "server is currently unable to handle the request" in fm_lower or "data.packaging.carvel.dev" in fm_lower:
                    carvel_issue = True
            if reconciling and not reconcile_succeeded:
                logger.debug(f"Package install {pkgi_namespace}/{pkgi_name} in cluster {cluster_id} is reconciling")
                reconciling_pkgi.append(f"{pkgi_namespace}/{pkgi_name}")
            elif not reconcile_succeeded:
                logger.debug(f"Package install {pkgi_namespace}/{pkgi_name} in cluster {cluster_id} failed to reconcile")
                status_summary = pkgi.get("status", {}).get("friendlyDescription", "")
                pkgi_info = f"{pkgi_namespace}/{pkgi_name}"
                if status_summary:
                    pkgi_info += f": {status_summary}"
                elif failure_message:
                    pkgi_info += f": {failure_message[:50]}..."
                else:
                    pkgi_info += ": not reconciled"
                failed_pkgi.append(pkgi_info)
        
        if failed_pkgi:
            logger.debug(f"Found {len(failed_pkgi)} failed package installs in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: Package installs failed:\n    " + "\n    ".join(failed_pkgi[:5])
            if len(failed_pkgi) > 5:
                details += f"\n    (and {len(failed_pkgi) - 5} more)"
            if carvel_issue:
                details += "\nRefer to KB https://knowledge.broadcom.com/external/article/387022"
            return "FAIL", details
        elif reconciling_pkgi:
            logger.debug(f"Found {len(reconciling_pkgi)} reconciling package installs in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: Package installs reconciling:\n    " + "\n    ".join(reconciling_pkgi[:5])
            if len(reconciling_pkgi) > 5:
                details += f"\n    (and {len(reconciling_pkgi) - 5} more)"
            return "WARN", details
        
        logger.debug(f"All package installs reconcile succeeded in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {len(pkgi_data['items'])} package installs reconcile succeeded"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check package installs for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking package installs: {e}"


def tkc_all_clusters_pkgi_check():
    """Check if all package installs in all TKC clusters are reconcile succeeded."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_pkgi_check,
        "TKC Clusters Package Installs Check",
        "package installs"
    )

def _is_pdb_misconfigured(pdb):
    """
    Check if a PDB is misconfigured (would block cluster lifecycle operations).
    
    A PDB is considered blocking (FAIL) if ANY of these conditions are true:
    - spec.maxUnavailable == 0 (integer)
    - spec.maxUnavailable == "0%" (percentage)
    - spec.minAvailable == "100%" (percentage)
    - spec.minAvailable (as int) >= status.currentHealthy (no headroom)
    
    A PDB is considered orphaned (WARN) if:
    - status.currentHealthy == 0 AND status.expectedPods == 0
    
    Returns tuple: (is_blocking, is_orphaned, reason)
    """
    spec = pdb.get("spec", {})
    status = pdb.get("status", {})
    
    max_unavailable = spec.get("maxUnavailable")
    min_available = spec.get("minAvailable")
    current_healthy = status.get("currentHealthy", 0)
    expected_pods = status.get("expectedPods", 0)
    
    # Check for orphaned PDB (no matching pods)
    if current_healthy == 0 and expected_pods == 0:
        return False, True, "No matching pods (orphaned PDB)"
    
    # Check maxUnavailable == 0
    if max_unavailable is not None:
        if max_unavailable == 0:
            return True, False, "maxUnavailable=0 blocks all voluntary disruptions"
        if isinstance(max_unavailable, str):
            if max_unavailable == "0" or max_unavailable == "0%":
                return True, False, f"maxUnavailable={max_unavailable} blocks all voluntary disruptions"
    
    # Check minAvailable == 100%
    if min_available is not None:
        if isinstance(min_available, str) and min_available == "100%":
            return True, False, "minAvailable=100% blocks all voluntary disruptions"
        
        # Check if minAvailable (as int) >= currentHealthy
        if isinstance(min_available, int):
            if current_healthy > 0 and min_available >= current_healthy:
                return True, False, f"minAvailable ({min_available}) >= currentHealthy ({current_healthy})"
        elif isinstance(min_available, str) and min_available.isdigit():
            min_avail_int = int(min_available)
            if current_healthy > 0 and min_avail_int >= current_healthy:
                return True, False, f"minAvailable ({min_avail_int}) >= currentHealthy ({current_healthy})"
    
    return False, False, None


def _tkc_single_cluster_pdb_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for misconfigured PDBs in a single TKC cluster.
    
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking PDBs for cluster {cluster_id}")
    
    try:
        # Get all PDBs in the cluster
        pdb_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pdb -A -o json"
        )
        
        if pdb_data is None:
            logger.debug(f"WARNING: Failed to get PDBs for cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: Failed to get PDBs"
        
        pdbs = pdb_data.get("items", [])
        
        if not pdbs:
            return "PASS", f"Cluster {cluster_id}: No PDBs found"
        
        blocking_pdbs = []
        orphaned_pdbs = []
        
        for pdb in pdbs:
            pdb_name = pdb.get("metadata", {}).get("name", "unknown")
            pdb_namespace = pdb.get("metadata", {}).get("namespace", "unknown")
            pdb_id = f"{pdb_namespace}/{pdb_name}"
            
            is_blocking, is_orphaned, reason = _is_pdb_misconfigured(pdb)
            
            if is_blocking:
                blocking_pdbs.append(f"{pdb_id}: {reason}")
                logger.debug(f"WARNING: Cluster {cluster_id}: Blocking PDB found - {pdb_id}: {reason}")
            elif is_orphaned:
                orphaned_pdbs.append(f"{pdb_id}: {reason}")
                logger.debug(f"Cluster {cluster_id}: Orphaned PDB found - {pdb_id}")
        
        # Determine result
        if blocking_pdbs:
            details = f"Cluster {cluster_id}: Blocking PDBs that may prevent cluster lifecycle operations:\n    " + "\n    ".join(blocking_pdbs[:5])
            if len(blocking_pdbs) > 5:
                details += f"\n    (and {len(blocking_pdbs) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/345904 for PDB blocking cluster upgrade."
            return "FAIL", details
        
        if orphaned_pdbs:
            details = f"Cluster {cluster_id}: Orphaned PDBs (no matching pods):\n    " + "\n    ".join(orphaned_pdbs[:5])
            if len(orphaned_pdbs) > 5:
                details += f"\n    (and {len(orphaned_pdbs) - 5} more)"
            return "WARN", details
        
        return "PASS", f"Cluster {cluster_id}: {len(pdbs)} PDBs checked, none misconfigured"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check PDBs for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking PDBs: {e}\nRefer to KB https://knowledge.broadcom.com/external/article/345904 for PDB blocking cluster upgrade."


def tkc_all_clusters_pdb_check():
    """Check for misconfigured PDBs across all TKC clusters."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_pdb_check,
        "TKC PodDisruptionBudget Check",
        "PDBs"
    )


def _tkc_single_cluster_vmware_system_user_daemonset_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for cluster-admin DaemonSet (vmware-system-user password expiry workaround) in workload cluster (KB 319375).
    Only warns when SSH as vmware-system-user fails due to password expiry; we do not have that signal here,
    so we never warn for a missing DaemonSet. We report PASS with informational details.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug("Checking cluster-admin DaemonSet for cluster %s", cluster_id)
    try:
        ds_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get daemonset cluster-admin -n default -o json 2>/dev/null || kubectl get daemonset -A -o json"
        )
        if ds_data is None:
            return "PASS", (
                f"Cluster {cluster_id}: Could not get DaemonSet list. "
                "If SSH to guest nodes as vmware-system-user fails due to password expiry, refer to KB https://knowledge.broadcom.com/external/article/319375"
            )
        if isinstance(ds_data, dict) and "items" in ds_data:
            cluster_admin = next((i for i in ds_data["items"] if i.get("metadata", {}).get("name") == "cluster-admin"), None)
        else:
            cluster_admin = ds_data if isinstance(ds_data, dict) and ds_data.get("metadata", {}).get("name") == "cluster-admin" else None
        if not cluster_admin:
            return "PASS", (
                f"Cluster {cluster_id}: cluster-admin DaemonSet not present. "
                "If SSH as vmware-system-user fails due to password expiry, refer to KB https://knowledge.broadcom.com/external/article/319375"
            )
        status = cluster_admin.get("status", {})
        desired = status.get("desiredNumberScheduled", 0)
        ready = status.get("numberReady", 0)
        if desired and ready != desired:
            return "PASS", (
                f"Cluster {cluster_id}: cluster-admin DaemonSet {ready}/{desired} ready. "
                "If SSH as vmware-system-user fails due to password expiry, refer to KB https://knowledge.broadcom.com/external/article/319375"
            )
        return "PASS", f"Cluster {cluster_id}: cluster-admin DaemonSet present and {ready}/{desired} ready (vmware-system-user expiry workaround in place)"
    except Exception as e:
        logger.debug("ERROR: Failed to check cluster-admin DaemonSet for cluster %s: %s", cluster_id, e)
        return "PASS", f"Cluster {cluster_id}: Could not verify cluster-admin DaemonSet: {e}. Refer to KB 319375 if SSH as vmware-system-user fails."


def tkc_all_clusters_vmware_system_user_daemonset_check():
    """Check for cluster-admin DaemonSet (vmware-system-user expiry workaround) across all TKC clusters (KB 319375)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_vmware_system_user_daemonset_check,
        "TKC vmware-system-user DaemonSet Check",
        "cluster-admin DaemonSet"
    )


def _tkc_single_cluster_antrea_health_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check antrea pods and antrea-pre-upgrade job health (KB 384095).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking antrea health for cluster {cluster_id}")
    try:
        pods_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pods -A -o json"
        )
        if pods_data is None:
            return "WARN", f"Cluster {cluster_id}: Could not get pods"
        items = pods_data.get("items", []) if isinstance(pods_data, dict) else []
        items = [p for p in items if "antrea" in (p.get("metadata", {}).get("name") or "").lower()]
        antrea_unhealthy = []
        for pod in items:
            name = pod.get("metadata", {}).get("name", "")
            if "antrea" not in name.lower():
                continue
            phase = pod.get("status", {}).get("phase", "")
            ns = pod.get("metadata", {}).get("namespace", "")
            cstatuses = pod.get("status", {}).get("containerStatuses", [])
            ready = sum(1 for c in cstatuses if c.get("ready")) if cstatuses else 0
            total = len(cstatuses)
            for c in cstatuses:
                state = c.get("state", {})
                if state.get("waiting", {}).get("reason") in ("CrashLoopBackOff", "ImagePullBackOff", "ErrImagePull"):
                    antrea_unhealthy.append(f"{ns}/{name}: {state['waiting'].get('reason', '')} (ready={ready}/{total})")
                    break
            else:
                if phase != "Running" or (total and ready != total):
                    antrea_unhealthy.append(f"{ns}/{name}: phase={phase}, ready={ready}/{total}")
        job_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get job antrea-pre-upgrade-job -n vmware-system-antrea -o json 2>/dev/null"
        )
        if job_data and isinstance(job_data, dict):
            status = job_data.get("status", {})
            if status.get("failed", 0) or (status.get("succeeded", 0) == 0 and status.get("active", 0) == 0 and status.get("conditions")):
                for c in status.get("conditions", []):
                    if c.get("type") == "Failed" and c.get("status") == "True":
                        antrea_unhealthy.append(f"vmware-system-antrea/antrea-pre-upgrade-job: Failed")
                        break
        # KB 386093: antrea-agent DaemonSet Up to Date < Desired
        ds_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get daemonset antrea-agent -n kube-system -o json 2>/dev/null"
        )
        if ds_data and isinstance(ds_data, dict):
            status = ds_data.get("status", {})
            desired = status.get("desiredNumberScheduled", 0)
            updated = status.get("updatedNumberScheduled", desired)
            if desired and updated < desired:
                antrea_unhealthy.append(f"antrea-agent DaemonSet: updated={updated}/{desired} (not all up to date)")
        if antrea_unhealthy:
            details = f"Cluster {cluster_id}: Antrea health issues:\n    " + "\n    ".join(antrea_unhealthy[:5])
            if len(antrea_unhealthy) > 5:
                details += f"\n    (and {len(antrea_unhealthy) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/384095"
            if any("not all up to date" in s for s in antrea_unhealthy):
                details += "\nRefer to KB https://knowledge.broadcom.com/external/article/386093"
            return "FAIL", details
        return "PASS", f"Cluster {cluster_id}: Antrea pods and pre-upgrade job OK"
    except Exception as e:
        logger.debug(f"ERROR: Failed to check antrea for cluster {cluster_id}: {e}")
        return "WARN", f"Cluster {cluster_id}: Error checking antrea: {e}"


def tkc_all_clusters_antrea_health_check():
    """Check antrea health across all TKC clusters (KB 384095)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_antrea_health_check,
        "TKC Antrea Health Check",
        "antrea"
    )


def _tkc_single_cluster_pause_image_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for pods with events indicating missing pause/sandbox image (KB 379856).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking pause image issues for cluster {cluster_id}")
    try:
        pods_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pods -A -o json"
        )
        if pods_data is None:
            return "WARN", f"Cluster {cluster_id}: Could not get pods"
        items = pods_data.get("items", [])
        pause_issues = []
        keywords = ("pause", "sandbox", "localhost:5000", "connection refused", "not found")
        for pod in items:
            name = pod.get("metadata", {}).get("name", "")
            ns = pod.get("metadata", {}).get("namespace", "")
            for c in pod.get("status", {}).get("containerStatuses", []) or []:
                state = c.get("state", {}) or {}
                waiting = state.get("waiting", {}) or {}
                msg = (waiting.get("message") or waiting.get("reason") or "").lower()
                if any(k in msg for k in keywords):
                    pause_issues.append(f"{ns}/{name}: {msg[:80]}")
                    break
            else:
                for ev in pod.get("status", {}).get("events", []) or []:
                    msg = (ev.get("message") or "").lower()
                    if any(k in msg for k in keywords):
                        pause_issues.append(f"{ns}/{name}: {msg[:80]}")
                        break
        if pause_issues:
            details = f"Cluster {cluster_id}: Pods with possible missing pause image:\n    " + "\n    ".join(pause_issues[:5])
            if len(pause_issues) > 5:
                details += f"\n    (and {len(pause_issues) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/379856"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: No pause image issues detected"
    except Exception as e:
        logger.debug(f"ERROR: Failed to check pause image for cluster {cluster_id}: {e}")
        return "WARN", f"Cluster {cluster_id}: Error checking pause image: {e}"


def tkc_all_clusters_pause_image_check():
    """Check for missing vmware pause image across all TKC clusters (KB 379856)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_pause_image_check,
        "TKC Pause Image Check",
        "pods"
    )


# Known third-party webhook names that can block CNI (KB 387563)
THIRD_PARTY_WEBHOOK_PREFIXES = ("gatekeeper", "kyverno", "k8tz", "rancher", "dynatrace", "linkerd", "check-ignore-label")
SYSTEM_WEBHOOK_PREFIXES = ("crdvalidator.antrea", "crdmutator.antrea", "vmware-system-tkg", "capi-", "clusterbootstrap")


def _tkc_single_cluster_third_party_webhook_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for third-party webhooks that may block CNI; WARN if present and nodes/CNI unhealthy (KB 387563).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking third-party webhooks for cluster {cluster_id}")
    try:
        vwh = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get validatingwebhookconfiguration -o json 2>/dev/null"
        )
        mwh = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get mutatingwebhookconfiguration -o json 2>/dev/null"
        )
        def is_third_party(name):
            if not name:
                return False
            n = name.lower()
            if any(n.startswith(s) for s in SYSTEM_WEBHOOK_PREFIXES):
                return False
            return any(n.startswith(p) or p in n for p in THIRD_PARTY_WEBHOOK_PREFIXES)
        third_party = []
        for data in (vwh, mwh):
            if not data or not isinstance(data, dict):
                continue
            for item in data.get("items", []):
                nm = item.get("metadata", {}).get("name", "")
                if is_third_party(nm):
                    third_party.append(nm)
        if not third_party:
            return "PASS", f"Cluster {cluster_id}: No known third-party webhooks"
        nodes_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get nodes -o json 2>/dev/null"
        )
        not_ready = []
        if nodes_data and isinstance(nodes_data, dict):
            for node in nodes_data.get("items", []):
                for c in node.get("status", {}).get("conditions", []):
                    if c.get("type") == "Ready" and c.get("status") != "True":
                        not_ready.append(node.get("metadata", {}).get("name", "?"))
                        break
        cni_pods = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pods -n kube-system -o json 2>/dev/null"
        )
        cni_unhealthy = False
        if cni_pods and isinstance(cni_pods, dict):
            for pod in cni_pods.get("items", []):
                name = pod.get("metadata", {}).get("name", "")
                if "antrea" in name.lower() or "calico" in name.lower():
                    phase = pod.get("status", {}).get("phase", "")
                    if phase != "Running":
                        cni_unhealthy = True
                        break
        if third_party and (not_ready or cni_unhealthy):
            details = f"Cluster {cluster_id}: Third-party webhooks present: {', '.join(third_party[:5])}. "
            if not_ready or cni_unhealthy:
                details += "Nodes or CNI may be affected. "
            details += "Refer to KB https://knowledge.broadcom.com/external/article/387563"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: Third-party webhooks present but nodes/CNI OK"
    except Exception as e:
        logger.debug(f"ERROR: Failed to check webhooks for cluster {cluster_id}: {e}")
        return "WARN", f"Cluster {cluster_id}: Error checking webhooks: {e}"


def tkc_all_clusters_third_party_webhook_check():
    """Check for third-party webhooks that may block CNI across all TKC clusters (KB 387563)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_third_party_webhook_check,
        "TKC Third-Party Webhook Check",
        "webhooks"
    )


def _tkc_single_cluster_upgrade_stuck_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for signs of upgrade stuck: ImagePullBackOff pods, machines in Provisioning (KB 378212).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking upgrade stuck for cluster {cluster_id}")
    try:
        pods_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pods -A -o json"
        )
        if pods_data is None:
            return "PASS", f"Cluster {cluster_id}: Could not get pods (skipped)"
        items = pods_data.get("items", [])
        image_pull_issues = []
        for pod in items:
            ns = pod.get("metadata", {}).get("namespace", "")
            name = pod.get("metadata", {}).get("name", "")
            for c in pod.get("status", {}).get("containerStatuses", []):
                state = c.get("state", {})
                reason = state.get("waiting", {}).get("reason", "") or state.get("waiting", {}).get("message", "")
                if "ImagePullBackOff" in reason or "ErrImagePull" in reason or "not found" in (state.get("waiting", {}).get("message") or "").lower():
                    image_pull_issues.append(f"{ns}/{name}: {reason}")
                    break
        if image_pull_issues:
            details = f"Cluster {cluster_id}: Pods with image pull issues (upgrade may be stuck):\n    " + "\n    ".join(image_pull_issues[:5])
            if len(image_pull_issues) > 5:
                details += f"\n    (and {len(image_pull_issues) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/378212"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: No upgrade-stuck indicators"
    except Exception as e:
        logger.debug(f"ERROR: Failed to check upgrade stuck for cluster {cluster_id}: {e}")
        return "PASS", f"Cluster {cluster_id}: Error (skipped): {e}"


def tkc_all_clusters_upgrade_stuck_check():
    """Check for upgrade stuck (ImagePullBackOff, missing images) across all TKC clusters (KB 378212)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_upgrade_stuck_check,
        "TKC Upgrade Stuck Check",
        "pods"
    )


def _tkc_single_cluster_volume_attachment_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for VolumeAttachments with attach errors (InvalidState/CBT mismatch) (KB 323021).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug("Checking volume attachments for cluster %s", cluster_id)
    try:
        va_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get volumeattachment -o json 2>/dev/null"
        )
        if va_data is None:
            return "PASS", f"Cluster {cluster_id}: Could not get volumeattachment (skipped)"
        items = va_data.get("items", []) if isinstance(va_data, dict) else []
        attach_errors = []
        keywords = ("invalidstate", "operation is not allowed", "current state", "cbt")
        for va in items:
            name = va.get("metadata", {}).get("name", "")
            status = va.get("status", {})
            if status.get("attached") is True:
                continue
            err = status.get("attachError", {}) or {}
            msg = (err.get("message") or err.get("reason") or "").lower()
            if any(k in msg for k in keywords):
                attach_errors.append(f"{name}: {msg[:80]}")
        if attach_errors:
            details = f"Cluster {cluster_id}: VolumeAttachment attach errors (CBT/InvalidState):\n    " + "\n    ".join(attach_errors[:5])
            if len(attach_errors) > 5:
                details += f"\n    (and {len(attach_errors) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/323021"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: No volume attachment errors detected"
    except Exception as e:
        logger.debug("ERROR: Failed to check volume attachments for cluster %s: %s", cluster_id, e)
        return "PASS", f"Cluster {cluster_id}: Error (skipped): {e}"


def tkc_all_clusters_volume_attachment_check():
    """Check for VolumeAttachment attach errors (CBT/InvalidState) across all TKC clusters (KB 323021)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_volume_attachment_check,
        "TKC Volume Attachment Check",
        "volumeattachment"
    )


def _tkc_single_cluster_control_plane_roles_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check that control plane nodes have control-plane role label (KB 386786).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug("Checking control plane roles for cluster %s", cluster_id)
    try:
        nodes_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get nodes -o json 2>/dev/null"
        )
        if nodes_data is None:
            return "PASS", f"Cluster {cluster_id}: Could not get nodes (skipped)"
        items = nodes_data.get("items", []) if isinstance(nodes_data, dict) else []
        missing_roles = []
        for node in items:
            name = node.get("metadata", {}).get("name", "")
            labels = node.get("metadata", {}).get("labels") or {}
            taints = node.get("spec", {}).get("taints") or []
            # Node is control plane if it has control-plane or master taint/label
            has_cp_taint = any(t.get("key") == "node-role.kubernetes.io/control-plane" for t in taints)
            has_master_taint = any(t.get("key") == "node-role.kubernetes.io/master" for t in taints)
            has_cp_label = "node-role.kubernetes.io/control-plane" in labels
            has_master_label = "node-role.kubernetes.io/master" in labels
            if has_cp_taint or has_master_taint or has_cp_label or has_master_label:
                if not has_cp_label and not has_master_label:
                    missing_roles.append(name)
        if missing_roles:
            details = f"Cluster {cluster_id}: Control plane node(s) missing role label: " + ", ".join(missing_roles[:5])
            if len(missing_roles) > 5:
                details += f" (and {len(missing_roles) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/386786"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: Control plane roles OK"
    except Exception as e:
        logger.debug("ERROR: Failed to check control plane roles for cluster %s: %s", cluster_id, e)
        return "PASS", f"Cluster {cluster_id}: Error (skipped): {e}"


def tkc_all_clusters_control_plane_roles_check():
    """Check control plane roles across all TKC clusters (KB 386786)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_control_plane_roles_check,
        "TKC Control Plane Roles Check",
        "nodes"
    )


def _tkc_single_cluster_pv_released_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for PVs stuck in Released (VolumeFailedDelete / CNS backlog) (KB 411248).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug("Checking PV Released for cluster %s", cluster_id)
    try:
        pv_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pv -o json 2>/dev/null"
        )
        if pv_data is None:
            return "PASS", f"Cluster {cluster_id}: Could not get PVs (skipped)"
        items = pv_data.get("items", []) if isinstance(pv_data, dict) else []
        released = []
        for pv in items:
            name = pv.get("metadata", {}).get("name", "")
            phase = pv.get("status", {}).get("phase", "")
            if phase == "Released":
                released.append(name)
        if released:
            details = f"Cluster {cluster_id}: PVs stuck in Released: " + ", ".join(released[:5])
            if len(released) > 5:
                details += f" (and {len(released) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/411248"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: No PVs in Released"
    except Exception as e:
        logger.debug("ERROR: Failed to check PV Released for cluster %s: %s", cluster_id, e)
        return "PASS", f"Cluster {cluster_id}: Error (skipped): {e}"


def tkc_all_clusters_pv_released_check():
    """Check for PVs stuck in Released across all TKC clusters (KB 411248)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_pv_released_check,
        "TKC PV Released Check",
        "pv"
    )


def _tkc_single_cluster_volume_mount_swap_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for nodes with NodeDiskPressure (volume mount disk swap) (KB 389012).
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug("Checking volume mount swap for cluster %s", cluster_id)
    try:
        nodes_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get nodes -o json 2>/dev/null"
        )
        if nodes_data is None:
            return "PASS", f"Cluster {cluster_id}: Could not get nodes (skipped)"
        items = nodes_data.get("items", []) if isinstance(nodes_data, dict) else []
        disk_pressure = []
        for node in items:
            name = node.get("metadata", {}).get("name", "")
            conditions = node.get("status", {}).get("conditions") or []
            for c in conditions:
                if c.get("type") == "DiskPressure" and c.get("status") == "True":
                    disk_pressure.append(name)
                    break
        if disk_pressure:
            details = f"Cluster {cluster_id}: Nodes with DiskPressure (possible volume mount swap): " + ", ".join(disk_pressure[:5])
            if len(disk_pressure) > 5:
                details += f" (and {len(disk_pressure) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/389012 and https://knowledge.broadcom.com/external/article/319405"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: No NodeDiskPressure"
    except Exception as e:
        logger.debug("ERROR: Failed to check volume mount swap for cluster %s: %s", cluster_id, e)
        return "PASS", f"Cluster {cluster_id}: Error (skipped): {e}"


def tkc_all_clusters_volume_mount_swap_check():
    """Check for NodeDiskPressure (volume mount disk swap) across all TKC clusters (KB 389012)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_volume_mount_swap_check,
        "TKC Volume Mount Swap Check",
        "nodes"
    )


def _tkc_single_cluster_nfs_mount_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check for pods with NFS/vSAN file share FailedMount (KB 399782).
    Message contains mount.nfs4, 'No such file or directory', exit status 32.
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug("Checking NFS mount for cluster %s", cluster_id)
    try:
        pods_data = run_kubectl_on_tkc(
            tkc_manager, cluster_name, namespace, ssh_key_path,
            "kubectl get pods -A -o json 2>/dev/null"
        )
        if pods_data is None:
            return "PASS", f"Cluster {cluster_id}: Could not get pods (skipped)"
        items = pods_data.get("items", []) if isinstance(pods_data, dict) else []
        keywords = ("mount.nfs4", "no such file or directory", "exit status 32", "failedmount")
        nfs_issues = []
        for pod in items:
            name = pod.get("metadata", {}).get("name", "")
            ns = pod.get("metadata", {}).get("namespace", "")
            for cs in pod.get("status", {}).get("containerStatuses") or []:
                state = cs.get("state", {}) or {}
                waiting = state.get("waiting", {}) or {}
                msg = (waiting.get("message") or waiting.get("reason") or "").lower()
                if any(k in msg for k in keywords):
                    nfs_issues.append(f"{ns}/{name}: {msg[:60]}")
                    break
        if nfs_issues:
            details = f"Cluster {cluster_id}: Pods with NFS/vSAN file share mount issues:\n    " + "\n    ".join(nfs_issues[:5])
            if len(nfs_issues) > 5:
                details += f"\n    (and {len(nfs_issues) - 5} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/399782"
            return "WARN", details
        return "PASS", f"Cluster {cluster_id}: No NFS mount issues detected"
    except Exception as e:
        logger.debug("ERROR: Failed to check NFS mount for cluster %s: %s", cluster_id, e)
        return "PASS", f"Cluster {cluster_id}: Error (skipped): {e}"


def tkc_all_clusters_nfs_mount_check():
    """Check for NFS/vSAN file share FailedMount across all TKC clusters (KB 399782)."""
    return run_check_on_all_clusters(
        _tkc_single_cluster_nfs_mount_check,
        "TKC NFS Mount Check",
        "pods"
    )


def _get_kcp_for_cluster(tkc_manager, cluster_name, namespace):
    """
    Get KubeadmControlPlane for a cluster from supervisor.
    Returns KCP dict or None. Uses label cluster.x-k8s.io/cluster-name.
    """
    command = f"kubectl get kcp -n {namespace} -l cluster.x-k8s.io/cluster-name={cluster_name} -o json 2>/dev/null"
    output = run_kubectl_on_supervisor(tkc_manager, command)
    if not output:
        return None
    try:
        data = json.loads(output)
        items = (data or {}).get("items") or []
        return items[0] if items else None
    except (json.JSONDecodeError, TypeError, IndexError):
        return None


def tkc_all_clusters_pre_upgrade_133_cloud_provider_check():
    """
    For clusters with version < 1.33: warn if KCP has cloud-provider in apiServer extraArgs.
    When upgrading to 1.33, this flag causes kube-apiserver to fail (KB 410481, 414483).
    """
    title = "VKS Clusters Pre-Upgrade 1.33 Cloud-Provider Flag Check (KB 410481)"
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    try:
        clusters = tkc_manager.get_tkc_clusters(force_refresh=True)
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        affected = []
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            phase = cluster.get("status", {}).get("phase", "")
            if phase != "Provisioned":
                continue
            version = parse_cluster_version(cluster)
            if version is None or version >= (1, 33):
                continue
            kcp = _get_kcp_for_cluster(tkc_manager, name, namespace)
            if not kcp:
                continue
            extra_args = (kcp.get("spec") or {}).get("kubeadmConfigSpec") or {}
            extra_args = (extra_args.get("clusterConfiguration") or {}).get("apiServer") or {}
            extra_args = extra_args.get("extraArgs") or {}
            if "cloud-provider" in extra_args:
                affected.append(f"{namespace}/{name}")
        if affected:
            details = "When upgrading to 1.33, remove cloud-provider from KCP apiServer extraArgs for:\n    " + "\n    ".join(affected[:10])
            if len(affected) > 10:
                details += f"\n    (and {len(affected) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/410481"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/414483"
            return {"title": title, "result": "WARN", "details": details}
        return {"title": title, "result": "PASS", "details": "No clusters < 1.33 with cloud-provider flag, or no clusters < 1.33."}
    except Exception as e:
        logger.debug("ERROR: Failed pre-upgrade 1.33 cloud-provider check: %s", e)
        return {"title": title, "result": "WARN", "details": f"Could not complete check: {e}. Refer to KB 410481/414483 when upgrading to 1.33."}


def tkc_all_clusters_pre_upgrade_133_legacy_managed_fields_check():
    """
    For clusters with version < 1.33: warn if KCP has legacy managedFields that block upgrade.
    Before upgrading to 1.33, run the script per KB 414483 to remove them.
    """
    title = "VKS Clusters Pre-Upgrade 1.33 Legacy KCP Managed Fields Check (KB 414483)"
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    try:
        clusters = tkc_manager.get_tkc_clusters(force_refresh=True)
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        affected = []
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            phase = cluster.get("status", {}).get("phase", "")
            if phase != "Provisioned":
                continue
            version = parse_cluster_version(cluster)
            if version is None or version >= (1, 33):
                continue
            kcp = _get_kcp_for_cluster(tkc_manager, name, namespace)
            if not kcp:
                continue
            managed_fields = (kcp.get("metadata") or {}).get("managedFields") or []
            for entry in managed_fields:
                if not isinstance(entry, dict):
                    continue
                api_version = entry.get("apiVersion") or ""
                manager = entry.get("manager") or ""
                operation = entry.get("operation") or ""
                subresource = entry.get("subresource") or ""
                if (
                    "controlplane.cluster.x-k8s.io/v1beta1" in api_version
                    and manager in ("manager", "before-first-apply")
                    and operation == "Update"
                    and subresource == ""
                ):
                    affected.append(f"{namespace}/{name}")
                    break
        if affected:
            details = "Before upgrading to 1.33, run the script per KB 414483 to remove legacy managed fields on KCP for:\n    " + "\n    ".join(affected[:10])
            if len(affected) > 10:
                details += f"\n    (and {len(affected) - 10} more)"
            details += "\nRefer to KB https://knowledge.broadcom.com/external/article/414483"
            return {"title": title, "result": "WARN", "details": details}
        return {"title": title, "result": "PASS", "details": "No clusters < 1.33 with legacy KCP managed fields, or no clusters < 1.33."}
    except Exception as e:
        logger.debug("ERROR: Failed pre-upgrade 1.33 legacy managed fields check: %s", e)
        return {"title": title, "result": "WARN", "details": f"Could not complete check: {e}. Refer to KB 414483 when upgrading to 1.33."}


def tkc_resource_all_checks():
    """Run all TKC Kubernetes resource checks and return a list of result dicts."""
    results = []
    try:
        results.append(tkc_all_clusters_status_check())
        results.append(tkc_all_clusters_nodes_check())
        results.append(tkc_all_clusters_pods_check())
        results.append(tkc_all_clusters_deployments_check())
        results.append(tkc_all_clusters_daemonsets_check())
        results.append(tkc_all_clusters_statefulsets_check())
        results.append(tkc_all_clusters_replicasets_check())
        results.append(tkc_all_clusters_services_check())
        results.append(tkc_all_clusters_pvc_check())
        results.append(tkc_all_clusters_pkgi_check())
        results.append(tkc_all_clusters_pdb_check())
        results.append(tkc_all_clusters_vmware_system_user_daemonset_check())
        results.append(tkc_all_clusters_antrea_health_check())
        results.append(tkc_all_clusters_pause_image_check())
        results.append(tkc_all_clusters_third_party_webhook_check())
        results.append(tkc_all_clusters_upgrade_stuck_check())
        results.append(tkc_all_clusters_volume_attachment_check())
        results.append(tkc_all_clusters_control_plane_roles_check())
        results.append(tkc_all_clusters_pv_released_check())
        results.append(tkc_all_clusters_volume_mount_swap_check())
        results.append(tkc_all_clusters_nfs_mount_check())
        results.append(tkc_all_clusters_pre_upgrade_133_cloud_provider_check())
        results.append(tkc_all_clusters_pre_upgrade_133_legacy_managed_fields_check())
    except Exception as e:
        logger.debug(f"ERROR: Failed to run TKC resource checks: {e}")
        results.append({
            "title": "TKC Resource Checks",
            "result": "FAIL",
            "details": f"Failed to run TKC resource checks: {e}"
        })
    return results
