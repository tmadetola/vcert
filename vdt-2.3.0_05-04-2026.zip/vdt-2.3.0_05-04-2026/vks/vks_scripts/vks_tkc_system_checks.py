import logging
import json
import os
import configparser
from vks.vks_lib.vks_tkc_utils import (
    get_tkc_manager,
    get_ssh_key_for_cluster,
    parse_kubeadm_cert_output,
)

logger = logging.getLogger(__name__)

def _tkc_single_cluster_port_connectivity_check(tkc_manager, cluster_name, namespace, ssh_key_path, port, port_desc):
    """
    Check inter-node connectivity between control plane nodes for a single TKC cluster on a specific port.
    
    Args:
        tkc_manager: TKCManager instance
        cluster_name: Name of the cluster
        namespace: Namespace of the cluster
        ssh_key_path: Path to SSH key
        port: Port number to check
        port_desc: Description of the port (e.g., "Kubernetes API server")
    
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking control plane connectivity on port {port} for cluster {cluster_id}")
    
    try:
        control_plane_nodes = tkc_manager.find_all_control_plane_ips(cluster_name, namespace)
        
        if not control_plane_nodes:
            logger.debug(f"WARNING: No control plane nodes found for cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: No control plane nodes found"
        
        if len(control_plane_nodes) == 1:
            logger.debug(f"Cluster {cluster_id} has only 1 control plane node, skipping connectivity check")
            return "PASS", f"Cluster {cluster_id}: Single control plane node (connectivity check skipped)"
        
        logger.debug(f"INFO: Checking port {port} connectivity between {len(control_plane_nodes)} control plane nodes in cluster {cluster_id}")
        
        failed_connections = []
        successful_connections = 0
        
        for source_node in control_plane_nodes:
            source_name = source_node["name"]
            source_ip = source_node["ip"]
            
            for target_node in control_plane_nodes:
                target_name = target_node["name"]
                target_ip = target_node["ip"]
                
                if source_ip == target_ip:
                    continue
                
                nc_command = f"nc -zv -w 5 {target_ip} {port} 2>&1"
                
                logger.debug(f"Testing {source_name} -> {target_name}:{port}")
                
                result = tkc_manager.ssh_to_tkc_node(source_ip, ssh_key_path, nc_command)
                
                if result and ("open" in result.lower() or "succeeded" in result.lower()):
                    successful_connections += 1
                    logger.debug(f"Connection {source_name} -> {target_name}:{port} succeeded")
                else:
                    failed_connections.append(
                        f"{source_name} ({source_ip}) -> {target_name} ({target_ip})"
                    )
                    logger.debug(f"WARNING: Connection {source_name} -> {target_name}:{port} failed: {result}")
        
        if failed_connections:
            logger.debug(f"WARNING: Found {len(failed_connections)} failed connections on port {port} in cluster {cluster_id}")
            details = f"Cluster {cluster_id}: Failed connections on port {port}:\n    " + "\n    ".join(failed_connections[:10])
            if len(failed_connections) > 10:
                details += f"\n    (and {len(failed_connections) - 10} more)"
            return "FAIL", details
        
        total_expected = len(control_plane_nodes) * (len(control_plane_nodes) - 1)
        logger.debug(f"INFO: All {successful_connections}/{total_expected} port {port} connections successful in cluster {cluster_id}")
        return "PASS", f"Cluster {cluster_id}: All {successful_connections} connections successful ({len(control_plane_nodes)} nodes)"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check port {port} connectivity for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking port {port} connectivity: {e}"

def _tkc_all_clusters_port_connectivity_check(port, port_desc):
    """
    Check inter-node connectivity between control plane nodes in all TKC clusters on a specific port.
    
    Args:
        port: Port number to check
        port_desc: Description of the port
    
    Returns a result dict with per-cluster connectivity status.
    """
    title = f"TKC Control Plane Port {port} Check ({port_desc})"
    result = "PASS"
    details_list = []
    
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        clusters = tkc_manager.get_tkc_clusters()
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        
        failed_count = 0
        checked_count = 0
        
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            phase = cluster.get("status", {}).get("phase", "unknown")
            
            if phase != "Provisioned":
                details_list.append(f"Cluster {namespace}/{name}: Skipped (phase={phase})")
                continue
            
            ssh_key_path = get_ssh_key_for_cluster(tkc_manager, name, namespace)
            if not ssh_key_path:
                details_list.append(f"Cluster {namespace}/{name}: Failed to get SSH key")
                result = "FAIL"
                failed_count += 1
                continue
            
            check_result, check_details = _tkc_single_cluster_port_connectivity_check(
                tkc_manager, name, namespace, ssh_key_path, port, port_desc
            )
            
            details_list.append(check_details)
            checked_count += 1
            
            if check_result == "FAIL":
                result = "FAIL"
                failed_count += 1
            elif check_result == "WARN" and result != "FAIL":
                result = "WARN"
        
        if not details_list:
            details = "No TKC clusters to check"
        else:
            details = "\n".join(details_list[:10])
            if len(details_list) > 10:
                details += f"\n(and {len(details_list) - 10} more clusters)"
        
        logger.debug(f"INFO: TKC control plane port {port} check completed: {result} ({failed_count}/{checked_count} failed)")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check TKC cluster control plane port {port} connectivity: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check TKC cluster control plane port {port} connectivity: {e}"}

def tkc_control_plane_port_6443_check():
    """Check inter-node connectivity on port 6443 (Kubernetes API server) between control plane nodes."""
    return _tkc_all_clusters_port_connectivity_check(6443, "Kubernetes API server")

def tkc_control_plane_port_10250_check():
    """Check inter-node connectivity on port 10250 (Kubelet API) between control plane nodes."""
    return _tkc_all_clusters_port_connectivity_check(10250, "Kubelet API")

def tkc_control_plane_port_2379_check():
    """Check inter-node connectivity on port 2379 (etcd client) between control plane nodes."""
    return _tkc_all_clusters_port_connectivity_check(2379, "etcd client")

def tkc_control_plane_port_2380_check():
    """Check inter-node connectivity on port 2380 (etcd peer) between control plane nodes."""
    return _tkc_all_clusters_port_connectivity_check(2380, "etcd peer")

def _tkc_single_cluster_etcd_member_list_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check etcd member list for a single TKC cluster.
    Verifies that etcd has the expected number of members (3 for HA clusters).
    
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking etcd member list for cluster {cluster_id}")
    
    try:
        control_plane_nodes = tkc_manager.find_all_control_plane_ips(cluster_name, namespace)
        
        if not control_plane_nodes:
            logger.debug(f"WARNING: No control plane nodes found for cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: No control plane nodes found"
        
        first_node = control_plane_nodes[0]
        node_ip = first_node["ip"]
        
        logger.debug(f"Running etcd member list check on node {first_node['name']} ({node_ip})")
        
        result = tkc_manager.run_etcdctl_command_on_tkc_node(
            node_ip, ssh_key_path, "member list -w json"
        )
        
        if not result:
            logger.debug(f"WARNING: Failed to get etcd member list for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get etcd member list"
        
        try:
            member_data = json.loads(result)
        except json.JSONDecodeError as e:
            logger.debug(f"ERROR: Failed to parse etcd member list JSON for cluster {cluster_id}: {e}")
            return "FAIL", f"Cluster {cluster_id}: Failed to parse etcd member list"
        
        members = member_data.get("members", [])
        member_count = len(members)
        expected_count = len(control_plane_nodes)
        
        logger.debug(f"Cluster {cluster_id}: Found {member_count} etcd members, expected {expected_count}")
        
        if member_count < expected_count:
            return "FAIL", f"Cluster {cluster_id}: etcd member count ({member_count}) less than control plane nodes ({expected_count})"
        elif member_count > expected_count:
            return "WARN", f"Cluster {cluster_id}: etcd member count ({member_count}) greater than control plane nodes ({expected_count})"
        
        if expected_count >= 3 and member_count < 3:
            return "FAIL", f"Cluster {cluster_id}: HA cluster has less than 3 etcd members ({member_count})"
        
        return "PASS", f"Cluster {cluster_id}: etcd has {member_count} members"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd member list for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking etcd member list: {e}"


def _tkc_single_cluster_etcd_endpoint_health_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check etcd endpoint health for a single TKC cluster.
    Verifies that all etcd endpoints are healthy.
    
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking etcd endpoint health for cluster {cluster_id}")
    
    try:
        control_plane_nodes = tkc_manager.find_all_control_plane_ips(cluster_name, namespace)
        
        if not control_plane_nodes:
            logger.debug(f"WARNING: No control plane nodes found for cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: No control plane nodes found"
        
        first_node = control_plane_nodes[0]
        node_ip = first_node["ip"]
        
        logger.debug(f"Running etcd endpoint health check on node {first_node['name']} ({node_ip})")
        
        result = tkc_manager.run_etcdctl_command_on_tkc_node(
            node_ip, ssh_key_path, "--cluster=true endpoint health -w json"
        )
        
        if not result:
            logger.debug(f"WARNING: Failed to get etcd endpoint health for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get etcd endpoint health"
        
        try:
            health_data = json.loads(result)
        except json.JSONDecodeError as e:
            logger.debug(f"ERROR: Failed to parse etcd endpoint health JSON for cluster {cluster_id}: {e}")
            return "FAIL", f"Cluster {cluster_id}: Failed to parse etcd endpoint health"
        
        if not health_data:
            return "FAIL", f"Cluster {cluster_id}: No etcd endpoint health data received"
        
        unhealthy_endpoints = []
        for entry in health_data:
            endpoint = entry.get("endpoint", "unknown")
            is_healthy = entry.get("health", False)
            if not is_healthy:
                error_msg = entry.get("error", "unknown error")
                logger.debug(f"WARNING: Cluster {cluster_id}: etcd endpoint {endpoint} is not healthy: {error_msg}")
                unhealthy_endpoints.append(f"{endpoint}: {error_msg[:50]}")
            else:
                logger.debug(f"Cluster {cluster_id}: etcd endpoint {endpoint} is healthy")
        
        if unhealthy_endpoints:
            details = f"Cluster {cluster_id}: Unhealthy etcd endpoints:\n    " + "\n    ".join(unhealthy_endpoints[:5])
            if len(unhealthy_endpoints) > 5:
                details += f"\n    (and {len(unhealthy_endpoints) - 5} more)"
            return "FAIL", details
        
        return "PASS", f"Cluster {cluster_id}: All {len(health_data)} etcd endpoints are healthy"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd endpoint health for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking etcd endpoint health: {e}"


def _tkc_single_cluster_etcd_endpoint_status_check(tkc_manager, cluster_name, namespace, ssh_key_path):
    """
    Check etcd endpoint status for a single TKC cluster.
    Verifies that all etcd endpoints have no errors in their status.
    
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking etcd endpoint status for cluster {cluster_id}")
    
    try:
        control_plane_nodes = tkc_manager.find_all_control_plane_ips(cluster_name, namespace)
        
        if not control_plane_nodes:
            logger.debug(f"WARNING: No control plane nodes found for cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: No control plane nodes found"
        
        first_node = control_plane_nodes[0]
        node_ip = first_node["ip"]
        
        logger.debug(f"Running etcd endpoint status check on node {first_node['name']} ({node_ip})")
        
        result = tkc_manager.run_etcdctl_command_on_tkc_node(
            node_ip, ssh_key_path, "--cluster=true endpoint status -w json"
        )
        
        if not result:
            logger.debug(f"WARNING: Failed to get etcd endpoint status for cluster {cluster_id}")
            return "FAIL", f"Cluster {cluster_id}: Failed to get etcd endpoint status"
        
        try:
            status_data = json.loads(result)
        except json.JSONDecodeError as e:
            logger.debug(f"ERROR: Failed to parse etcd endpoint status JSON for cluster {cluster_id}: {e}")
            return "FAIL", f"Cluster {cluster_id}: Failed to parse etcd endpoint status"
        
        if not status_data:
            return "FAIL", f"Cluster {cluster_id}: No etcd endpoint status data received"
        
        endpoints_with_errors = []
        for entry in status_data:
            endpoint = entry.get("endpoint", "unknown")
            errors = entry.get("errors")
            if errors:
                logger.debug(f"WARNING: Cluster {cluster_id}: etcd endpoint {endpoint} has errors: {errors}")
                endpoints_with_errors.append(f"{endpoint}: {str(errors)[:50]}")
            else:
                logger.debug(f"Cluster {cluster_id}: etcd endpoint {endpoint} status OK")
        
        if endpoints_with_errors:
            details = f"Cluster {cluster_id}: etcd endpoints with errors:\n    " + "\n    ".join(endpoints_with_errors[:5])
            if len(endpoints_with_errors) > 5:
                details += f"\n    (and {len(endpoints_with_errors) - 5} more)"
            return "FAIL", details
        
        return "PASS", f"Cluster {cluster_id}: All {len(status_data)} etcd endpoints have no errors"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd endpoint status for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking etcd endpoint status: {e}"


def _tkc_all_clusters_etcd_check(check_func, title):
    """
    Generic function to run an etcd check across all TKC clusters.
    
    Args:
        check_func: Function to call for each cluster
        title: Title for the check result
    
    Returns a result dict with per-cluster etcd status.
    """
    result = "PASS"
    details_list = []
    
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        clusters = tkc_manager.get_tkc_clusters()
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        
        failed_count = 0
        checked_count = 0
        
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name", "unknown")
            namespace = cluster.get("metadata", {}).get("namespace", "unknown")
            phase = cluster.get("status", {}).get("phase", "unknown")
            
            if phase != "Provisioned":
                details_list.append(f"Cluster {namespace}/{name}: Skipped (phase={phase})")
                continue
            
            ssh_key_path = get_ssh_key_for_cluster(tkc_manager, name, namespace)
            if not ssh_key_path:
                details_list.append(f"Cluster {namespace}/{name}: Failed to get SSH key")
                result = "FAIL"
                failed_count += 1
                continue
            
            check_result, check_details = check_func(
                tkc_manager, name, namespace, ssh_key_path
            )
            
            details_list.append(check_details)
            checked_count += 1
            
            if check_result == "FAIL":
                result = "FAIL"
                failed_count += 1
            elif check_result == "WARN" and result != "FAIL":
                result = "WARN"
        
        if not details_list:
            details = "No TKC clusters to check"
        else:
            details = "\n".join(details_list[:10])
            if len(details_list) > 10:
                details += f"\n(and {len(details_list) - 10} more clusters)"
        
        logger.debug(f"INFO: {title} completed: {result} ({failed_count}/{checked_count} failed)")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to run {title}: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to run check: {e}"}

def tkc_all_clusters_etcd_member_list_check():
    """Check etcd member list for all TKC clusters."""
    return _tkc_all_clusters_etcd_check(
        _tkc_single_cluster_etcd_member_list_check,
        "TKC etcd Member List Check"
    )

def tkc_all_clusters_etcd_endpoint_health_check():
    """Check etcd endpoint health for all TKC clusters."""
    return _tkc_all_clusters_etcd_check(
        _tkc_single_cluster_etcd_endpoint_health_check,
        "TKC etcd Endpoint Health Check"
    )

def tkc_all_clusters_etcd_endpoint_status_check():
    """Check etcd endpoint status for all TKC clusters."""
    return _tkc_all_clusters_etcd_check(
        _tkc_single_cluster_etcd_endpoint_status_check,
        "TKC etcd Endpoint Status Check"
    )

def _tkc_single_cluster_cert_check(tkc_manager, cluster_name, namespace, ssh_key_path, 
                                    warning_days=30, critical_days=7):
    """
    Check certificate expiration on all control plane nodes of a single TKC cluster.
    Runs 'kubeadm certs check-expiration' on each control plane node.
    
    Returns (result, details) tuple.
    """
    cluster_id = f"{namespace}/{cluster_name}"
    logger.debug(f"Checking certificate expiration for cluster {cluster_id}")
    
    try:
        control_plane_nodes = tkc_manager.find_all_control_plane_ips(cluster_name, namespace)
        
        if not control_plane_nodes:
            logger.debug(f"WARNING: No control plane nodes found for cluster {cluster_id}")
            return "WARN", f"Cluster {cluster_id}: No control plane nodes found"
        
        all_certs = []
        failed_nodes = []
        
        for node in control_plane_nodes:
            node_name = node["name"]
            node_ip = node["ip"]
            
            logger.debug(f"Running kubeadm certs check-expiration on node {node_name} ({node_ip})")
            
            result = tkc_manager.ssh_to_tkc_node(
                node_ip, ssh_key_path, "kubeadm certs check-expiration"
            )
            
            if not result:
                logger.debug(f"WARNING: Failed to get certificate info from node {node_name}")
                failed_nodes.append(node_name)
                continue

            certs = parse_kubeadm_cert_output(result)
            
            if not certs:
                logger.debug(f"WARNING: No certificates parsed from node {node_name}")
                failed_nodes.append(node_name)
                continue
            
            for cert in certs:
                cert["node_name"] = node_name
                cert["node_ip"] = node_ip
            
            all_certs.extend(certs)
            logger.debug(f"Found {len(certs)} certificates on node {node_name}")
        
        if not all_certs and failed_nodes:
            return "FAIL", f"Cluster {cluster_id}: Failed to check certificates on nodes: {', '.join(failed_nodes)}"
        
        if not all_certs:
            return "WARN", f"Cluster {cluster_id}: No certificates found"
        
        expired_certs = []
        critical_certs = []
        warning_certs = []
        
        for cert in all_certs:
            days = cert.get("residual_days", -1)
            cert_info = f"{cert['cert_name']} on {cert['node_name']} ({cert['residual_time']})"
            
            if days < 0:
                expired_certs.append(cert_info)
            elif days <= critical_days:
                critical_certs.append(cert_info)
            elif days <= warning_days:
                warning_certs.append(cert_info)
        
        if expired_certs:
            details = f"Cluster {cluster_id}: EXPIRED certificates:\n    " + "\n    ".join(expired_certs[:5])
            if len(expired_certs) > 5:
                details += f"\n    (and {len(expired_certs) - 5} more)"
            return "FAIL", details
        
        if critical_certs:
            details = f"Cluster {cluster_id}: Certificates expiring within {critical_days} days:\n    " + "\n    ".join(critical_certs[:5])
            if len(critical_certs) > 5:
                details += f"\n    (and {len(critical_certs) - 5} more)"
            return "FAIL", details
        
        if warning_certs:
            details = f"Cluster {cluster_id}: Certificates expiring within {warning_days} days:\n    " + "\n    ".join(warning_certs[:5])
            if len(warning_certs) > 5:
                details += f"\n    (and {len(warning_certs) - 5} more)"
            return "WARN", details
        
        min_days = min(cert.get("residual_days", 999999) for cert in all_certs if cert.get("residual_days", -1) > 0)
        return "PASS", f"Cluster {cluster_id}: All certificates valid (min {min_days}d remaining)"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check certificates for cluster {cluster_id}: {e}")
        return "FAIL", f"Cluster {cluster_id}: Error checking certificates: {e}"


def tkc_all_clusters_cert_check():
    """
    Check kubeadm certificate expiration on all TKC clusters.
    Runs 'kubeadm certs check-expiration' on each control plane node of each cluster.
    
    Returns a result dict with per-cluster certificate status.
    """
    title = "TKC kubeadm Certificate Expiration Check"
    result = "PASS"
    
    cfgfile = os.path.join(os.path.dirname(os.path.dirname(__file__)), "vks_cfg", "vks_vdt.ini")
    config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
    config.read(cfgfile)
    warning_days = int(config.get('thresholds', 'cert_expiry_warning', fallback='30'))
    critical_days = int(config.get('thresholds', 'cert_expiry_critical', fallback='7'))
    
    tkc_manager = get_tkc_manager()
    if not tkc_manager:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    
    try:
        clusters = tkc_manager.get_tkc_clusters()
        if not clusters or not clusters.get("items"):
            return {"title": title, "result": "PASS", "details": "No TKC clusters found"}
        
        details_list = []
        failed_count = 0
        warn_count = 0
        checked_count = 0
        
        for cluster in clusters["items"]:
            name = cluster.get("metadata", {}).get("name")
            namespace = cluster.get("metadata", {}).get("namespace")
            
            if not name or not namespace:
                logger.debug(f"WARNING: Skipping cluster with missing name or namespace")
                continue
            
            phase = cluster.get("status", {}).get("phase", "unknown")
            if phase != "Provisioned":
                logger.debug(f"Skipping cluster {namespace}/{name} - phase is {phase}")
                details_list.append(f"Cluster {namespace}/{name}: Skipped (phase={phase})")
                continue
            
            ssh_key_path = get_ssh_key_for_cluster(tkc_manager, name, namespace)
            if not ssh_key_path:
                logger.debug(f"WARNING: Failed to get SSH key for cluster {namespace}/{name}")
                details_list.append(f"Cluster {namespace}/{name}: Failed to get SSH key")
                failed_count += 1
                result = "FAIL"
                continue
            
            check_result, check_details = _tkc_single_cluster_cert_check(
                tkc_manager, name, namespace, ssh_key_path, warning_days, critical_days
            )
            
            details_list.append(check_details)
            checked_count += 1
            
            if check_result == "FAIL":
                result = "FAIL"
                failed_count += 1
            elif check_result == "WARN":
                warn_count += 1
                if result != "FAIL":
                    result = "WARN"
        
        if not details_list:
            details = "No TKC clusters to check"
        else:
            details = "\n".join(details_list[:10])
            if len(details_list) > 10:
                details += f"\n(and {len(details_list) - 10} more clusters)"
        
        logger.debug(f"INFO: TKC certificate check completed: {result} ({failed_count} failed, {warn_count} warnings out of {checked_count} checked)")
        return {"title": title, "result": result, "details": details}
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check TKC cluster certificates: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to check TKC cluster certificates: {e}"}

def tkc_system_all_checks():
    """Run all TKC system/infrastructure checks and return a list of result dicts."""
    results = []
    try:
        results.append(tkc_control_plane_port_6443_check())
        results.append(tkc_control_plane_port_10250_check())
        results.append(tkc_control_plane_port_2379_check())
        results.append(tkc_control_plane_port_2380_check())
        results.append(tkc_all_clusters_etcd_member_list_check())
        results.append(tkc_all_clusters_etcd_endpoint_health_check())
        results.append(tkc_all_clusters_etcd_endpoint_status_check())
        results.append(tkc_all_clusters_cert_check())
    except Exception as e:
        logger.debug(f"ERROR: Failed to run TKC system checks: {e}")
        results.append({
            "title": "TKC System Checks",
            "result": "FAIL",
            "details": f"Failed to run TKC system checks: {e}"
        })
    return results
