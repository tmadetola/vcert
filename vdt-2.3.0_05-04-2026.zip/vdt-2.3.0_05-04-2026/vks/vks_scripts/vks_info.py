__title__ = "VKS Basic Info"

from vks.vks_lib.vks_db_utils import export_wcp_tables_to_json, read_wcp_table, getSupervisorName, remove_exported_wcp_tables
from vks.vks_lib.vks_sv_utils import checkSshAvailability

SUPERVISOR_NAME = getSupervisorName()

def getSvConfig():
    """
    Get the supervisor configuration from the cluster_db_configs.json file.
    
    Returns:
        dict: The supervisor configuration if found, otherwise None.
    """
    cluster_db_configs = read_wcp_table("cluster_db_configs.json")

    for config in cluster_db_configs:
        if config.get("desired_config", {}).get("Name") == SUPERVISOR_NAME:
            return config
        
def findSupervisorName():
    """
    Find the supervisor name from the cluster_db_configs.json file.
    """
    title = "Supervisor Name Detection"
    result = "INFO"
    details = ""

    if SUPERVISOR_NAME:
        details = f"Running VDT against Supervisor: {SUPERVISOR_NAME}. \n" \
                   f"If this is not the correct supervisor, please set the environment variable SUPERVISOR_NAME to the correct value." 

    else:
        details = "No supervisor name found."
        result = "FAIL"

    return {"title": title, "result": result, "details": details}

def getSvId():
    sv_config = getSvConfig()

    if sv_config:
        return sv_config.get("instance_id")
    return None

def getSvVersion():
    sv_config = getSvConfig()

    if sv_config:
        return sv_config.get("cluster_version", "Unknown Version")
    return "Unknown Version"

def getTkgSvVersion():
    supervisor_services = read_wcp_table("kube_carvel_package_installs.json")
    
    for svc in supervisor_services:
        if svc.get("supervisor_id") == getSvId() and svc.get("name") == "svc-tkg.vsphere.vmware.com":
            # return svc.data.status.version
            return svc.get("data", {}).get("status", {}).get("version")
        
def getEsxiNodeCount():
    """
    Get the count of ESXi nodes in the supervisor cluster.
    
    Returns:
        int: The count of ESXi nodes.
    """
    worker_nodes = read_wcp_table("node_configs.json")

    # return the count of entries in the json where "desired_state":"Ready"
    if worker_nodes is not None:
        return len([node for node in worker_nodes if node.get("desired_state") == "Ready"])
    return 0

def installedSupervisorServices():
    """
    Returns a list of installed supervisor services.
    
    Returns:
        list: A list of installed supervisor services.
    """
    supervisor_services = read_wcp_table("kube_carvel_package_installs.json")
    return len(supervisor_services) if supervisor_services else 0
    
def getNamespaceCount():
    workload_cluster_db_configs = read_wcp_table("workload_configs.json")
    if workload_cluster_db_configs is None:
        return 0

    count = 0
    for config in workload_cluster_db_configs:
        if config.get("vm_classes") is not None and config.get("supervisor_id") == getSvId():
            count += 1
    return count

def getCapiClusterCount():
    """
    Get the count of Cluster API Cluster resources (cluster.x-k8s.io).
    These are the underlying CAPI clusters that back TKC resources.
    
    Returns:
        int: The count of CAPI Cluster resources.
    """
    kube_capi_clusters = read_wcp_table("kube_capi_clusters.json")
    if kube_capi_clusters is None:
        return 0

    count = 0
    for cluster in kube_capi_clusters:
        if cluster.get("supervisor_id") == getSvId():
            count += 1
    return count

def getTkcV1alpha3Count():
    """
    Get the count of TanzuKubernetesCluster v1alpha3 resources.
    These are TKC CRs using the run.tanzu.vmware.com/v1alpha3 API.
    
    Returns:
        int: The count of v1alpha3 TKC clusters.
    """
    kube_tanzu_kubernetes_clusters = read_wcp_table("kube_tanzu_kubernetes_clusters.json")
    if kube_tanzu_kubernetes_clusters is None:
        return 0

    count = 0
    for cluster in kube_tanzu_kubernetes_clusters:
        if cluster.get("supervisor_id") == getSvId():
            count += 1
    return count

def getTkcV1beta1Count():
    """
    Get the count of TanzuKubernetesCluster v1beta1 resources.
    These are TKC CRs using the run.tanzu.vmware.com/v1beta1 API.
    
    Note: The database table is named kube_tanzu_kubernetes_clusters_v1beta2
    but this actually stores v1beta1 TKC resources (the naming is a database artifact).
    
    Returns:
        int: The count of v1beta1 TKC clusters.
    """
    # The table name in the database is v1beta2 but stores v1beta1 TKC resources
    kube_tanzu_kubernetes_clusters = read_wcp_table("kube_tanzu_kubernetes_clusters_v1beta2.json")
    if kube_tanzu_kubernetes_clusters is None:
        return 0

    count = 0
    for cluster in kube_tanzu_kubernetes_clusters:
        if cluster.get("supervisor_id") == getSvId():
            count += 1
    return count

def VksInfo():
    """
    Collects basic information about the VKS environment.

    Returns:
        dict: A dictionary containing the supervisor name, version, namespace count, and TKC count.
    """
    remove_exported_wcp_tables()
    export_wcp_tables_to_json()


    info = {}

    info["supervisor_name"] = SUPERVISOR_NAME
    info["supervisor_version"] = getSvVersion()
    info["tkg_service_version"] = getTkgSvVersion()
    info["esxi_node_count"] = getEsxiNodeCount()
    info["installed_supervisor_services"] = installedSupervisorServices()
    info["namespace_count"] = getNamespaceCount()
    info["vks_cluster_count"] = getCapiClusterCount()
    
    return info


def main():
    info = VksInfo()

    details = """
Supervisor Name: {supervisor_name}
Supervisor Version: {supervisor_version}
TKG Service Version: {tkg_service_version}
ESXi Node Count: {esxi_node_count}
Installed Supervisor Services: {installed_supervisor_services}
Namespace Count: {namespace_count}
VKS Cluster Count: {vks_cluster_count}
""".format(**info)

    title = __title__
    result = "INFO"

    return {"title": title, "result": result, "details": details}


if __name__ == "__main__":
    main()