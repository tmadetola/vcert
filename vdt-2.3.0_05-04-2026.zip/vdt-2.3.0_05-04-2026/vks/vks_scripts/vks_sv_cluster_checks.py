import json
import logging
from vks.vks_lib.vks_supervisor_manager import supervisor_manager
from vks.vks_lib.vks_sv_utils import checkSshAvailability, run_ssh_command
from vks.vks_scripts.vks_info import getSvConfig

logger = logging.getLogger(__name__)


def getSvVmCount():
    logger.debug(f"INFO: Starting supervisor VM count check")
    sv_config = getSvConfig()

    title = "Supervisor VM Count"
    result = "PASS"
    details = ""

    if not sv_config:
        logger.debug(f"ERROR: No supervisor configuration found")
        return {"title": title, "result": "FAIL", "details": "No supervisor configuration found"}

    vm_count = len(sv_config.get("master_vm_information", [])) if sv_config else 0
    logger.debug(f"Found {vm_count} supervisor VMs in configuration")
    
    if vm_count != 3:
        details = f"Supervisor VM count is {vm_count}. Expected 3 VMs."
        result = "WARN"
        logger.debug(f"WARNING: Supervisor VM count mismatch: expected 3, found {vm_count}")
    else:
        logger.debug(f"INFO: Supervisor VM count is correct (3 VMs)")
    
    return {"title": title, "result": result, "details": details}

def getSvVipAvailability():
    logger.debug(f"INFO: Starting supervisor VIP availability check")
    sv_config = getSvConfig()

    title = "Supervisor VIP Availability"
    result = "PASS"
    details = ""

    if not sv_config:
        logger.debug(f"ERROR: No supervisor configuration found")
        return {"title": title, "result": "FAIL", "details": "No supervisor configuration found"}

    master_mgmt_ip = sv_config.get("master_mgmt_ip")
    if not master_mgmt_ip:
        details = "Supervisor management IP is not configured."
        result = "FAIL"
        logger.debug(f"ERROR: Supervisor management IP not configured")
        return {"title": title, "result": result, "details": details}
    
    logger.debug(f"Checking SSH availability for supervisor VIP: {master_mgmt_ip}")
    try:
        if checkSshAvailability(master_mgmt_ip):
            logger.debug(f"INFO: Supervisor VIP {master_mgmt_ip} is available via SSH")
        else:
            details = "Supervisor VIP is not available via SSH."
            result = "WARN"
            logger.debug(f"WARNING: Supervisor VIP {master_mgmt_ip} is not available via SSH")
    except Exception as e:
        logger.debug(f"ERROR: Failed to check SSH availability for {master_mgmt_ip}: {e}")
        details = f"Failed to check SSH availability: {e}"
        result = "FAIL"

    return {"title": title, "result": result, "details": details}

def supervisor_nodes_are_ready_check():
    """
    Check if the supervisor nodes are in a ready state.

    Returns:
        dict: A dictionary containing the title, result, and details of the node readiness check.
    """
    logger.debug(f"INFO: Starting supervisor nodes readiness check")
    # Use single supervisor for kubectl commands instead of all VMs
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor Nodes Are Ready Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        logger.debug(f"ERROR: No supervisor IP available for node readiness check")
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    # Run kubectl get nodes only once to retrieve all node information
    logger.debug(f"Getting node status from chosen supervisor VM: {supervisor_ip}")
    try:
        kubectl_output = run_ssh_command(supervisor_ip, "root", "kubectl get nodes -o json")
    except Exception as e:
        logger.debug(f"ERROR: Failed to run kubectl get nodes: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to run kubectl get nodes: {e}"}

    try:
        nodes_data = json.loads(kubectl_output)
        logger.debug(f"Successfully parsed kubectl output, found {len(nodes_data.get('items', []))} nodes")
    except (json.JSONDecodeError, TypeError) as e:
        logger.debug(f"ERROR: Could not decode kubectl output: {e}")
        return {"title": title, "result": "FAIL", "details": "Could not decode kubectl output"}

    # Get all supervisors to check their node status
    supervisor_vms = supervisor_manager.get_supervisors()
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for cross-referencing nodes")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    # Process each VM's status based on the kubectl output
    for vm in supervisor_vms:
        vm_dns = vm.get("vm_dns")
        if vm_dns:
            node_name = vm_dns  # Using DNS name as the node name
            ready_status = "False"

            for item in nodes_data.get("items", []):
                if item["metadata"]["name"] == node_name:
                    for condition in item["status"]["conditions"]:
                        if condition["type"] == "Ready" and condition["status"] == "True":
                            ready_status = "True"
                            logger.debug(f"Node {node_name} is ready")
                            break
                    break # Found node, can stop looking

            if ready_status != "True":
                result = "FAIL"
                details += f"VM {vm['vm_name']} ({vm['vm_dns']}) is not ready.\n"
                logger.debug(f"ERROR: Node {node_name} is not ready")
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no DNS name, skipping readiness check")

    logger.debug(f"INFO: Node readiness check completed with result: {result}")
    return {"title": title, "result": result, "details": details}


def supervisor_vms_roles_check():
    """
    Check if the supervisor VMs have the correct roles assigned.

    Returns:
        dict: A dictionary containing the title, result, and details of the role check.
    """
    logger.debug(f"INFO: Starting supervisor VMs roles check")
    # Use single supervisor for kubectl commands
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "Supervisor VMs Roles Check"
    result = "PASS"
    details = ""

    if not supervisor_ip:
        logger.debug(f"ERROR: No supervisor IP available for roles check")
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}

    # Run kubectl get nodes to get role information
    logger.debug(f"Getting node roles from chosen supervisor VM: {supervisor_ip}")
    try:
        kubectl_output = run_ssh_command(supervisor_ip, "root", "kubectl get nodes -o json")
    except Exception as e:
        logger.debug(f"ERROR: Failed to run kubectl get nodes: {e}")
        return {"title": title, "result": "FAIL", "details": f"Failed to run kubectl get nodes: {e}"}

    try:
        nodes_data = json.loads(kubectl_output)
        logger.debug(f"Successfully parsed kubectl output for roles check")
    except (json.JSONDecodeError, TypeError) as e:
        logger.debug(f"ERROR: Could not decode kubectl output: {e}")
        return {"title": title, "result": "FAIL", "details": "Could not decode kubectl output"}

    # Get all supervisors to check their roles
    supervisor_vms = supervisor_manager.get_supervisors()
    if not supervisor_vms:
        logger.debug(f"ERROR: No supervisor VMs found for cross-referencing roles")
        return {"title": title, "result": "FAIL", "details": "No supervisor VMs found"}

    for vm in supervisor_vms:
        vm_dns = vm.get("vm_dns")
        if vm_dns:
            node_name = vm_dns
            correct_roles = False

            for item in nodes_data.get("items", []):
                if item["metadata"]["name"] == node_name: #Find the current vm from the supervisors
                    labels = item["metadata"]["labels"]
                    if "node-role.kubernetes.io/control-plane" in labels or "node-role.kubernetes.io/master" in labels:
                        correct_roles = True
                        logger.debug(f"Node {node_name} has correct control-plane/master role")
                    else:
                        logger.debug(f"ERROR: Node {node_name} missing control-plane/master role. Labels: {list(labels.keys())}")
                    break #Found it, can stop looking
            
            if not correct_roles:
                 result = "FAIL"
                 details += f"VM {vm['vm_name']} ({vm['vm_dns']}) does not have the correct roles assigned.\n"
        else:
            logger.debug(f"WARNING: VM {vm.get('vm_name')} has no DNS name, skipping roles check")

    logger.debug(f"INFO: Supervisor VMs roles check completed with result: {result}")
    return {"title": title, "result": result, "details": details}