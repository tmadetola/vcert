import json 
import logging
from lib.vdt_base import set_force_flag
from vks.vks_lib.vks_sv_utils import run_ssh_command
from vks.vks_lib.vks_supervisor_manager import supervisor_manager

logger = logging.getLogger(__name__)


def etcdctl_member_list(supervisor_ip):
    """
    Get the etcd member list from the supervisor VM.

    Args:
        supervisor_ip (str): The IP address of the supervisor VM.

    Returns:
        list: A list of dictionaries containing the etcd member information.
    """
    logger.debug(f"Getting etcd member list from supervisor {supervisor_ip}")
    command = "etcdctl member list -w json"
    try:
        output = run_ssh_command(supervisor_ip, "root", command)
        result = json.loads(output)
        logger.debug(f"Retrieved {len(result.get('members', []))} etcd members")
        return result
    except json.JSONDecodeError as e:
        logger.debug(f"ERROR: Failed to parse etcd member list JSON: {e}")
        raise
    except Exception as e:
        logger.debug(f"ERROR: Failed to get etcd member list: {e}")
        raise

def etcdctl_endpoint_health(supervisor_ip):
    """
    Get the health status of etcd endpoints from the supervisor VM.

    Args:
        supervisor_ip (str): The IP address of the supervisor VM.

    Returns:
        list: A list of dictionaries containing the health status of etcd endpoints.
    """
    logger.debug(f"Getting etcd endpoint health from supervisor {supervisor_ip}")
    command = "etcdctl --cluster=true endpoint health -w json"
    try:
        output = run_ssh_command(supervisor_ip, "root", command)
        result = json.loads(output)
        logger.debug(f"Retrieved health status for {len(result)} etcd endpoints")
        return result
    except json.JSONDecodeError as e:
        logger.debug(f"ERROR: Failed to parse etcd endpoint health JSON: {e}")
        raise
    except Exception as e:
        logger.debug(f"ERROR: Failed to get etcd endpoint health: {e}")
        raise

def etcdctl_endpoint_status(supervisor_ip):
    """
    Get the status of etcd endpoints from the supervisor VM.

    Args:
        supervisor_ip (str): The IP address of the supervisor VM.

    Returns:
        list: A list of dictionaries containing the status of etcd endpoints.
    """
    logger.debug(f"Getting etcd endpoint status from supervisor {supervisor_ip}")
    command = "etcdctl --cluster=true endpoint status -w json"
    try:
        output = run_ssh_command(supervisor_ip, "root", command)
        result = json.loads(output)
        logger.debug(f"Retrieved status for {len(result)} etcd endpoints")
        return result
    except json.JSONDecodeError as e:
        logger.debug(f"ERROR: Failed to parse etcd endpoint status JSON: {e}")
        raise
    except Exception as e:
        logger.debug(f"ERROR: Failed to get etcd endpoint status: {e}")
        raise

def etcd_running_check(supervisor_ip):
    """
    Check if the etcd service is running on the supervisor VM.

    Args:
        supervisor_ip (str): The IP address of the supervisor VM.

    Returns:
        bool: True if etcd is running, False otherwise.
    """
    logger.debug(f"Checking if etcd is running on supervisor {supervisor_ip}")
    command = "etcdctl member list -w json"
    try:
        output = json.loads(run_ssh_command(supervisor_ip, "root", command))
        # check if "level": "warn" kv is in output
        if isinstance(output, dict) and "level" in output and output["level"] == "warn":
            logger.debug(f"ERROR: ETCD warning detected: {output.get('error', 'Unknown etcd error')}")
            return False, output.get("error", "Unknown etcd error")
        logger.debug("ETCD is running normally")
        return True, None
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd running status: {e}")
        return False, str(e)
    
def etcdctl_member_list_check(supervisor_ip):
    logger.debug(f"Checking etcd member list on supervisor {supervisor_ip}")
    try:
        members = etcdctl_member_list(supervisor_ip)
        member_count = len(members.get("members", []))
        logger.debug(f"Found {member_count} etcd members")
        if member_count < 3:
            logger.debug(f"WARNING: ETCD member count is {member_count}, expected at least 3")
            return False
        return True
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd member list: {e}")
        return False

def etcdctl_endpoint_health_check(supervisor_ip):
    logger.debug(f"Checking etcd endpoint health on supervisor {supervisor_ip}")
    try:
        health_output = etcdctl_endpoint_health(supervisor_ip)
        if not health_output:
            logger.debug(f"ERROR: No health output received from etcd")
            return False, None
        
        for entry in health_output:
            endpoint = entry.get("endpoint", "unknown")
            is_healthy = entry.get("health", False)
            if not is_healthy:
                logger.debug(f"ERROR: ETCD endpoint {endpoint} is not healthy")
                return False, endpoint
            else:
                logger.debug(f"ETCD endpoint {endpoint} is healthy")
        
        return True, None
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd endpoint health: {e}")
        return False, None

def etcdctl_endpoint_status_check(supervisor_ip):
    logger.debug(f"Checking etcd endpoint status on supervisor {supervisor_ip}")
    try:
        status = etcdctl_endpoint_status(supervisor_ip)
        if not status:
            logger.debug(f"ERROR: No status output received from etcd")
            return False, None
        
        for entry in status:
            endpoint = entry.get("endpoint", "unknown")
            # check if entry has "errors" key and it is not empty
            if "errors" in entry and entry["errors"]:
                logger.debug(f"ERROR: ETCD endpoint {endpoint} has errors: {entry['errors']}")
                return False, entry.get("errors")
            else:
                logger.debug(f"ETCD endpoint {endpoint} status OK")
        
        return True, None
    except Exception as e:
        logger.debug(f"ERROR: Failed to check etcd endpoint status: {e}")
        return False, None

def supervisor_etcd_running_check():
    """
    Check if etcd is running on the supervisor.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "etcd Running Check"
    result = "PASS"
    details = ""
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    etcd_running, etcd_error = etcd_running_check(supervisor_ip)
    if not etcd_running:
        result = "FAIL"
        details = f"etcd command failed with error {etcd_error}"
    return {"title": title, "result": result, "details": details}


def supervisor_etcd_member_list_check():
    """
    Check if etcd member list has at least 3 members.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "etcd Member List Check"
    result = "PASS"
    details = ""
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    if not etcdctl_member_list_check(supervisor_ip):
        result = "FAIL"
        details = "etcd member list check failed. Less than 3 members found."
    return {"title": title, "result": result, "details": details}


def supervisor_etcd_endpoint_health_check():
    """
    Check if all etcd endpoints are healthy.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "etcd Endpoint Health Check"
    result = "PASS"
    details = ""
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    health_ok, unhealthy_endpoint = etcdctl_endpoint_health_check(supervisor_ip)
    if not health_ok:
        result = "FAIL"
        details = f"etcd endpoint health check failed. Endpoint {unhealthy_endpoint} is not healthy."
    return {"title": title, "result": result, "details": details}


def supervisor_etcd_endpoint_status_check():
    """
    Check if all etcd endpoints have no errors in their status.
    Returns a result dict.
    """
    supervisor_ip = supervisor_manager.get_chosen_supervisor_ip()
    title = "etcd Endpoint Status Check"
    result = "PASS"
    details = ""
    if not supervisor_ip:
        return {"title": title, "result": "FAIL", "details": "No supervisor IP available"}
    status_ok, status_errors = etcdctl_endpoint_status_check(supervisor_ip)
    if not status_ok:
        result = "FAIL"
        details = f"etcd endpoint status check failed. Errors found: {status_errors}"
    return {"title": title, "result": result, "details": details}


def supervisor_etcd_all_checks():
    """
    Run all etcd checks and return a list of result dicts.
    """
    set_force_flag(enabled=True)
    results = []
    try:
        results.append(supervisor_etcd_running_check())
        results.append(supervisor_etcd_member_list_check())
        results.append(supervisor_etcd_endpoint_health_check())
        results.append(supervisor_etcd_endpoint_status_check())
    finally:
        set_force_flag(enabled=False)
    return results