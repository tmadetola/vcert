import logging
import re
import json
from vks.vks_lib.common import run_command
from vks.vks_lib.vks_db_utils import read_wcp_table
from vks.vks_lib.vks_supervisor_manager import supervisor_manager
from vks.vks_lib.vks_sv_utils import run_ssh_command

logger = logging.getLogger(__name__)

def vks_wcp_pending_upgrade():
    """
    Check for pending VKS WCP upgrades by comparing supervisor control plane versions,
    VMware-wcpovf package version, and wcp_version from configuration.
    
    Returns:
        dict: A dictionary containing the title, result, and details of the upgrade check.
    """
    logger.debug(f"INFO: Running VKS WCP Pending Upgrade Check")
    
    title = "VKS WCP Pending Upgrade Check"
    result = "PASS"
    details = ""
    
    try:
        # Get supervisor VM information from supervisor manager
        logger.debug("Getting supervisor VM information from supervisor manager")
        supervisor_vms = supervisor_manager.get_supervisors()
        
        if not supervisor_vms:
            logger.debug(f"WARNING: No supervisor VMs found")
            return {"title": title, "result": "WARN", "details": "No supervisor VMs found"}
        
        # Get version information from each supervisor VM via SSH
        master_vm_versions = {}
        for vm in supervisor_vms:
            vm_ip = vm.get("vm_ip")
            vm_name = vm.get("vm_name")
            if vm_ip:
                logger.debug(f"Getting version for VM {vm_name} ({vm_ip})")
                try:
                    # Get the kubelet version which contains the build information
                    version_cmd = "kubectl version --client=true -o json 2>/dev/null | jq -r '.clientVersion.gitVersion' || kubelet --version | awk '{print $2}'"
                    version_output = run_ssh_command(vm_ip, "root", version_cmd)
                    if version_output:
                        master_vm_versions[vm_name] = version_output.strip()
                        logger.debug(f"VM {vm_name}: {version_output.strip()}")
                    else:
                        logger.debug(f"WARNING: Could not get version for VM {vm_name}")
                except Exception as e:
                    logger.debug(f"ERROR: Failed to get version for VM {vm_name}: {e}")
        
        if not master_vm_versions:
            logger.debug(f"WARNING: No master VM version information found")
            return {"title": title, "result": "WARN", "details": "No master VM version information found"}
        
        # Get VMware-wcpovf package version
        logger.debug("Getting VMware-wcpovf package version")
        rpm_cmd = ["rpm", "-qa", "VMware-wcpovf*"]
        rpm_output = run_command(rpm_cmd).decode().strip()
        
        wcpovf_version = None
        if rpm_output:
            # Extract version from output like "VMware-wcpovf-4.0.584-23905380.x86_64"
            match = re.search(r'VMware-wcpovf-[\d\.]+-(\d+)', rpm_output)
            if match:
                wcpovf_version = match.group(1)
                logger.debug(f"VMware-wcpovf version: {wcpovf_version}")
            else:
                logger.debug(f"WARNING: Could not parse VMware-wcpovf version from: {rpm_output}")
        else:
            logger.debug(f"WARNING: VMware-wcpovf package not found")
        
        # Get wcp_version from configuration
        logger.debug("Getting wcp_version from configuration")
        wcp_versions_cmd = ["cat", "/etc/vmware/wcp/wcp_versions.yaml"]
        wcp_versions_output = run_command(wcp_versions_cmd).decode().strip()
        
        wcp_config_version = None
        for line in wcp_versions_output.split('\n'):
            if 'wcp_version:' in line:
                # Extract version from line like "   wcp_version: 0.1.9-23905380"
                match = re.search(r'wcp_version:\s*[\d\.]+-(\d+)', line)
                if match:
                    wcp_config_version = match.group(1)
                    logger.debug(f"WCP config version: {wcp_config_version}")
                break
        
        if not wcp_config_version:
            logger.debug(f"WARNING: Could not find wcp_version in configuration")
        
        # Compare versions
        version_issues = []
        
        # Check if wcpovf and wcp_version match
        if wcpovf_version and wcp_config_version:
            if wcpovf_version != wcp_config_version:
                version_issues.append(f"VMware-wcpovf version ({wcpovf_version}) does not match wcp_version ({wcp_config_version})")
                logger.debug(f"WARNING: Version mismatch: wcpovf={wcpovf_version}, wcp_config={wcp_config_version}")
        
        # Check if all master VMs have consistent versions
        if master_vm_versions:
            unique_versions = set()
            for vm_name, version in master_vm_versions.items():
                # Extract build number from version like "v1.28.3+vmware.2-fips.1-vsc0.1.9-23905380"
                match = re.search(r'-(\d+)$', version)
                if match:
                    unique_versions.add(match.group(1))
            
            if len(unique_versions) > 1:
                version_issues.append(f"Inconsistent versions across master VMs: {list(unique_versions)}")
                logger.debug(f"WARNING: Inconsistent master VM versions: {unique_versions}")
            
            # Compare master VM versions with wcpovf/wcp_version
            if unique_versions and wcpovf_version:
                master_build = list(unique_versions)[0] if len(unique_versions) == 1 else None
                if master_build and master_build != wcpovf_version:
                    version_issues.append(f"Master VM build ({master_build}) does not match VMware-wcpovf version ({wcpovf_version})")
                    logger.debug(f"WARNING: Master VM build mismatch: {master_build} vs {wcpovf_version}")
        
        # Set result based on findings
        if version_issues:
            result = "WARN"
            details = "Pending upgrade detected:\n" + "\n".join([f"- {issue}" for issue in version_issues])
            details += "\n\nVersions found:"
            if wcpovf_version:
                details += f"\n- VMware-wcpovf: {wcpovf_version}"
            if wcp_config_version:
                details += f"\n- wcp_version: {wcp_config_version}"
            for vm_name, version in master_vm_versions.items():
                details += f"\n- {vm_name}: {version}"
        else:
            details = "All versions are consistent - no pending upgrade detected."
            if wcpovf_version:
                details += f"\n- VMware-wcpovf: {wcpovf_version}"
            if wcp_config_version:
                details += f"\n- wcp_version: {wcp_config_version}"
            for vm_name, version in master_vm_versions.items():
                details += f"\n- {vm_name}: {version}"
        
    except Exception as e:
        logger.debug(f"ERROR: Failed to check for pending upgrades: {e}")
        result = "FAIL"
        details = f"Failed to check for pending upgrades: {e}"

    logger.debug(f"INFO: VKS WCP Pending Upgrade Check completed with result: {result}")
    return {
        "title": title,
        "result": result,
        "details": details
    }

def vks_wcp_ongoing_upgrade():
    """
    Check for ongoing VKS WCP upgrades by checking the supervisor VM version.
    
    Returns:
        dict: A dictionary containing the title, result, and details of the upgrade check.
    """
    logger.debug(f"INFO: Running VKS WCP Ongoing Upgrade Check")
    title = "VKS WCP Ongoing Upgrade Check"
    result = "PASS"
    details = ""
    
    try:
        # Get supervisor VM information from supervisor manager
        logger.debug("Getting supervisor VM information from supervisor manager")
        supervisor_db_configs = read_wcp_table("cluster_db_configs.json")

        if not supervisor_db_configs:
            logger.debug(f"WARNING: No supervisor DB configs found")
            return {"title": title, "result": "WARN", "details": "No supervisor DB configs found"}
        
        for config in supervisor_db_configs:
            logger.debug("Checking upgrade state for config: %s - %s", config.get("desired_config", {}).get("Name"), config.get("upgrade_state"))
            if config.get("upgrade_state") == "ERROR":
                result = "FAIL"
                details = "WCP upgrade error detected."
                break
            if config.get("upgrade_state") != "READY":
                result = "WARN"
                details = "WCP upgrade in progress detected."
                break
            else:
                result = "PASS"
                details = "No WCP upgrade in progress detected."
                break
    except Exception as e:
        logger.debug(f"ERROR: Failed to check for ongoing upgrades: {e}")
        result = "FAIL"
        details = f"Failed to check for ongoing upgrades: {e}"

    logger.debug(f"INFO: VKS WCP Ongoing Upgrade Check completed with result: {result}")
    return {"title": title, "result": result, "details": details}

def vks_wcp_supervisor_deployment_stuck_check():
    """
    Check wcpsvc.log on vCenter for Supervisor deployment stuck at
    'Installed and Started Kubernetes Node Agent' (KB 393663).
    Log path: /var/log/vmware/wcp/wcpsvc.log on vCenter where VDT runs.
    """
    logger.debug("INFO: Running VKS WCP Supervisor Deployment Stuck Check")
    title = "VKS WCP Supervisor Deployment Stuck Check"
    result = "PASS"
    details = ""

    wcpsvc_log = "/var/log/vmware/wcp/wcpsvc.log"
    keyword = "incompatible with hosts"

    try:
        out = run_command(
            ["grep", keyword, wcpsvc_log],
            log_command=False,
        )
        if out is None:
            details = "Could not read wcpsvc.log (VDT may not run on vCenter)."
            logger.debug("WARNING: Could not grep wcpsvc.log")
            return {"title": title, "result": "PASS", "details": details}
        text = out.decode("utf-8", errors="replace") if isinstance(out, bytes) else str(out)
        if keyword in text and text.strip():
            result = "WARN"
            details = (
                "wcpsvc.log contains 'incompatible with hosts' (Solution specification). "
                "Supervisor deployment may be stuck at 'Installed and Started Kubernetes Node Agent'. "
                "Ensure ESXi hosts are in compliance with vSphere Lifecycle Manager. "
                "Refer to KB https://knowledge.broadcom.com/external/article/393663"
            )
        else:
            details = "No incompatible-with-hosts errors in wcpsvc.log."
    except Exception as e:
        logger.debug("ERROR: Failed to check wcpsvc.log: %s", e)
        details = f"Could not check wcpsvc.log: {e}. Refer to KB https://knowledge.broadcom.com/external/article/393663"
        result = "WARN"

    logger.debug("INFO: VKS WCP Supervisor Deployment Stuck Check completed: %s", result)
    return {"title": title, "result": result, "details": details}


def main():
    # Run all checks
    vks_wcp_pending_upgrade()
if __name__ == "__main__":
    main()