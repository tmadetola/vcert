import os, sys
import configparser
import ast
from . import vks_defaults
vks_defaults.setDefaults()

defaults_conf_file = os.path.join(os.path.dirname(__file__), 'defaults.ini')

config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
config.read(defaults_conf_file)

pnid = config.get('defaults', 'pnid')
httpsPort = int(config.get('defaults', 'httpsPort'))
sso_domain = config.get('defaults', 'sso_domain')
timeout = 20
retries = 3
vc_version = config.get('defaults', 'version')
vc_build = config.get('defaults', 'build')
service_status = ast.literal_eval(config.get('defaults', 'service_status'))
hostname = config.get('defaults', 'hostname')