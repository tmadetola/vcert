import json
import requests
import urllib3
import sys
from sddc_manager.sddc_cfg.current_defaults import ssoAdmin
from sddc_manager.sddc_lib.authUtils import gen_token_sddc, sso_prompt
from sddc_manager.sddc_lib.commandUtils import run_psql_command
import logging
from requests.auth import HTTPBasicAuth

logger = logging.getLogger(__name__)

'''TODO: increase timeout to 15'''

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def api_requests(access_token,api_url):
    header = {'Authorization': f'Bearer {access_token}'}
    try:
        response = requests.get(api_url, headers=header, verify=False)
        return json.loads(response.text)
    
    except (requests.exceptions.RequestException, json.JSONDecodeError) as e:
        print(f"Error making the request or parsing JSON: {e}")
        return [] 


def get_sso_credentials(access_token):
    """
    Fetches credentials and filters for SSO accounts with non-null secrets.
    """
    api_url = "https://localhost/v1/system/credentials/service"
    header = {'Authorization': f'Bearer {access_token}'}
    sso_accounts = []
    
    for entry in api_requests(access_token, api_url=api_url):
        # Check if it's an SSO credential and has a secret
        if entry.get("credentialType") == "SSO" and entry.get("secret"):
            entityId = entry.get("entityId")
            serviceId = entry.get("serviceId")
            username = entry.get("username")
            password = entry.get("secret")  
            targetType = entry.get("targetType")
            
        
            sso_accounts.append({
                'entityId': entityId,
                'serviceId': serviceId,
                'username': username,
                'password': password,
                'targetType': targetType
            })
    
    #print (sso_accounts)
    return sso_accounts


def map_credentials_to_resources(access_token, sso_accounts):
    """
    Maps SSO accounts to their respective resources using lookup dictionaries.
    """
    vc_url = "http://localhost/inventory/vcenters"
    vx_rail_url = "http://localhost/inventory/vxmanagers"
 
    # Fetch inventory data 
    try:
        response = requests.get(vc_url, verify=False) or []
        vc_list = json.loads(response.text)
        #print (vc_list)

        response = requests.get(vx_rail_url, verify=False) or []
        vxrail_list = json.loads(response.text)
        #print (vxrail_list)
    
    except Exception as e:
        logger.debug(f"Error fetching inventory data: {e}")
        return []

    vc_lookup = {vc["id"]: vc.get("hostName") for vc in vc_list}
    vxrail_lookup = {vx["id"]: vx.get("hostName") for vx in vxrail_list}
    

    mapped_accounts = []

    for account in sso_accounts:
        entity_id = account.get("entityId")
        service_id = account.get("serviceId")
        targetType = account.get("targetType")

        resource_name = None

        if targetType == "VCENTER":
            resource_name = vc_lookup.get(entity_id)  # Lookup using entityId

        elif targetType == "VXRAIL_MANAGER":
            resource_name = vxrail_lookup.get(service_id)  # Lookup using serviceId

        if resource_name:
            mapped_accounts.append({
                "resourceName": resource_name,
                "username": account["username"],
                "password": account["password"],
                "targetType": targetType
            })
    #print (mapped_accounts)
    return mapped_accounts
    

def authenticate_to_resource(resourceName, username, password, targetType):
    """
    Attempts authentication to the specified resource based on its type.
    """
    headers = {
        "Content-Type": "application/json"
    }

    if targetType == "VCENTER":
        url = f"https://{resourceName}/rest/com/vmware/cis/session"
        try:
            response = requests.post(url, auth=(username, password), headers=headers, verify=False)
            if response.status_code == 200:
                return True, f"Authentication successful for {username} on vCenter {resourceName}"
            else:
                return False, f"Authentication failed for {username} on vCenter {resourceName}: {response.status_code}"
        except requests.exceptions.RequestException as e:
            return False, f"Error connecting to vCenter {resourceName}: {e}"

    elif targetType == "VXRAIL_MANAGER":
        url = f"https://{resourceName}/rest/vxm/private/v1/system"
        try:
            response = requests.get(url, auth=(username, password), verify=False)
            if response.status_code == 200:
                return True, f"Authentication successful for {username} on VxRail Manager {resourceName}"
            else:
                return False, f"Authentication failed for {username} on VxRail Manager {resourceName}: {response.status_code}"
        except requests.exceptions.RequestException as e:
            return False, f"Error connecting to VxRail Manager {resourceName}: {e}"

    else:
        return False, f"Unsupported resource type: {targetType}"


def main(username, password):
    """
    Runs the authentication check for all mapped service accounts and prints results into the VDT framework.
    """
    access_token = gen_token_sddc(username, password) 
    sso_accounts = get_sso_credentials(access_token)
    mapped_accounts = map_credentials_to_resources(access_token, sso_accounts)  # Use the mapped credentials

    pass_results = []
    fail_results = []

    #print (mapped_accounts)

    for account in mapped_accounts:
        success, message = authenticate_to_resource(account["resourceName"], account["username"], account["password"], account["targetType"])

        if success:
            logger.info(message)
        else:
            fail_results.append(message)

    # Generate test result summary
    if not fail_results:
        result = "PASS"
        resultDetails = "No authentication issues detected.\n"
        documentation = ""
        notes = ""
    else:
        result = "FAIL"
        resultDetails = "Authentication failures detected:\n" + "\n".join(fail_results)
        documentation = "https://knowledge.broadcom.com/external/article/327796"
        notes = "Please review the KB for additional troubleshooting and resolution."

    return {
        "title": "Check for disconnected service accounts on SDDC Manager",
        "result": result,
        "details": resultDetails,
        "documentation": documentation,
        "notes": notes
    }

if __name__ == "__main__":
    if len(sys.argv) > 2:
        main(sys.argv[1], sys.argv[2])
    else:
        username = ssoAdmin
        password = sso_prompt()
        main(username,password)
        