#!/usr/bin/env python

__title__ = "DISK CHECK"

import subprocess
import os
import logging

logger = logging.getLogger(__name__)

#define threshold and critical values.
threshold = 80
critical = 100

def get_df_output():
    """Run df -h and return raw output"""
    result = subprocess.run(
        ["df", "-h"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    return result.stdout.strip()

def check_disk_space(exclusion=None):
    """
    Returns:
      0 = OK
      1 = WARN (>= 80%)
      2 = CRITICAL (100%)
    """
    if exclusion is None:
        exclusion = []

    df_output = get_df_output()
    lines = df_output.splitlines()[1:]  

    status = 0

    for line in lines:
        parts = line.split()
        filesystem, useage, mount = parts[0], parts[4], parts[5]

        #check for any exclusions in filesystem or mount
        if any(excluded in filesystem or excluded in mount for excluded in exclusion):
            continue

        usage = int(useage.rstrip('%'))

        #if usage = 100% throw ERROR
        if usage == critical:
            return 2
        #if usage >=80 throw WARN
        elif usage >= threshold:
            status = 1

    return status

def disk():
    exclusion = []
    df_output = get_df_output()
    status = check_disk_space(exclusion)

    if status == 0:
        diskCheck = {
            "title": "Checking filesystem for space utilization",
            "result": "PASS",
            "details": df_output+"\n",
            "notes": "Files systems are below 80% utilization"
        }

    elif status == 1:
        diskCheck = {
            "title": "Checking filesystem for space utilization",
            "result": "WARN",
            "details": df_output+"\n",
            "notes": "One or more filesystems are above 80% utilization."
        }

    else:  # status == 2
        diskCheck = {
            "title": "Checking filesystem for space utilization",
            "result": "FAIL",
            "details": df_output+"\n",
            "notes": "CRITICAL: One or more filesystems are at 100% utilization. Immediate action required."
        }

    return diskCheck