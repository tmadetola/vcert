#!/usr/bin/env python
"""
__author__ =  ["Steve Barrett"]
__credits__ = ["Tyler FitzGerald"]

"""
import logging
import os
import stat
from pathlib import Path

logger = logging.getLogger(__name__)


def check_nfs_mount(folder_info: dict):

    
    path_str = folder_info['path']
    expected_perms_str = folder_info['perms_str']
    expected_owner = folder_info['owner']
    expected_group = folder_info['group']

    title = path_str
    result = 'PASS'
    details = ''
    documentation = ''
    
    logger.info(f"Checking path: {path_str}")
    try:
        path = Path(path_str)
        if not path.exists():
            result = 'FAIL'
            logger.debug(f"Path not found: {path_str}")
            details = f"Path not found: {path_str}"
        else:
            st = os.stat(path_str)
            actual_perms_str = stat.filemode(st.st_mode)
            actual_owner = path.owner()
            actual_group = path.group()

            current_status = f"\n\tPermissions: {actual_perms_str}\n\tOwner: {actual_owner}\n\tGroup: {actual_group}"
            
            is_pass = (actual_perms_str == expected_perms_str and
                        actual_owner == expected_owner and
                        actual_group == expected_group)

            if is_pass:
                logger.info(f"Check passed for {path_str}")
                details = f"{current_status}"

            else:
                result = 'FAIL'
                expected_status = f"\n\tPermissions: {expected_perms_str}\n\tOwner: {expected_owner}\n\tGroup: {expected_group}"
                details =  f"Expected: {expected_status} \nFound: {current_status}"

    except Exception as e:
        result = 'FAIL'
        logger.debug(f"Error checking {path_str}: {e}")
        details = f"Error checking {path_str}: {e}"

    if result == 'FAIL':
        documentation = "https://knowledge.broadcom.com/external/article/392923"
    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}

def check_nfs_ownership_permissions():
    """
    Checks the ownership and permissions of specified NFS mount paths.
    """
    logger.info("Starting NFS mount permission and ownership check.")
    title = "Check NFS Mount Permissions and Ownership"
    result = 'PASS'
    checks = []
    passed_checks = {'subheading': 'Passed Checks', 'checks': []}
    failed_checks = {'subheading': 'Failed Checks', 'checks': []}


    folders_to_check = [
        {'path': '/nfs/vmware/vcf/nfs-mount/bundle/depot/local/', 'perms_str': 'drwxr-xr-x', 'owner': 'vcf_lcm', 'group': 'vcf'},
        {'path': '/nfs/vmware/vcf/nfs-mount/bundle/depot/', 'perms_str': 'drwxr-xr-x', 'owner': 'vcf_lcm', 'group': 'vcf'},
        {'path': '/nfs/vmware/vcf/nfs-mount/bundle/', 'perms_str': 'drwxrwxr-x', 'owner': 'vcf_lcm', 'group': 'vcf'},
        {'path': '/nfs/vmware/vcf/nfs-mount/', 'perms_str': 'drwxrwxr-x', 'owner': 'root', 'group': 'vcf'},
        {'path': '/nfs/vmware/vcf/', 'perms_str': 'drwxr-xr-x', 'owner': 'root', 'group': 'root'}
    ]

    for folder_info in folders_to_check:
        check_result = check_nfs_mount(folder_info)
        if check_result['result'] == 'PASS':
            passed_checks['checks'].append(check_result)
        else:
            failed_checks['checks'].append(check_result)
            
    details = ""
    if len(failed_checks['checks']) > 0:
       checks.append(failed_checks)
    
    if len(passed_checks['checks']) > 0:
        checks.append(passed_checks)

    return {
        "subheading": title,
        "checks": checks
    }
