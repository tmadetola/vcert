#!/usr/bin/env python
"""
__author__ =  ["Laraib Kazi", "Tyler FitzGerald", "Keenan Matheny"]
__credits__ = ["Keenan Matheny"]

"""

from sddc_manager.sddc_lib.commandUtils import run_psql_command
import logging

logger = logging.getLogger(__name__)

def pantheonBundle(): 
    """
    Checks if Pantheon bundle exists in LCM DB. 

    Args:
        None

    Returns:
        dict: Result of the Pantheon Bundle Check
    """
    query = "SELECT bundle_id FROM upgrade WHERE upgrade_id IN (SELECT upgrade_id FROM upgrade_element WHERE resource_type='MULTI_SITE_SERVICE');"
    bundle_ids = (run_psql_command('lcm', query))

    
    count = len(bundle_ids)
    if count > 0:
        result = 'WARN'
        details = f'{count} Pantheon bundle(s) found in LCM DB'
        documentation = 'https://knowledge.broadcom.com/external/article/327200'
        notes = 'Please reference the KB above to clear out the Pantheon bundles.'

    else:
        result = 'PASS'
        details = f'No Pantheon bundles found in LCM.'
        documentation = ''
        notes = ''
    
    return {"title":'Check for Pantheon Bundles in LCM',
            "result":result, "details":details, "documentation":documentation, "notes":notes}