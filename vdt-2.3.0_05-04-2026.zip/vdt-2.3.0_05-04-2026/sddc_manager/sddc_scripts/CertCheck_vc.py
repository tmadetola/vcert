#!/usr/bin/env python
"""
__author__ =  ["Laraib Kazi", "Tyler FitzGerald", "Keenan Matheny"]
__credits__ = ["Keenan Matheny", "Christopher Morrow", "Fouad Sethna", "Kevin Hagopian"]

"""

import sys
import requests
import logging
from sddc_manager.sddc_cfg.current_defaults import ssoAdmin, commonsvcsCerts, alternativeJreCerts, vcList
from sddc_manager.sddc_lib.certUtils import *
from sddc_manager.sddc_lib.authUtils import get_session_token, sso_prompt

logger = logging.getLogger(__name__)

def getVcTrustedRoots(vcenter, session_token):
    """
    Gets list of 'chain ids' for all entries in Trusted Roots
    Store of the vCenter Server

    Args:
        vcenter (str): FQDN of the vCenter
        session_token (str): API Session token for the vCenter

    Returns:
        trustedCerts (list): List of the Trusted Root Certificates
    """
    rootChainIds = []
    api_url = f'https://{vcenter}/api/vcenter/certificate-management/vcenter/trusted-root-chains'
    headers = {'vmware-api-session-id': session_token}
    response = requests.get(api_url, headers=headers, verify=False)
    for element in response.json():
        rootChainIds.append(element["chain"])
    
    # Gets list of certificates for each entry in 'chain ids'
    trustedCerts = []
    for chain in rootChainIds:
        api_url = f'https://{vcenter}/api/vcenter/certificate-management/vcenter/trusted-root-chains/{chain}'
        headers = {'vmware-api-session-id': session_token}
        response = requests.get(api_url, headers=headers, verify=False)
        output = response.json()["cert_chain"]
        splitOutput = output["cert_chain"][0].split('\n')
        trustedCert = '-----BEGIN CERTIFICATE-----\n'
        for line in splitOutput:
            if line.startswith('-----BEGIN CERTIFICATE-----'):
                printing = True
                continue
            elif line.startswith('-----END CERTIFICATE-----'):
                printing = False
                break
            if printing:
                trustedCert = trustedCert + line + '\n'
        trustedCert = trustedCert + '-----END CERTIFICATE-----'

        trustedCerts.append(trustedCert)
        
    return trustedCerts

def validate_chain(cert, roots):
    chain = b""  # Initialize chain as bytes
    parsed_cert = Cert(cert.encode("utf-8"))  # Encode certs utf-8
    ca_chain = []

    if not parsed_cert.subjectkey:
        raise Exception(f"Certificate: {parsed_cert.subject} doesn't have a subject key!")

    while True:
        chain += cert.encode("utf-8")  # Encode certs utf-8
        parsed_cert = Cert(cert.encode("utf-8"))  # Cert input as bytes

        if not parsed_cert.authkey:
            break

        elif "\n" in parsed_cert.authkey:
            cert_authkey = parsed_cert.authkey.split()[0].split(":", 1)[1].strip().encode("utf-8")  # Convert to bytes

        else:
            cert_authkey = parsed_cert.authkey.encode("utf-8")  # Convert to bytes

        if cert_authkey and parsed_cert.subjectkey.encode("utf-8") != cert_authkey:
            match = False
            for root_cert in roots:
                if Cert(root_cert.encode("utf-8")).subjectkey.strip().encode("utf-8") == cert_authkey:
                    match = True
                    ca_chain.append(root_cert.encode("utf-8"))
                    cert = root_cert
                else:
                    continue

            if not match:
                raise Exception("No match found!")

        else:
            break

    return chain, ca_chain


def main(username, password):
    """
    Checks the certificate status (Trust, expiration, SAN) for
    all vCenters in VCF Inventory

    Args:
        username (str): SSO Admin Username
        password (str): SSO Admin password

    Returns:
        result (dict): Result of the Certificate Status Check
    """    
    results = []
    
    for vc in vcList:
        try:
            # Get VC API Token
            status, token = get_session_token(vc["hostname"], username, password)
            
            # Get VC Cert on Port 443
            vcCert = getSslCert(vc["hostname"], '443')
            vcCertObj = Cert(vcCert)
            
            # Validate certificate chain
            chain, ca_chain = validate_chain(vcCert, getVcTrustedRoots(vc['hostname'], token))
            
            # Initialize list to store trust check results for multiple certificates
            rootTrustChecks = []

            # Check each certificate in the CA chain
            for cert in ca_chain:
                ca_chain_obj = Cert(cert)
                rootTrustCheck = vcSddcTrustCheck(commonsvcsCerts, alternativeJreCerts, ca_chain_obj)
                rootTrustChecks.append(rootTrustCheck)  # Store each result

        except Exception as e:
            print(f"Error processing {vc['hostname']}: {e}")
            continue

        # Check if the Cert is expiring:
        expResult = checkCert(vcCert).expCheck()
        expCheck = {"title": "Expiration Check", "result": expResult["status"], "details": expResult["details"]}

        # SAN Check for Cert:
        sanResult = checkCert(vcCert, vc["hostname"], vc["ip"]).sanCheck()
        sanCheck = {"title": "Subject Alternative Name Check", "result": sanResult["status"], "details": sanResult["details"]}

        # Combine results
        checks = rootTrustChecks + [expCheck, sanCheck]
        results.append({'subheading': f'{vc["hostname"]}', 'checks': checks})
    
    return results  # Return the full results

    
if __name__ == '__main__':
    if len(sys.argv) > 2:
        main(sys.argv[1], sys.argv[2])
    else:
        username = ssoAdmin
        password = sso_prompt()
        main(username,password)
    