#!/usr/bin/env python
"""
__author__ =  ["Laraib Kazi", "Tyler FitzGerald", "Keenan Matheny"]
__credits__ = ["Keenan Matheny"]

"""

from sddc_manager.sddc_lib.commandUtils import run_psql_command
from sddc_manager.sddc_cfg.current_defaults import sddcVersion
import logging

logger = logging.getLogger(__name__)

def manifestCount(): 
    """
    Checks the number of Manifest Files found in the SDDC Manager
    LCM DB.

    Args:
        None

    Returns:
        dict: Result of the Manifest File Count Check
    """
    query = "select count(*) from manifest"
    count = int(run_psql_command('lcm', query))

    
    if count > 1:
        result = 'WARN'
        details = f'{count} Manifest files found in LCM DB.'
        documentation = 'https://knowledge.broadcom.com/external/article/327217'
        notes = 'Please reference the KB above to clear out the extra manifest files.'
    elif count == 0:
        result = 'WARN'
        details = f'{count} Manifest files found in LCM DB.'
        documentation = ''
        notes = ''
    else:
        result = 'PASS'
        details = f'{count} Manifest file found in LCM DB.'
        documentation = ''
        notes = ''
    
    return {"title":'Check number of LCM Manifest Files in the DB',
            "result":result, "details":details, "documentation":documentation, "notes":notes}