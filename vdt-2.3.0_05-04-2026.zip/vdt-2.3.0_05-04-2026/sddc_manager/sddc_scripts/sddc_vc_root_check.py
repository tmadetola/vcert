import re
import textwrap
import json
import requests
import urllib3
import sys
import paramiko
from sddc_manager.sddc_cfg.current_defaults import ssoAdmin
from sddc_manager.sddc_lib.authUtils import gen_token_sddc, sso_prompt
import logging

logger = logging.getLogger(__name__)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

known_hosts = "/etc/vmware/vcf/commonsvcs/known_hosts"


def api_requests(access_token, api_url):
    header = {'Authorization': f'Bearer {access_token}'}
    try:
        response = requests.get(api_url, headers=header, verify=False)
        return json.loads(response.text)
    except (requests.exceptions.RequestException, json.JSONDecodeError) as e:
        print(f"Error making the request or parsing JSON: {e}")
        return []


def get_sso_credentials(access_token):
    """
    Fetches credentials and filters for root vCenter accounts with non-null secrets.
    """
    api_url = "https://localhost/v1/system/credentials"
    vc_root_info = []

    for entry in api_requests(access_token, api_url=api_url):
        if entry.get("username") == "root" and entry.get("entityType") == "VCENTER":
            vc_root_info.append({
                'entityId': entry.get("entityId"),
                'username': entry.get("username"),
                'password': entry.get("secret")
            })

    return vc_root_info


def map_credentials_to_resources(access_token, vc_root_info):
    """
    Maps root credentials to vCenter hostnames using the inventory.
    """
    vc_url = "http://localhost/inventory/vcenters"

    try:
        response = requests.get(vc_url, verify=False)
        vc_list = json.loads(response.text)
    except Exception as e:
        logger.debug(f"Error fetching inventory data: {e}")
        return []

    vc_lookup = {vc["id"]: vc.get("hostName") for vc in vc_list}

    mapped_accounts = []
    for account in vc_root_info:
        resource_name = vc_lookup.get(account.get("entityId"))
        if resource_name:
            mapped_accounts.append({
                "resourceName": resource_name,
                "username": account["username"],
                "password": account["password"],
            })

    return mapped_accounts


def authenticate_to_resource(resourceName, username, password):
    """
    Attempts SSH authentication to the vCenter appliance to check root password.
    Validates the host key against the VCF known_hosts file before authenticating.
    Opens a session and immediately closes it — no commands are executed via SSH.
    """
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.RejectPolicy())

    try:
        ssh.load_host_keys(known_hosts)
    except FileNotFoundError:
        return False, f"Known hosts file not found at {known_hosts}", \
            "https://knowledge.broadcom.com/external/article/316028", \
            "Please review the KB to update host keys on SDDC Manager"
    except Exception as e:
        return False, f"Error loading known hosts file: {e}", \
            "https://knowledge.broadcom.com/external/article/316028", \
            "Please review the KB to update host keys on SDDC Manager"

    try:
        ssh.connect(
            hostname=resourceName,
            username=username,
            password=password,
            timeout=10,
            allow_agent=False,
            look_for_keys=False,
            disabled_algorithms={
                # Only negotiate key types present in the VCF known_hosts file.
                # Prefer ecdsa-sha2-nistp256; keep ssh-rsa as fallback.
                # Disabling rsa-sha2-* variants prevents paramiko from upgrading
                # to a signature scheme that won't match the known_hosts entry.
                'keys': ['rsa-sha2-256', 'rsa-sha2-512', 'ssh-ed25519']
            }
        )
        ssh.close()
        return True, f"Authentication successful for {username} on vCenter {resourceName}", None, None

    except paramiko.AuthenticationException:
        return False, f"Authentication failed for {username} on vCenter {resourceName}: invalid credentials", \
            "https://knowledge.broadcom.com/external/article/305970", \
            "Please check that the vCenter root password matches the vCenter root password in SDDC Manager locker"

    except paramiko.SSHException as e:
        host_key_indicators = ["not found in known_hosts", "host key mismatch", "Invalid host key", "does not match"]
        if any(indicator in str(e) for indicator in host_key_indicators):
            match = re.search(r"got '([^']+)', expected '([^']+)'", str(e))
            if match:
                got_key, expected_key = match.group(1), match.group(2)
                indent = "                    "
                got_wrapped = textwrap.fill(got_key, width=60,
                                            initial_indent="Got:      ",
                                            subsequent_indent="          ")
                expected_wrapped = textwrap.fill(expected_key, width=60,
                                                 initial_indent="Expected: ",
                                                 subsequent_indent="          ")
                message = (
                    "Host key verification failed for vCenter " + resourceName + ":\n" +
                    got_wrapped + "\n" +
                    expected_wrapped
                )
            else:
                message = "Host key verification failed for vCenter " + resourceName + ": " + str(e)
            return False, message, \
                "https://knowledge.broadcom.com/external/article/316028", \
                "Please review the KB to update host keys on SDDC Manager"
        return False, f"SSH error connecting to vCenter {resourceName}: {e}", None, None

    except Exception as e:
        return False, f"Error connecting to vCenter {resourceName}: {e}", None, None


def main(username, password):
    """
    Runs the SSH credential check for all vCenters in SDDC inventory
    """
    access_token = gen_token_sddc(username, password)
    vc_root_info = get_sso_credentials(access_token)
    mapped_accounts = map_credentials_to_resources(access_token, vc_root_info)

    pass_results = []
    fail_results = []

    for account in mapped_accounts:
        success, message, doc, notes = authenticate_to_resource(
            account["resourceName"],
            account["username"],
            account["password"]
        )
        if success:
            logger.info(message)
            pass_results.append(message)
        else:
            logger.warning(message)
            fail_results.append({
                "message": message,
                "documentation": doc,
                "notes": notes
            })

    if not fail_results:
        result = "PASS"
        resultDetails = "vCenter root passwords match.\n"
        documentation = ""
        result_notes = ""
    else:
        result = "FAIL"
        detail_blocks = ["Authentication failures detected:\n"]
        for failure in fail_results:
            block = failure["message"]
            if failure["documentation"]:
                block += f"\nDocumentation:  {failure['documentation']}"
            if failure["notes"]:
                block += f"\nNotes: {failure['notes']}"
            detail_blocks.append(block)
        resultDetails = "\n\n".join(detail_blocks)
        documentation = ""
        result_notes = ""

    return {
        "title": "Check vCenter root credentials from SDDC Manager",
        "result": result,
        "details": resultDetails,
        "documentation": documentation,
        "notes": result_notes
    }


if __name__ == "__main__":
    if len(sys.argv) > 2:
        main(sys.argv[1], sys.argv[2])
    else:
        username = ssoAdmin
        password = sso_prompt()
        main(username, password)