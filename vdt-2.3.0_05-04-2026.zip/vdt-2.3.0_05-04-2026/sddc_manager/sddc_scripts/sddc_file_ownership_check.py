#!/usr/bin/env python
"""
__author__ =  ["Steve Barrett"]
__credits__ = ["Tyler FitzGerald"]

"""
import logging
from pathlib import Path
from lib.vdt_base import Base

logger = logging.getLogger(__name__)

CYELLOW = '\033[93m'
CEND = '\033[0m'

def check_file_ownership(service_info: dict, prop_file: str):
    """
    Checks the ownership of a single service properties file.
    """
    base_path = "/etc/vmware/vcf/"
    full_path = f'{base_path}{service_info["service"]}/{prop_file}'
    expected_owner = service_info["owner"]
    expected_group = service_info["group"]

    title = f'Ownership for {full_path}'
    result = 'PASS'
    details = ''
    documentation = ''

    try:
        path = Path(full_path)
        if not path.exists():
            logger.info(f'File not found, skipping: {full_path}')
            # Not a failure, as some files may not exist by design.
            return None

        actual_owner = path.owner()
        actual_group = path.group()

        current_status = f"\n\tOwner: {actual_owner}\n\tGroup: {actual_group}"

        is_pass = (actual_owner == expected_owner and actual_group == expected_group)

        if is_pass:
            logger.info(f"Check passed for {full_path}")
            details = f"{current_status}"
        else:
            result = 'FAIL'
            expected_status = f"\n\tOwner: {expected_owner}\n\tGroup: {expected_group}"
            details = f"Expected: {expected_status} \nFound: {current_status}"
            documentation = f'https://knowledge.broadcom.com/external/article/385592\n'

    except Exception as e:
        result = 'FAIL'
        logger.debug(f"Error checking {full_path}: {e}")
        details = f"Error checking {full_path}: {e}"

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}


## Service file ownership checks
def permission_ownership_check():
    """
    Checks the ownership of service properties files.
    """
    logger.info("Starting service file ownership check.")
    title = 'Check Service Properties file ownership'
    checks = []
    passed_checks = {'subheading': 'Passed Checks', 'checks': []}
    failed_checks = {'subheading': 'Failed Checks', 'checks': []}

    services_to_check = [
        {
            "service": "domainmanager",
            "owner": "vcf_domainmanager",
            "group": "vcf"
        },
        {
            "service": "operationsmanager",
            "owner": "vcf_operationsmanager",
            "group": "vcf"
        }
    ]

    property_files = ["application.properties", "application.prod.properties"]

    for service_info in services_to_check:
        for prop_file in property_files:
            check_result = check_file_ownership(service_info, prop_file)
            if check_result:
                if check_result['result'] == 'PASS':
                    passed_checks['checks'].append(check_result)
                else:
                    failed_checks['checks'].append(check_result)

    if failed_checks['checks']:
        checks.append(failed_checks)

    if passed_checks['checks']:
        checks.append(passed_checks)

    return {
        "subheading": title,
        "checks": checks
    }

def main():
    return permission_ownership_check()

if __name__ == '__main__':
    main()


