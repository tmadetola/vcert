import sys, os
import urllib.parse as urlparse
import requests
import re
import logging
import json
import ssl
from ssl import SSLError
import socket
import time
import traceback
import certifi
from OpenSSL import SSL
from OpenSSL.crypto import dump_certificate, FILETYPE_PEM
from sddc_manager.sddc_lib.certUtils import getSslCert, Cert
from sddc_manager.sddc_cfg.current_defaults import sddcVersion, ca_pem_file
from sddc_manager.sddc_lib.authUtils import gen_token_sddc
timeout = 2
logger = logging.getLogger(__name__)
logging.getLogger('urllib3').setLevel(logging.WARNING)

CONFIG_PATH = "/opt/vmware/vcf/lcm/lcm-app/conf/application-prod.properties"
BC_DL_URL = "dl.broadcom.com"
KB_CONFIG_INSTRUCTIONS = "https://knowledge.broadcom.com/external/article/390098"

EXPECTED_VALUES = {
    "lcm.depot.adapter.host": "dl.broadcom.com",
    "lcm.depot.adapter.remote.repoDir": "/COMP/SDDC_MANAGER_VCF",
    "lcm.depot.adapter.remote.lcmManifestDir": "/COMP/SDDC_MANAGER_VCF/lcm/manifest",
    "lcm.depot.adapter.remote.lcmProductVersionCatalogDir": "/COMP/SDDC_MANAGER_VCF/lcm/productVersionCatalog"
}

if sddcVersion.startswith('9'): 
    ROOTDIR_KEY = "lcm.depot.adapter.remote.v2.rootDir"
else:
    ROOTDIR_KEY = "lcm.depot.adapter.remote.rootDir"


class CheckConnect(object):

    """
    A class for checking connectivity to a host on specific ports.

    Attributes:
        retry (int): The number of times to retry the connection check.
        delay (int): The number of seconds to wait between connection attempts.
        timeout (int): The timeout value in seconds for the connection attempt.
        ip (str): The IP address of the host to check.
        ports (list or int): The list of ports to check or a single port number.
        ptype (str): The type of protocol to use for the connection check.
        init_msg (str): The initial message for the connection check.

    Methods:
        TCP(port): Checks the TCP connectivity to the specified port.
        check(): Performs the connection check for all the specified ports.
    """    
    def __init__(self, ip, ports):
        #  Spec will be yaml parameters specific to the product
        """
        Initialize a PortChecker object.

        Args:
            ip (str): The IP address of the host to perform port checks on.
            ports (int or list): The port or list of ports to check on the host.

        Attributes:
            retry (int): The number of times to retry a failed port check.
            delay (int): The delay in seconds between retries.
            timeout (int): The timeout in seconds for each port check.
            ip (str): The IP address of the host to perform port checks on.
            ports (list): A list of ports to check on the host.
            ptype (str): The type of port check to perform.
            init_msg (str): The initialization message for the PortChecker object.
        """        
        self.retry = 1
        self.delay = 1
        self.timeout = 2
        self.ip = ip
        if isinstance(ports, int):
            self.ports = [ports]
        if isinstance(ports, list):
            self.ports = ports
        self.ptype = "TCP"

        self.init_msg = "Port check for host %s" % self.ip

    def TCP(self, port):
        """
        Test TCP connection on a specified port.

        Args:
            port (int): The port number to test the TCP connection.

        Returns:
            tuple: A tuple containing the return code (0 if successful, 1 if failed) and a message describing the test result.
        """        
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(self.timeout)
        rc = 1
        try:
            response = s.connect((self.ip, int(port)))
            s.shutdown(socket.SHUT_RDWR)
            s.close()
            result = "tcp port test returned %s" % response
            logger.debug(result)
            rc = 0
        except Exception as e:
            result = "tcp port test failed. error was: %s" % e
            logger.debug(result)
        return rc, result

    def check(self):
        """
        Performs a TCP check on a list of ports.

        Returns a tuple of a success flag and a dictionary containing the result of each port check.

        Args:
            self: An instance of the class that this method is a part of.

        Returns:
            tuple: A tuple containing a boolean indicating whether all the checks were successful, and a dictionary that maps each checked port to its result ('success' or 'failed').
        """        
        output = {}
        success = True
        for port in self.ports:
            listening = False
            for attempt in range(self.retry):
                rc, result = self.TCP(port)
                if rc == 0:
                    listening = True
                    break
                else:
                    time.sleep(self.delay)
            if listening:
                output[str(port)] = "success"
            else:
                output[str(port)] = "failed"
                success = False
        return success, output
    
def get_proxy_details():
    enabled = False
    proxy_url = None
    proxies = {}
    api_url = 'http://localhost/inventory/proxy-configuration'
    headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
    logger.info(f'Attempting GET API Call with URL {api_url}')

    try:
        response = requests.get(api_url, headers=headers, verify=False, timeout=5)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException as e:
        logger.debug(f"Failed to retrieve proxy details: {e}")
        return {}, False

    if data.get("isConfigured") and data.get("isEnabled"):
        enabled = True
        protocol = data.get("transferProtocol").lower()
        host = data.get("host")
        port = data.get("port")
        proxy_url = f"{protocol}://{host}:{port}"

    if proxy_url:
        proxies = {
            "http": proxy_url,
            "https": proxy_url
        }

    return proxies, enabled

def proxy_config():
    title = 'LCM Proxy Configuration'
    details = ''
    result = 'INFO'

    proxy_details, enabled = get_proxy_details()
    proxies = []
    proxy_configured = False

    for x, y in proxy_details.items():
        if y:
            proxies.append(f"{x}: {y}")
            proxy_configured = True

    proxy_output = '\n'.join(proxies)

    if proxy_configured and enabled:
        details += f"Proxy is configured and enabled.\nProxy URL(s): {proxy_output}"
    elif proxy_configured:
        details += f"Proxy {proxy_output} is configured but NOT enabled."
    else:
        details += "No Proxy configured for LCM service."

    return {"title": title, "result": result, "details": details}


def get_depot_url_check():
    result = "PASS"
    title = "Depot URL Configuration"
    documentation = ""
    details = ""

    token = None
    matched = 0
    expected_total = 5

    logger.debug(f"Reading config from {CONFIG_PATH}")
    if not os.path.exists(CONFIG_PATH):
        result = "FAIL"
        details = f"Configuration file not found: {CONFIG_PATH}"
        return {'title': title, 'result': result, 'details': details, 'documentation': KB_CONFIG_INSTRUCTIONS}, None

    with open(CONFIG_PATH, 'r') as f:
        lines = [line.strip() for line in f if '=' in line and not line.strip().startswith("#")]
    config = dict(line.split('=', 1) for line in lines)

    logger.debug(f"Parsed config: {config}")

    #Store incorrect values
    incorrect_values = []

    # Check static keys
    for key, expected in EXPECTED_VALUES.items():
        actual = config.get(key)
        if actual == expected:
            logger.debug(f"[MATCH] {key} = {actual}")
            matched += 1
        else:
            logger.debug(f"[MISMATCH] {key} = actual: {actual}, expected: {expected}")
            incorrect_values.append(f"{key} = {actual}, expected: {expected}")

    # Check for token value
    token_path = config.get(ROOTDIR_KEY)

    if token_path:
        match = re.match(r"^/([^/]+)/PROD$", token_path)
        if match:
            token = match.group(1)
            logger.debug(f"[MATCH] {ROOTDIR_KEY} contains token: {token}")
            matched += 1
        else:
            logger.debug(f"[MISMATCH] {ROOTDIR_KEY} = {token_path} (does not match /TOKEN/PROD format)")
            incorrect_values.append(f"{ROOTDIR_KEY} = {token_path} (does not match /TOKEN/PROD format)")
    else:
        logger.debug(f"[MISSING] {ROOTDIR_KEY} not found")
        incorrect_values.append(f"{ROOTDIR_KEY} not found")

    if matched != expected_total:
        result = "FAIL"
        documentation = "https://knowledge.broadcom.com/external/article/389871"
        details = f"{matched}/{expected_total} expected values found in {CONFIG_PATH}\n" + "\n".join(incorrect_values)

    else:
        details = "All expected configuration values are present."

    return {'title': title, 'result': result, 'details': details, 'documentation': documentation}, token

def verify_cb(conn, cert, errun, depth, ok):
        return True

def proxy_configured(proxies):
    for x,y in proxies.items():
        if y:
            return True
        
    return False

def transparent_proxy_cert_verify():
    hostname = urlparse.urlparse(BC_DL_URL).hostname
    conn = ssl.create_connection((hostname, 443))
    context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    sock = context.wrap_socket(conn, server_hostname=hostname)
    certificate = ssl.DER_cert_to_PEM_cert(sock.getpeercert(True))
    return certificate

def proxy_test_cert_verify(proxies):
    https_proxy = urlparse.urlparse(proxies.get('http'))
    proxy_host = https_proxy.hostname
    proxy_port = https_proxy.port
    PROXY_ADDR = (f"{proxy_host}", proxy_port)
    CONNECT = f"CONNECT {BC_DL_URL}:{443} HTTP/1.0\r\nConnection: close\r\n\r\n"
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    s.setblocking(1)
    s.connect(PROXY_ADDR)
    s.send(str.encode(CONNECT))
    s.recv(4096)

    ctx = SSL.Context(SSL.SSLv23_METHOD)
    ctx.set_verify(SSL.VERIFY_NONE, verify_cb)

    ss = SSL.Connection(ctx, s)
    ss.set_connect_state()
    ss.do_handshake()
    cert = ss.get_peer_certificate()
    ss.shutdown()
    ss.close()
    return dump_certificate(cert=cert, type=FILETYPE_PEM).decode('utf-8')

def test_url(title, url, fail_doc, token="",proxies={},verify=True):
    #print(token)
    hostname = urlparse.urlparse(url).hostname
    result = "PASS"
    documentation = ""
    details = ""
    #print(f"url: {url}, proxies: {proxies}")

    context = ssl.create_default_context()
    if not verify:
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE

    try:
        r = requests.get(url, stream=True, timeout=timeout, proxies=proxies, verify=verify)
        if r.status_code >= 200 and r.status_code < 400:
            title = f"{title} - OK"
            content = next(r.iter_content(10))
        else:
            result = "FAIL"
            title = f"{title} - ({r.status_code}:{r.reason})"
            documentation = fail_doc
            details = f""        
    
    except requests.exceptions.SSLError:
        
        if verify != ca_pem_file and verify == True:
            return test_url(title, url, fail_doc, token, proxies=proxies, verify=ca_pem_file)
        else:
            title = f"{title} - UNTRUSTED"
            
            try:
                
                if proxy_configured(proxies):
                    raw_cert = proxy_test_cert_verify(proxies)
                else:
                    raw_cert = transparent_proxy_cert_verify()
                
                cert = Cert(raw_cert)
                detected_issuer = cert.issuer
                logger.debug(f"got cert: {str(cert)}")

                details_msg = f"""
    The connection to {BC_DL_URL} is being intercepted by a security device in your network.  
    Ensure file downloads from {BC_DL_URL} are not being blocked by this device.
    Additional Info: The SSL cert issuer for {hostname} is not trusted!
    Detected issuer: {detected_issuer}
    You will likely have to manually trust the device's certificate.  see KB 316072

    """
                docu_msg = "https://knowledge.broadcom.com/external/article/316072"
                
                result = test_url(title, url, fail_doc, token=token, proxies=proxies,verify=False)
                result['result'] = "FAIL"
                result['details'] = result['details'] + details_msg
                result['documentation'] = result['documentation'] + f"\n{docu_msg}"
                return result

            except Exception as e:
                result = "FAIL"
                details = f"Unable to parse the certificate!  Error was: {e}"
    
    except requests.exceptions.ConnectTimeout as e:
        e = str(e).replace(url, hostname)
        result = "FAIL"
        details = f"Failed to connect to {hostname} due to timeout.  Please check network connectivity."

    except requests.exceptions.ConnectionError as e:
        result = "FAIL"
        e = str(e).replace(url, hostname)
        
        if "Name or service not known" in str(e):
            details = f"Connection error.  Failed to resolve {hostname} in DNS!"
        
        elif "Connection refused" in str(e):
            details = f"Connection error.  Connection to {hostname} was refused!"

        elif "Network is unreachable" in str(e):
            details = f"Connection error.  Connection to {hostname}:  Network is unreachable!"
        
        else:
            details = f"Connection error.  Error was: {e}"
   
    except Exception as e:
        e = str(e).replace(url, hostname)
        result = "FAIL"
        details = f"ERROR connecting to {hostname}!\n Error was: {e}"

    return {'title': title, 'result': result, 'details': details.replace(token, '<download token>'), 'documentation': documentation}


def check_depot_config():
    proxies, enabled = get_proxy_details()
    title = "Default Depot Configuration"
    checks = []

    if not sddcVersion.startswith('9'):

        config_check, token = get_depot_url_check()
        checks.append(config_check)

        if config_check['result'] == "PASS" and token:
            manifest_url = f"https://{BC_DL_URL}/{token}/PROD/COMP/SDDC_MANAGER_VCF/lcm/manifest/v1/lcmManifest.json"
            pvc_url = f"https://{BC_DL_URL}/{token}/PROD/COMP/SDDC_MANAGER_VCF/lcm/productVersionCatalog/v1/productVersionCatalog.json"
            checks.append({'subheading': 'Download Test', 'checks': [
                test_url("lcmManifest.json download", manifest_url, KB_CONFIG_INSTRUCTIONS, proxies=proxies, token=token),
                test_url("productVersionCatalog.json download", pvc_url, KB_CONFIG_INSTRUCTIONS, proxies=proxies, token=token)
            ]})
        elif not token:
            logger.debug("Token not found, skipping download checks.")
    else:
        checks.append({'title': "Checks skipped - Not necessary for 9.x+", 'result': 'PASS', 'details': "", 'documentation': ''})

    return {'subheading': title, 'checks': checks}
