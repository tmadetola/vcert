#!/usr/bin/env python
import logging
import requests
import urllib3

logger = logging.getLogger(__name__)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def check_commonsvcs_status():
    """
    Checks if commonsvcs is responding (API) via /about endpoint.
    Returns a simple list of checks.
    """
    # REMOVED: logger.info("Starting Common Services Health Check.") 
    
    main_title = "Common Services Health Check"
    checks = []

    api_check = {
        "title": "Commonservices is running",
        "result": "PASS",
        "details": "",
        "documentation": ""
    }

    api_url = 'http://localhost/commonsvcs/about'
    
    try:
        response = requests.get(api_url, verify=False, timeout=5)
        
        if response.status_code == 200:
            api_check["details"] = f"API endpoint {api_url} is responding (HTTP 200)."
            checks.append(api_check)
        else:
            logger.debug(f"Commonsvcs API failed. Status Code: {response.status_code}")
            api_check["title"] = "Unable to run VDT! Detected the commonsvcs service is down on the SDDC manager"
            api_check["result"] = "FAIL"
            api_check["details"] = f"API returned error code: {response.status_code}"
            api_check["documentation"] = "Please investigate /var/log/vmware/vcf/commonservices/vcf-commonsvcs.log for issues."
            checks.append(api_check)
            logger.info(f"{api_check}")
            
    except requests.exceptions.ConnectionError:
        logger.debug("Commonsvcs API Connection Refused")
        api_check["title"] = "Unable to run VDT! Detected the commonsvcs service is down on the SDDC manager"
        api_check["result"] = "FAIL"
        api_check["details"] = "API Connection Refused. Service is likely down or port 80/443 is blocked."
        api_check["documentation"] = "Please investigate /var/log/vmware/vcf/commonservices/vcf-commonsvcs.log for issues."
        checks.append(api_check)
        logger.info(f"{api_check}")

    except Exception as e:
        logger.debug(f"Commonsvcs API Exception: {e}")
        api_check["title"] = "Unable to run VDT! Detected the commonsvcs service is down on the SDDC manager"
        api_check["result"] = "FAIL"
        api_check["details"] = f"API Check Failed: {str(e)}"
        checks.append(api_check)
        logger.info(f"{api_check}")

    return {
        "title": main_title,
        "checks": checks
    }