#!/usr/bin/env python
"""
__author__ =  ["Tyler FitzGerald", "Laraib Kazi", "Keenan Matheny"]
__credits__ = ["Keenan Matheny"]

"""

from sddc_manager.sddc_lib.commandUtils import run_psql_command
from sddc_manager.sddc_cfg.current_defaults import sddcVersion
import logging

logger = logging.getLogger(__name__)

def credential_history(): 
    """
    Checks for high number of credential history. 

    Args:
        None

    Returns:
        dict: Result of the Credential History Check
    """
    query = "select count(*) from credentialhistory;"

    bundle_ids = (run_psql_command('platform', query))

    count = len(bundle_ids)
    if count > 250:
        result = 'WARN'
        details = f'{count} credential_history records were found'
        documentation = 'https://knowledge.broadcom.com/external/article/327212'
        notes = 'Please reference the KB above to clear out credential history'

    else:
        result = 'PASS'
        details = f'Expected number of credential history records.'
        documentation = ''
        notes = ''
    
    return {"title":'Check credential_history entries',
            "result":result, "details":details, "documentation":documentation, "notes":notes}