#!/usr/bin/env python3

__author__ = ["Tyler FitzGerald"]

import os
import re
import logging
from sddc_manager.sddc_cfg.current_defaults import sddcVersion

logger = logging.getLogger(__name__)
title = "SDDC /etc/hosts Check"

commented_entry_regex = re.compile(
    r"^#\s*(?:\d{1,3}(?:\.\d{1,3}){3}|[0-9a-fA-F:]+)\s+\S+"
)

header = {
    "legacy": {              
        "header": "# VAMI_EDIT_BEGIN",
        "footer": "# VAMI_EDIT_END",
        "label":  "5.2 or lower (VAMI)",
    },
    "modern": {                      
        "header": "# Begin /etc/hosts (network card version)",
        "footer": "# End /etc/hosts (network card version)",
        "label":  "5.2.1 or higher (network card version)",
    },
}

hosts_file_path = "/etc/hosts"

def hosts_file_exists_check():
    """
    Check if the /etc/hosts file exists and return its hosts_file.

    Returns:
        tuple: A dictionary with keys 'title', 'result', and 'details',
               and the file hosts_file as a string (empty string if file not found).
    """
    title = "Check if /etc/hosts file exists"
    result = "PASS"
    details = ""
    hosts_file = ""

    if not os.path.exists(hosts_file_path):
        result = "FAIL"
        details = (
            "/etc/hosts file does not exist!\n"
            "\tDocumentation: https://knowledge.broadcom.com/external/article/409862\n"
            "\tNotes:         Please ensure the /etc/hosts file exists."
        )
        return {'title': title, 'result': result, 'details': details}, hosts_file

    with open(hosts_file_path, "r") as f:
        hosts_file = f.read()

    lines = hosts_file.splitlines()
    details = "/etc/hosts hosts_file:\n\t" + "\n\t".join(lines)

    return {'title': title, 'result': result, 'details': details}, hosts_file


def hosts_format_check(hosts_file, sddcVersion):
    """
    Check the /etc/hosts file for a valid header/footer block.
    Validates that the detected format matches the expected format for the SDDC version.
        - SDDC > 5.2.0 : expects 'modern'  (# Begin/End /etc/hosts (network card version))
        - SDDC <= 5.2.0 : expects 'legacy' (# VAMI_EDIT_BEGIN / # VAMI_EDIT_END)

    Args:
        hosts_file (str):   The hosts_file of /etc/hosts from hosts_file_exists_check().
        sddcVersion (str):  The SDDC version string (e.g. '5.2.1', '5.1.0').

    Returns:
        tuple: A dictionary with keys 'title', 'result', and 'details',
               and a tuple of (detected_format, header_index, footer_index).
               detected_format will be None if no valid block was found.
    """
    title = "Check /etc/hosts format"
    result = "PASS"
    details = ""
    detected_format = None
    header_index = None  
    footer_index = None

    sddcShortVersion = int(sddcVersion.split("-")[0].replace('.',''))
    expected_format = "modern" if sddcShortVersion > 520 else "legacy"

    lines = hosts_file.splitlines()

    for fmt_name, markers in header.items():
        h = next((i for i, l in enumerate(lines) if l.strip() == markers["header"]), None)
        f = next((i for i, l in enumerate(lines) if l.strip().endswith(markers["footer"])), None) 
        if h is not None and f is not None and h < f:
            detected_format = fmt_name
            header_index = h  
            footer_index = f
            break

    if detected_format is None:
        result = "FAIL"
        details = (
            "Invalid /etc/hosts format found.\n"
            "\tExpected one of following formats:\n"
            "\t  5.2 or older : # VAMI_EDIT_BEGIN / # VAMI_EDIT_END\n"
            "\t  5.2 or higher : # Begin /etc/hosts (network card version) / # End /etc/hosts (network card version)\n"
            "\tDocumentation: https://knowledge.broadcom.com/external/article/409862\n"
            "\tNotes: Ensure /etc/hosts contains a recognized format."
        )
    elif detected_format != expected_format:
        result = "WARN"
        details = (
            f"Unexpected format for SDDC version {sddcVersion}.\n"
            f"\tDetected:  {header[detected_format]['label']}\n"
            f"\tDocumentation: https://knowledge.broadcom.com/external/article/409862\n"
            f"\tNotes: SDDC {'>' if expected_format == 'modern' else '<='} 5.2.0 "
        )
    else:
        details = (
            f"{header[detected_format]['label']} "
        )

    return {'title': title, 'result': result, 'details': details}, (detected_format, header_index, footer_index)


def hosts_commented_check(contents, detected_format, header_idx, footer_idx):
    """
    Check for commented-out host entries inside the header/footer block.

    Args:
        contents (str):        The contents of /etc/hosts from hosts_file_exists_check().
        detected_format (str): The detected format ('legacy' or 'modern') from hosts_format_check().
        header_idx (int):      Line index of the block header from hosts_format_check().
        footer_idx (int):      Line index of the block footer from hosts_format_check().

    Returns:
        dict: A dictionary with keys 'title', 'result', and 'details'.
    """
    title = "Check for commented out lines in /etc/hosts"
    result = "PASS"
    details = ""

    lines = contents.splitlines()
    block_lines = lines[header_idx + 1 : footer_idx]
    commented_hosts = [
        line for line in block_lines if commented_entry_regex.match(line.strip())
    ]

    if commented_hosts:
        count = len(commented_hosts)
        entry_word = "entry" if count == 1 else "entries"
        result = "WARN"
        details = (
            "Commented-out host entries:\n\t" +
            "\n\t".join(commented_hosts) +
            "\n\tDocumentation: https://knowledge.broadcom.com/external/article/409862\n"
            f"\tNotes: Found {count} commented-out host {entry_word} inside hosts file "
            f"Please verify entry and uncomment if needed."
        )

    return {'title': title, 'result': result, 'details': details}


def main():
    """
    Run all /etc/hosts checks sequentially.

    Checks are:
      1. File exists          — if FAIL, remaining checks are skipped.
      2. Header/footer format — FAIL if no valid block found.
      3. Commented-out lines  — WARN if any commented-out host entries are found.

    Returns:
        list: A list of result dicts with keys 'title', 'result', and 'details'.
    """
    output = []

    exists_check, hosts_file = hosts_file_exists_check()
    output.append(exists_check)
    if exists_check['result'] == "FAIL":
        return output

    format_check, (detected_format, header_idx, footer_idx) = hosts_format_check(hosts_file, sddcVersion)
    output.append(format_check)

    if detected_format is not None:
        output.append(hosts_commented_check(hosts_file, detected_format, header_idx, footer_idx))

    return output