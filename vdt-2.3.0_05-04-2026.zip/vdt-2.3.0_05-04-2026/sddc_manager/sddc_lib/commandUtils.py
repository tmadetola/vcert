#!/usr/bin/env python
"""
__author__ =  ["Laraib Kazi", "Tyler FitzGerald"]

"""
import subprocess
import sys
import os
import argparse
import atexit
import logging.config
from importlib import import_module

sys.path.append("/opt/vmware/sddc-support/dependency/")

try:
    import psycopg as psycopg_version 
except ImportError:
    try:
        import psycopg2 as psycopg_version
    except ImportError:
        raise ImportError(
            "Unable to import psycopg or psycopg2!"
        )

_DefaultCommmandEncoding = sys.getfilesystemencoding()

workingdir = os.path.dirname(os.path.abspath(__file__))
scripts_dir = os.path.join(workingdir, 'scripts')

def run_command(cmd, stdin=None, encoding=_DefaultCommmandEncoding):
    """
    Run a command in a subprocess and return the output.

    Args:
        cmd (list): A list of command and arguments to run.
        stdin (str, optional): Standard input for the command. Defaults to None.
        encoding (str, optional): The encoding to use for the input. Defaults to the default command encoding.

    Returns:
        bytes: The output of the command as bytes.

    Raises:
        subprocess.CalledProcessError: If the command returns a non-zero exit status.
        subprocess.TimeoutExpired: If the command times out.
    """    

    process = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, stdin=subprocess.PIPE)
    stdout, stderr = process.communicate(stdin)
    return stdout

def run_psql_command(db, query):
    """
    Run a PostgreSQL query with psycopg2

    Args:
        db (str): Database name
        query (str): SQL query to execute

    Returns:
        str: Output formatted like psql -qAtX
    """

    conn = None

    try:
        conn = psycopg_version.connect(
            dbname=db,
            user="postgres",
            host="localhost"
        )

        with conn.cursor() as cursor:
            cursor.execute(query)

            if cursor.description:
                rows = cursor.fetchall()

                output_lines = []
                for row in rows:
                    line = "|".join("" if col is None else str(col) for col in row)
                    output_lines.append(line)

                return "\n".join(output_lines)

            else:
                conn.commit()
                return ""

    except psycopg_version.OperationalError as e:
        raise Exception(f"Unable to connect to PostgreSQL: {e}")

    except Exception as e:
        raise Exception(f"Postgres query failed: {e}")

    finally:
        if conn:
            conn.close()