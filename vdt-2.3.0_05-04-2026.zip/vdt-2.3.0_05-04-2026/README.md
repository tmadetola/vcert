# VDT
 ```                                                    
VVVVVVVV           VVVVVVVVDDDDDDDDDDDDD       TTTTTTTTTTTTTTTTTTTTTTT
V::::::V           V::::::VD::::::::::::DDD    T:::::::::::::::::::::T
V::::::V           V::::::VD:::::::::::::::DD  T:::::::::::::::::::::T
V::::::V           V::::::VDDD:::::DDDDD:::::D T:::::TT:::::::TT:::::T
 V:::::V           V:::::V   D:::::D    D:::::DTTTTTT  T:::::T  TTTTTT
  V:::::V         V:::::V    D:::::D     D:::::D       T:::::T        
   V:::::V       V:::::V     D:::::D     D:::::D       T:::::T        
    V:::::V     V:::::V      D:::::D     D:::::D       T:::::T        
     V:::::V   V:::::V       D:::::D     D:::::D       T:::::T        
      V:::::V V:::::V        D:::::D     D:::::D       T:::::T        
       V:::::V:::::V         D:::::D     D:::::D       T:::::T        
        V:::::::::V          D:::::D    D:::::D        T:::::T        
         V:::::::V         DDD:::::DDDDD:::::D       TT:::::::TT      
          V:::::V          D:::::::::::::::DD        T:::::::::T      
           V:::V           D::::::::::::DDD          T:::::::::T      
            VVV            DDDDDDDDDDDDD             TTTTTTTTTTT      

                      vSphere Diagnostic Tool
```

__status__ = "Beta"

VCF Diagnostic Tool for vSphere (formerly vSphere Diagnostic Tool) is a multi product diagnostic tool that can be run directly on a vCenter Server appliance or SDDC Manager. It executes a series of checks on the system configuration and reports user-friendly PASS/FAIL/WARN results for known configuration issues. It also provides information (INFO) messages from certain areas which we hope will make detecting inconsistencies easier. The goal of these tests is to provide information to the user that is hard to gather or otherwise not obvious when troubleshooting an issue.

DISCLAIMER: This script is currently in its beta release phase. As such, it may contain bugs, errors, or incomplete features. Please leverage results with caution.  Please check this article frequently for the latest version.
 
NOTE:  If using a version of VDT attached to this article with '_beta' appended to the name, this version may result in unexpected errors.  If an error occurs, please report the issue to vcf-gs-sa-vdt.pdl@broadcom.com , then download and use the latest stable version (latest version without '_beta').  Additionally, check back frequently to use the latest version of the '_beta' version, as it will be updated often with bug fixes.
